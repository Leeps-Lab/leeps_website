
########################
### Construct Estimates for Table 2
### Test Hypotheses 1 and 2
########################



P <- read.table("INSERT-PATH-TO_Data.csv",header=TRUE,sep=",")
P$markup<-P$value-P$cost

P[P$attempted==FALSE,"markup"]<-P[P$attempted==FALSE,]$high_val_round
 
P<-P[P$round<36,]


P$high<-(P$treatment=="High")*1
P$M<-(P$structure=="M")*1
P$interact<-(P$treatment=="High")*(P$structure=="M")*1



P$limit1<-80*(1-P$M)
P$limit2<-120*(P$M)*(1-P$high)
P$limit3<-144*(P$M)*(P$high)
P$limit<-P$limit1+P$limit2+P$limit3

library(nlme)

# Produce Table 2

model<-lme(markup~high+M+interact,random=~1|session/uniquesub,data=P[P$high_val_round>144 & P$attempted==TRUE,])
summary(model)

library(gregmisc)
library(gmodels)

#Wald test: High Monopoly greater than High Competition
estimable(model, c(0,0,1,1))


#Wald test: High Monopoly greater than Low Monopoly
estimable(model, c(0,1,0,1))



