
##########################
### Produce Figure 6, supporting Finding 4
##########################


cutoff<-80
rnd<-36
funct<-"mean"
step<-4


library("survival")
library("plotrix")

P <- read.table("INSERT-PATH-TO_Data.csv",header=TRUE,sep=",")

P$markup<-P$value-P$cost
P$bin<-cut(P$cost,breaks=seq(50,80,step),labels=FALSE)
P$n<-1






#################
## CONSTRUCT DATA FRAME OF OPTIMAL BEHAVIOR
#################


optimal<-expand.grid(cost=seq(40,80,by=2))
optimal$op.high<- (-0.001895*((optimal$cost)^2))+(0.97302235*optimal$cost)+14.2864917
optimal$op.low<- (-0.0024833*((optimal$cost)^2))+(1.06949379*optimal$cost)+10.3335244
optimal$ea.low<- (optimal$op.low-optimal$cost)*((50/optimal$op.low)^3)*(((80-optimal$cost)/30)^2)
optimal$ea.high<- (optimal$op.high-optimal$cost)*((50/optimal$op.high)^2.25)*(((80-optimal$cost)/30)^2)
optimal$op.low<-optimal$op.low-optimal$cost
optimal$op.high<-optimal$op.high-optimal$cost


#################
## SUBSET DATA AND CREATE VARIABLES
#################


low.a<-P[P$treatment=="Low" & P$structure=="C" & P$attempted==TRUE & P$high_val_round > cutoff  & P$round<rnd,]
high.a<-P[P$treatment=="High" & P$structure=="C" & P$attempted==TRUE & P$high_val_round>cutoff  & P$round<rnd,]

low.a$size<-ave(low.a$n,low.a$bin,FUN=sum)
high.a$size<-ave(high.a$n,high.a$bin,FUN=sum)

low.a$error<-ave(low.a$markup,low.a$bin,FUN=std.error)
high.a$error<-ave(high.a$markup,high.a$bin,FUN=std.error)



#################
## FORM DATASET OF MEANS
#################


low.ave.a<-aggregate.data.frame(list(markup=low.a$markup,cost=low.a$cost,error=low.a$error, n=low.a$size),list(bin=low.a$bin),FUN=funct)
high.ave.a<-aggregate.data.frame(list(markup=high.a$markup, cost=high.a$cost,error=high.a$error, n=high.a$size),list(bin=high.a$bin),FUN=funct)


#################
## PRODUCE FIGURE
#################

layout(matrix(c(1,2),1,2))

plot(low.ave.a$markup~low.ave.a$cost,ylim=c(0,10),main="Low",col="black",xlab="Cost",ylab="Markup",xlim=c(50,80))
lines(optimal$cost,optimal$op.low,col="black")
lines(optimal$cost,optimal$ea.low,col="black",lty=2)
abline("h"=0)
legend("topleft", legend=c("BNE Markup","BNE Expected Earnings"),col=c("black","black"),bg="white",lty=c(1,2),box.lwd="white",box.lty="blank")



plot(high.ave.a$markup~high.ave.a$cost,ylim=c(0,10),main="High",col="black",xlab="Cost",ylab="Markup",xlim=c(50,80))
lines(optimal$cost,optimal$op.high,col="black")
lines(optimal$cost,optimal$ea.high,col="black",lty=2)
abline("h"=0)


# Fraction who attempt investment in this sample
mean(P[P$structure=="C" & P$high_val_round > cutoff,]$attempted)

# As above, disaggregated by treatment
tapply(P[P$structure=="C" & P$high_val_round > cutoff,]$attempted,P[P$structure=="C" & P$high_val_round > cutoff,]$treatment,mean )




