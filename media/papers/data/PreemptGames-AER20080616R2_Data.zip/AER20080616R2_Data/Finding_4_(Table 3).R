
#####################
##  Statistical Models Reported in Table 3 in Support of Finding 4
#####################


#Open dataset.csv
P <- read.table("INSERT-PATH-TO_Data.csv",header=TRUE,sep=",")



P<-P[P$high_val_round>80 & P$attempted==TRUE & P$structure=="C",]

P$markup<-P$value-P$cost

low<-P[P$treatment=="Low",]
high<-P[P$treatment=="High",]

library(nlme)


########################
#  GENERATE OPTIMAL VALUES
#  Used for weighting regressions
########################


low$op<- (-0.001895*((low$cost)^2))+(0.97302235*low$cost)+14.2864917
high$op<- (-0.0024833*((high$cost)^2))+(1.06949379*high$cost)+10.3335244
low$ea<- (low$op-low$cost)*((50/low$op)^3)*(((80-low$cost)/30)^2)
high$ea<- (high$op-high$cost)*((50/high$op)^2.25)*(((80-high$cost)/30)^2)

low$opmark <- low$op - low$cost
high$opmark <- high$op - high$cost

low$ea<-1/low$ea
high$ea<-1/high$ea



library(gregmisc)
library(gmodels)


########################
#  Estimate Statistical Models
########################


#  REGRESSIONS FOR LOW TREATMENT

low.80<-lme(markup~cost,random=~1|session/uniquesub ,data=low[low$cost<=80,])
low.70<-lme(markup~cost,random=~1|session/uniquesub ,data=low[low$cost<=70,])
low.60<-lme(markup~cost,random=~1|session/uniquesub ,data=low[low$cost<=60,])
low.w<-lme(markup~cost,random=~1|session/uniquesub, data=low, weights=varFixed(~ea))


# Show regression results

summary(low.80)
summary(low.70)
summary(low.60)
summary(low.w)

#Wald tests

estimable(low.80, rbind(c(0,1),c(1,0)),beta0=c(-0.253,20.65))
)

estimable(low.70, rbind(c(0,1),c(1,0)),beta0=c(-0.253,20.65))

estimable(low.60, rbind(c(0,1),c(1,0)),beta0=c(-0.253,20.65))

estimable(low.w, rbind(c(0,1),c(1,0)),beta0=c(-0.253,20.65))



#  REGRESSIONS FOR HIGH TREATMENT



high.80<-lme(markup~cost,random=~1|session/uniquesub ,data=high[high$cost<=80,])
high.70<-lme(markup~cost,random=~1|session/uniquesub ,data=high[high$cost<=70,])
high.60<-lme(markup~cost,random=~1|session/uniquesub ,data=high[high$cost<=60,])
high.w<-lme(markup~cost,random=~1|session/uniquesub, data=high, weights=varFixed(~ea))


#Show regression results

summary(high.80)
summary(high.70)
summary(high.60)
summary(high.w)


# Wald tests


estimable(high.80, rbind(c(0,1),c(1,0)),beta0=c(-0.273,22.14))

estimable(high.70, rbind(c(0,1),c(1,0)),beta0=c(-0.273,22.14))

estimable(high.60, rbind(c(0,1),c(1,0)),beta0=c(-0.273,22.14))

estimable(high.w, rbind(c(0,1),c(1,0)),beta0=c(-0.273,22.14))




