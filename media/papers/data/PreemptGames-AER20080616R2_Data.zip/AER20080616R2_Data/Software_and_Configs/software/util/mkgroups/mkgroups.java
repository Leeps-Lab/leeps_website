import java.util.*;


class mkgroups {

   final int rounds = 25;
   final int groupSize = 3;
   final int groups = 4;
   final int players = groups * groupSize;

   Random rand = new Random(System.currentTimeMillis());

   LinkedList<Integer> usedPlayers = new LinkedList<Integer>();
   LinkedList<String> usedGroups = new LinkedList<String>();


   boolean beenTogether(int[] group) {
      return true;
   }


   String getPlayers(int[] group) {
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < group.length; i++) {
         sb.append(group[i]);
         if (!(i + 1 == group.length)) {
            sb.append(',');
         }
      }
      return sb.toString();
   }


   int[] genRandGroup() {
      int[] group = new int[groupSize];
      for (int i = 0; i < group.length; i++) {

         boolean unique = false;
         while (!unique) {
            group[i] = genRandPlayer();
            unique = true;
            for (int j = i - 1; j >= 0; j--) {
               if (group[i] == group[j]) {
                  unique = false;
               }
            }
         }
      }
      return group;
   }



   int genRandPlayer() {
      int player = rand.nextInt(players) + 1;
      if (!usedPlayers.contains(player)) {
         usedPlayers.add(player);
         return player;
      } else if (usedPlayers.size() == players) {
         System.out.println("ERROR");
         return 0;
      } else {
         return genRandPlayer();
      }
   }


   public static void main(String[] args) {
      new mkgroups();
   }


   void releaseGroup(int[] group) {
      for (int p = 0; p < group.length; p++) {
         usedPlayers.remove((Integer) group[p]);
      }
   }
   
   void releaseGroupSet(int[][] groupSet) {
      for (int[] group: groupSet) {
         usedGroups.remove(getPlayers(group));
      }
   }


   public mkgroups() {
      for (int r = 1; r <= rounds; r++) {
         int[][] roundData = new int[groups][groupSize];
         System.out.printf("<round id=\"%d\">%n", r);
         boolean validSet = false;
         while (!validSet) {
            validSet = true;
            usedPlayers.clear();
            
            mkset_loop:
            for (int g = 1; g <= groups; g++) {

               int[] group = null;


               boolean foundGroup = false;
               while (!foundGroup) {
                  group = genRandGroup();
                  Arrays.sort(group);
                  if (!usedGroups.contains(getPlayers(group))) {
                     foundGroup = true;
                  } else {
                     
                     releaseGroup(group);
                     
                     if(g==groups){
                        validSet=false;
                        releaseGroupSet(roundData);
                        roundData = new int[groups][groupSize];
                        break mkset_loop;
                     }
                  }
               }
               usedGroups.add(getPlayers(group));
               roundData[g-1] = group;
            }
         }
         for(int g = 0; g < roundData.length; g++){
            int[] group = roundData[g];
            System.out.printf("\t<player id=\"%s\" group.id=\"%s\"/>%n", getPlayers(group), g+1);
         }
         System.out.printf("</round>%n%n");
      }
   }
}

