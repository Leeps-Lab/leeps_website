/* SwapRounds
 *
 * Use this to modify the IT game.csv output file.
 *
 * We use the game.csv file as an input file to run the same
 * random draws for future experiments.  But, sometimes we want to juggle
 * the rounds around so better suit the session experience. That's what this
 * is for.
 *
 * You need a period_map.csv file:  1st column is old period number
 *                                  2nd column is new period number
 *
 */
import java.io.*;
import java.util.*;

public class swapRounds
{
	static TreeMap<Integer, ArrayList> periods  = new TreeMap<Integer, ArrayList>();
    static TreeMap<Integer, Integer>  period_map = new TreeMap<Integer, Integer>();

	public static void main(String[] args) throws Exception
	{
		String in1 = null;
		String in2 = null;
		String out1 = null;

		try
		{
			in1 = args[0];
			in2 = args[1];
			out1 = args[2];
		}
		catch(Exception e)
		{
			System.out.println("Usage:");
			System.out.println("java swapRounds [period map] [game input file] [game output file]");
			System.out.println();
			System.out.println("Example:");
			System.out.println("java swapRounds map.csv game.csv game-2.csv");
			System.out.println();
			System.out.println("Period Map file should have two columns: period_input_id, period_output_id");
			System.exit(0);
		}
		readMapCsv(in1);
		readGameCsv(in2);
		createGameCsv(out1);
	}

	static void readMapCsv(String inputFile) throws Exception
	{
		BufferedReader in = new BufferedReader(new FileReader(inputFile));

		String line;

		while((line = in.readLine()) != null)
		{
            int old_round = -1, new_round = -1;
			String[] split = line.split(",");

			try
			{
				old_round = Integer.parseInt(split[0].trim());
				new_round = Integer.parseInt(split[1].trim());

				period_map.put(new Integer(old_round), new Integer(new_round));

			}
			catch(Exception e)
			{
				continue;
			}
		}
		in.close();
	}

	static void readGameCsv(String inputFile) throws Exception
	{
		BufferedReader in = new BufferedReader(new FileReader(inputFile));

		String line;
        ArrayList<String[]> round_data = new ArrayList<String[]>();

        int prev_round = -1;
		while((line = in.readLine()) != null)
		{
           
            int this_round = 0;

			try
			{
			    String[] split = line.split(",");
				this_round = Integer.parseInt(split[2].trim());

                if (prev_round != this_round) {
                    if (prev_round > 0) periods.put((Integer)period_map.get(new Integer(prev_round)), round_data);
                    round_data = new ArrayList<String[]>();
                    prev_round = this_round;
                }

                round_data.add(split);
			}
			catch(Exception e)
			{
			}
		}
		in.close();
	}

	static void createGameCsv(String outputFile) throws Exception
	{
		PrintWriter out = new PrintWriter(outputFile);

		while(  ! periods.isEmpty())
		{
            Integer round = (Integer) periods.firstKey();
            ArrayList round_data = (ArrayList) periods.remove(round);
		    while(  ! round_data.isEmpty()) {
                // Get a line of data (array of columns)
                String[] column = (String[]) round_data.remove(0);
                column[2] = ""+round;
                for(int j = 0; j < column.length; j++)
                {
                    out.print(column[j]);
                    if(j == 2) out.print("    ");
                    if(j < column.length - 1)
                        out.print(',');
                }//end for
                out.println();
            }//end while
        }//end while
        out.close();
    }// end createGameCsv
}// end main
