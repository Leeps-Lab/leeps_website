import java.io.*;
import java.util.*;

public class Prepare_IT_Output
{
	static TreeMap<Integer, Double> highValues = new TreeMap<Integer, Double>();
    static TreeMap<Integer, Integer>endTimes = new TreeMap<Integer, Integer>();

    static Integer _round = 1;

	public static void main(String[] args) throws Exception
	{
		String in1 = null;
		String in2 = null;
		String out1 = null;

		try
		{
			in1 = args[0];
			in2 = args[1];
			out1 = args[2];
		}
		catch(Exception e)
		{
			System.out.println("Usage:");
			System.out.println("java Prepare_IT_Output [game input file] [event input file] [event output file]");
			System.out.println();
			System.out.println("Example:");
			System.out.println("java Prepare_IT_Output game.csv event.csv event-2.csv");
			System.exit(0);
		}
		readGameCsv(in1);
		createEventCsv(in2, out1);
	}

	static void readGameCsv(String inputFile) throws Exception
	{
		BufferedReader in = new BufferedReader(new FileReader(inputFile));

		String line;
		while((line = in.readLine()) != null)
		{
            int round = 0;
            Integer time = new Integer(-1);
			String[] split = line.split(",");

			try
			{
				time = Integer.parseInt(split[0].trim());
				round = Integer.parseInt(split[2].trim());

				double value = Double.parseDouble(split[5].trim());
				Double prevValue = highValues.get(round);
				if(prevValue == null || value > prevValue.doubleValue())
					highValues.put(round, value);

				endTimes.put(new Integer(round), time);

			}
			catch(Exception e)
			{
				continue;
			}
		}
		in.close();
	}

	static void createEventCsv(String inputFile, String outputFile) throws Exception
	{
		BufferedReader in = new BufferedReader(new FileReader(inputFile));
		PrintWriter out = new PrintWriter(outputFile);

        Vector<String[]> lines = new Vector<String[]>();
		String line;
        out.println(in.readLine());
		while((line = in.readLine()) != null)
		{
			String[] split = line.split(",");
			try
			{
				_round = Integer.parseInt(split[1].trim());

                String[] split2 = new String[split.length+2];
                System.arraycopy(split, 0, split2, 0, split.length);
			    split2[split2.length-2] = " " + Double.toString(highValues.get(_round));
                lines.addElement(split2);
			}
			catch(Exception e)
			{
                if(line.startsWith("TIME"))
                {
                    line = line.replaceFirst("HIGH_VALUE", "HIGH_VAL_NOW");
                    line = line + "\t ,HIGH_VAL_ROUND ,TIME_END";
                    out.println(line);
                }
                else if(line.startsWith("###"))
                {
                    for(int i = 0; i < lines.size(); i++)
                    {
                       String[] part = (String [])lines.get(i);
                       //add ending time
                       part[part.length-1] = endTimes.get(_round).toString();
                       
                       //then write line to file
                       for(int j = 0; j < part.length; j++)
                       {
                          out.print(part[j]);
                          if(i < part.length - 1)
                             out.print(',');
                       }//end for
                       out.println();
                    }//end for
                    //uncomment next line to print out ###end of round
                    //out.println(line);
                    lines.clear();
                }//end else if
				continue;
			}//end catch
		}//end while
		in.close();
		out.close();
	}
}// end main
