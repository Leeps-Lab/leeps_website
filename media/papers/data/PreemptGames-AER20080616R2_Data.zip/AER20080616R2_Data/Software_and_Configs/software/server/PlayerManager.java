package leeps.it.server;
import leeps.utility.net.server.MessengerServer;
import leeps.utility.net.QueuedMessenger;
import leeps.utility.data.Message;
import java.util.Map;
import java.util.HashMap;

public class PlayerManager {
    static final private Map connectedPlayers = new HashMap(); 
    static final private Map disconnectedPlayers = new HashMap();

    public static void acceptConnection(final QueuedMessenger connection) {
        new Thread() {
            public void run() {
                for(int i = 0; i < 100; i++)
                    if(authenticate(connection)) 
                        return;
            }
        }.start();
    }

    private static boolean authenticate(QueuedMessenger connection) {
        Message loginData = (Message)connection.getMessage();
        if(loginData == null)
            return false;
        synchronized (PlayerManager.class) {
            String name;
            if(!(loginData.has("name") 
                    && (name = loginData.getTS("name", "")).length() > 0))
            {
                connection.send(new Message("login.reject")
                        .set("message", "Please enter your name."));
                return false;
            }

            if(connectedPlayers.containsKey(name)) {
                connection.send(new Message("login.reject")
                        .set("message", name + 
                            " is already connected. Distinguish yourself."));
                return false;
            }
            if(disconnectedPlayers.containsKey(name) 
                    && !loginData.getp("relogin")) {
                connection.send(new Message("login.reject")
                        .set("message", 
                            "if you were disconnected "+
                            "and are reconnecting,\r\n" + 
                            "please say so by checking the relogin button."
                            ));
                return false;
            } 
            if(!disconnectedPlayers.containsKey(name) 
                && loginData.getp("relogin")) {
                connection.send(new Message("login.reject")
                        .set("message", 
                            "Either this is your first time " + 
                            "logging in (uncheck [relogin]),\r\n" +
                            "or you did not spell your " +
                            "name exactly as before."
                            ));
                return false;
            }

            if(!loginData.getp("relogin")) {
                return newPlayer(connection, name);
            } else {
                return oldPlayer(connection, name);
            }
        }
    }

    public static boolean newPlayer(QueuedMessenger connection, String name) {
        Game.Player player = Game.makeNetworkPlayer(connection, name);
        if(player != null) {
            connectedPlayers.put(name, player);
            connection.send(new Message("login.accept"));
            Terminal.message("connected: " + name + "/" + (player.id+1));
            return true;
        } else {
            connection.send(new Message("login.reject")
                    .set("message", "the game is full, sorry"));
            return false;
        }
    }

    public static boolean oldPlayer(QueuedMessenger connection, String name) {
        NetworkPlayer player = 
            (NetworkPlayer)disconnectedPlayers.remove(name);
        connectedPlayers.put(name, player);
        connection.send(new Message("login.accept"));
        player.renewConnection(connection);
        Terminal.message("reconnected: " + name + "/" + player.id);
        return true;
    }

    public static synchronized void playerDisconnected(String name) {
        disconnectedPlayers.put(name, connectedPlayers.remove(name));
    }
}
