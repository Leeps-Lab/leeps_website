package leeps.it.server;
import leeps.utility.net.server.MessengerServer;
import leeps.utility.net.server.AppletWriter;
import leeps.utility.net.server.JNLPWriter;
import leeps.utility.net.QueuedMessenger;
import leeps.utility.data.Message;
import leeps.utility.Debug;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import leeps.utility.Logger;

public class Server implements MessengerServer.Listener {
    static final String APPLET_TITLE = "Investment Timing";
    static final String APPLET_CODE = "leeps/it/client/ITClient.class";

    static Message commandLineConfig;
    private static Server instance = new Server();
    static MessengerServer server;
    static {
        try {
            server = new MessengerServer(instance);
        } catch(Exception ex) {
            Debug.print("ERROR", Server.class, "static-init",
                    "Server creation failed:" + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
        }
    }

    private Server(){}

    public static void main(String[] args) {
        commandLineConfig = parseCommandLine(args);
        if(!Rules.setConfigFile(commandLineConfig.getz("config.file"))) {
            Debug.print("ERROR", Server.class, "initial-config",
                    "Please fix the config file before anything");
            System.exit(1);
        }


        try {
            System.err.println("Deploying into: " 
                    + Rules.getGameConfig().getz(
                        "deploy.directory", "!!!OUCH!!!") + "...");
            doDeploy();
            System.err.println("Initializing the game...");
            Game.initializeGameData();
            System.err.println("Opening up the network...");
            server.start();
        } catch (Exception ex) {
            Debug.print("ERROR", Server.class, "startup",
                    "Error in initialization, aborting");
            ex.printStackTrace();
            System.exit(1);
        }

        System.err.println("Investment Timing Server... ready!");
        Terminal.doCommandLine();
    }
    
    private static String stripSuffix(String word, String suffix) {
        if(word.endsWith(suffix))
            return word.substring(0, word.length() - suffix.length());
        else
            return word;
    }
    
    private static Message parseCommandLine(String[] args) {
        String configFile = "config.xit";
        Message config = new Message("command-line");

        int k;
        for(k = 0; k < args.length && args[k].charAt(0) == '-'; k++) {
            if(args[k].equals("--")) {
                k++;
                break;
            }

            for(int x = 0; x < args[k].length(); x++)
            switch(args[k].charAt(x++)) {
            case 'o':
                String output;
                if(x == args[k].length()) {
                    output = args[++k];
                } else {
                    output = args[k++].substring(x);
                }
                config.set("output.directory", output);
                break;
            default: 
                Debug.print(
                        "WARNING", Server.class, "command-line",
                        "unrecognized option -" + args[k].charAt(x));
                break;
            }
        }
        if(k < args.length) {
            configFile = args[k++];
        }
        config
            .set("config.file", configFile)
            .set("?output.directory", 
                    stripSuffix(configFile, ".xit"));
        if(k < args.length) {
            Debug.print("WARNING", Server.class, "command-line",
                    "Unused argument(s): " + args[k]);
        }
        return config;
    }

    static void writeStream(InputStream stream, File target) throws Exception {
        FileOutputStream writer = new FileOutputStream(target);
        byte[] buf = new byte[128];
        int bytes;
        while((bytes = stream.read(buf)) != -1) {
            writer.write(buf, 0, bytes);
        }
        writer.close();
    }

    static void doDeploy() throws Exception {
        Message gameConfig = Rules.getGameConfig();
        AppletWriter appletHTML = new AppletWriter( 
                gameConfig.getz("deploy.applet.title", APPLET_TITLE),
                gameConfig.getz("deploy.applet.archive", "client.jar"),
                gameConfig.getz("deploy.applet.code", APPLET_CODE),
                server,
                gameConfig.geti("deploy.applet.width", 400),
                gameConfig.geti("deploy.applet.height", 300)
                );

        JNLPWriter jnlp = new JNLPWriter();
        jnlp.configureFromMapStrings(
                gameConfig.extract("deploy.jnlp").getMap());
        // jnlp.set("title", APPLET_TITLE);
        // jnlp.addJar("client.jar");
        // jnlp.addJar("swixml.jar");
        // jnlp.addJar("jdom.jar");
        // jnlp.set("codebase", "http://leeps.ucsc.edu/~fluffy/it/");
        // jnlp.set("main.class", "leeps.it.client.ITClient");
        // jnlp.set("width", "" + gameConfig.geti("deploy.applet.width", 400));
        // jnlp.set("height", "" + gameConfig.geti("deploy.applet.height", 400));

        jnlp.addParam("host", server.getHost());
        jnlp.addParam("port", "" + server.getPort());
        jnlp.addArgument(server.getHost());
        jnlp.addArgument("" + server.getPort());

        InputStream appletTemplate = 
            Server.class.getResourceAsStream("applet.html");
        if(appletTemplate != null) {
            appletHTML.setTemplate(appletTemplate);
            appletTemplate.close();
        }

        String appletFilename = 
                    gameConfig.getz("deploy.applet.filename", "applet.html");
        appletHTML.writeApplet(
                new File(gameConfig.getz("deploy.directory"), 
                    appletFilename));
        jnlp.writeApplication(new File(gameConfig.getz("deploy.directory"), 
                    "it.jnlp"));

        InputStream indexHTML = Server.class.getResourceAsStream("index.html");
        if(indexHTML != null) {
            appletHTML.setTemplate(indexHTML);
            appletHTML.set("applet.html", appletFilename);
            appletHTML.writeApplet(
                    new File(gameConfig.getz("deploy.directory"), 
                        "index.html"));
            indexHTML.close();
        }
    }

    public void hear(QueuedMessenger connection) {
        PlayerManager.acceptConnection(connection);
    }
}
