package leeps.it.server;

import java.util.*;

import leeps.utility.data.*;

/**
 * Static class that calculates the optimal investment value.
 * @author Josh Vinson
 */
public class NashEquilibrium
{
	private NashEquilibrium()
	{
		//
	}

	/**
	 * Calculates the optimal investment value based on the current rules and
	 * the player's data.
	 * @param data should be the Message object passed to Game.Player.gameData(Message).
	 * @return the value at which one should invest.
	 * @see Game.Player#gameData(Message)
	 */
	public static int getInvestTarget(Message data)
	{
		int investTarget;

		//I = this player's cost
		int cost = 0;
		int lowestPossibleCost = 0;
		int highestPossibleCost = 0;

		double[] otherCosts;

		//dT = tickDuration
		double tickDurationNormalized;
		//q = tickEndProbability
		double tickEndProbability;
		//dH = valueStepPercent
		double valueStepPercent;
		//p = valueStepChance
		double valueStepChance;
		//n = groupSize
		int groupSize;

		//these are calculated
		//sigma = "constant, instantaneous standard deviation in the drift rate, alpha"
		double sigma;
		//alpha = "constant, instantaneous growth rate of the value of the asset, Vt"
		double alpha;
		//rho = "total required rate of return for the robot player"
		double rho;
		//delta = rho - alpha
		double delta;
		double beta;
		double vm; // value monopoly
		double vc; // value competition

		cost = data.geti("cost");
		double tickDuration = data.getd("tick.duration.ms");
        tickDurationNormalized = (double) tickDuration / 60000.0;
		int mean = Rules.getCurrentRound().geti("cost.mean");
		int radius = Rules.getCurrentRound().geti("cost.radius");
		lowestPossibleCost = mean - radius;
		highestPossibleCost = mean + radius;
		tickEndProbability = Rules.getCurrentRound().getd("ticks.end.prob");
		valueStepPercent = Rules.getCurrentRound().getd("value.step.percent") / 100.0;
		valueStepChance = Rules.getCurrentRound().getd("value.step.chance");
		groupSize = data.geti("groupSize");
		otherCosts = (double[])data.get("cost.shadow", new double[0]);

		//was initEq()
		sigma = valueStepPercent / Math.sqrt(tickDurationNormalized);
		alpha = (2.0 * sigma * (valueStepChance - .5)) / Math.sqrt(tickDurationNormalized);
		rho = -Math.log(1.0 - tickEndProbability) / tickDurationNormalized;

		delta = rho - alpha;

		double betaTemp1 = 0.5;
		double betaTemp2 = (rho - delta) / (sigma * sigma);
		double betaTemp3 = Math.pow(betaTemp2 - betaTemp1, 2) + ((2 * rho) / (sigma * sigma));

		beta = betaTemp1 - betaTemp2 + Math.sqrt(betaTemp3);

		if(beta < 1)
		{
			System.out.println("Warning: beta < 1");
		}

		vm = (beta * cost) / (beta - 1.0); // This is the optimal value for monopoly case

/*        System.err.println("***** Start NashEq debug (period "+Rules.getRoundID()+") *****");
        System.err.println("cost = "+cost);
        System.err.println("tickDurationNormalized = "+tickDurationNormalized);
        System.err.println("lowCost = "+lowestPossibleCost);
        System.err.println("highCost = "+highestPossibleCost);
        System.err.println("tickEndProb = "+tickEndProbability);
        System.err.println("valueStepPct = "+valueStepPercent);
        System.err.println("valueStepChance = "+valueStepChance);
        System.err.println("groupSize = "+groupSize);
        System.err.println("otherCosts = "+otherCosts);
        System.err.println("sigma = "+sigma);
        System.err.println("alpha = "+alpha);
        System.err.println("rho = "+rho);
        System.err.println("delta = "+delta);
        System.err.println("betaTemp1 = "+betaTemp1);
        System.err.println("betaTemp2 = "+betaTemp2);
        System.err.println("betaTemp3 = "+betaTemp3);
        System.err.println("beta = "+beta);
        System.err.println("vm = "+vm);  */
       

        vc = vm; 

		if (groupSize > 1) { // If not monopoly  
            if(otherCosts.length > 0) // If costs are public
            {   // Then use 2nd lowest cost, or my cost if higher
                double[] temp = new double[otherCosts.length];
                System.arraycopy(otherCosts, 0, temp, 0, otherCosts.length);
                Arrays.sort(temp);
                vc = Math.max(temp[1], cost); 
            }
            else // If costs are private
            {
                double denom = groupSize;
                double numerator = ((groupSize -1) * cost + highestPossibleCost);
                vc = Math.round(numerator / denom);
            }
        }

        investTarget = (int) Math.min(vc, vm);

/*        System.err.println("vc = "+vc); 
        System.err.println("investTarget = "+investTarget);
        System.err.println("************"); */
		return investTarget;
	}
}
