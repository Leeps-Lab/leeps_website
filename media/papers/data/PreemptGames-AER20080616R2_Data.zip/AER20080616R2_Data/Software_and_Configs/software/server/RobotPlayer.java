package leeps.it.server;

import leeps.utility.data.*;

/**
 * AI Player that invests once it reaches a given profit.
 */
public class RobotPlayer extends Game.Player
{
	int cost = 0;
	int threshold;
	boolean play, enabled;

	/**
	 * Creates a Robot Player with the provided name and id, that uses
	 * NashEquilibrium to find a target investment value.
	 * @param name
	 * @param id
	 */
	public RobotPlayer(String name, int id)
	{
		this(name, id, -1);
	}

	/**
	 * Creates a Robot Player with the provided name, id, and target value.
	 * @param name
	 * @param id
	 * @param threshold the value at which the robot player will
	 * invest. A value of -1 indicates to use NashEquilibrium optimal threshold.
	 */
	public RobotPlayer(String name, int id, int threshold)
	{
		super(id, name, "robot");
		this.threshold = threshold;
	}

	public void gameData(Message data)
	{
		if(data.type().equals("round.start"))
		{
			cost = data.geti("cost");
            enabled = data.getp("enabled", true);
			if (enabled) play = true;
		}
		if(play)
		{
			if(data.type().equals("round.tick"))
			{
				int value = data.geti("value");
                int targetValue = threshold;
                if(threshold == -1) targetValue = optimal_investment;
				if(value > targetValue)
				{
					invest();
					play = false;
				}
			}
			else if(data.type().equals("round.end"))
			{
				play = false;
			}
		}
	}
}
