package leeps.it.server;

import leeps.utility.net.QueuedMessenger;
import leeps.utility.net.Messenger;
import leeps.utility.data.Message;
import leeps.utility.Debug;
import leeps.utility.Range;
import leeps.utility.gui.ColorString;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Random;
import java.util.Date;
import java.text.DateFormat;
import java.util.StringTokenizer;
import java.util.Comparator;
import java.lang.reflect.Method;
import java.lang.reflect.Constructor;
import java.lang.Math;
import java.awt.Color;
import leeps.utility.sm.StateMachineParser;
import leeps.utility.sm.StateMachine;
import leeps.utility.io.InputStreamScanner;
import leeps.utility.ThreadControl;
import leeps.utility.Delay;
import leeps.utility.Logger;
import leeps.utility.text.Tabulate;
import java.io.BufferedReader;
import java.io.FileReader;
import leeps.utility.text.Padder;

public class Game {
   static Player[] players;
   static int connectedPlayerCount = 0;
   final static Object playerMonitor = new Object();
   final static Object investmentMonitor = new Object();
   final static StateMachine state;
   static int currNumTicks;
   static long investedValue;

   static {
      StateMachine state_ = null;
      try {
         state_ = StateMachineParser.parse(new InputStreamScanner(
                  Game.class.getResourceAsStream("game.stm")),
                  Game.class, Message.class).build(null);
      } catch (Exception ex) {
      }
      state = state_;
   }


   public static void initializeGameData() {
      try {
         int numPlayers = Rules.getGameConfig().geti("players");
         int numRobots = 0;
         players = new Player[numPlayers];
         for (int i = 0; i < numPlayers; i++) {
            Message playerConfig = Rules.getPlayerConfig(i);
            Class clazz = Class.forName(playerConfig.getz("class"));
            Constructor cons = null;
            try {
               cons = clazz.getConstructor(new Class[]{String.class, int.class});
            } catch (NoSuchMethodException ex) {
            }

            if (cons != null) {
               cons.newInstance(new Object[]{new String("Robot " + (i + 1)), new Integer(i)});
               numRobots++;
            } else {
               Method registerHole = null;

               try {
                  registerHole = clazz.getMethod("registerHole",
                           new Class[]{int.class});
               } catch (NoSuchMethodException ex) {
               }

               if (registerHole != null) {
                  registerHole.invoke(null,
                           new Object[]{new Integer(i)});
               }
            }
         }
         if (numPlayers == numRobots) {// if no human players then signal
            signal("connect");
         }// all players connected
      } catch (Exception ex) {
         Debug.print("ERROR", Game.class, "init",
                  ex.toString());
         ex.printStackTrace();
         System.exit(1);
      }

      System.err.println("Setting up output files...");

      try {
         Logger.setOutputDirectory(
                  Server.commandLineConfig.getz("output.directory"));
         Logger.addOutputFile("game.csv");
         Logger.addOutputFile("round.csv");
         Logger.addOutputFile("event.csv");
         Logger.addOutputFile("score_log.txt");
         Logger.addOutputFile("payment.csv");
         Logger.addOutputFile("log.txt");

         Logger.println("payment.csv", "#" +
                 DateFormat.getDateTimeInstance(
                     DateFormat.FULL, DateFormat.LONG)
                 .format(new Date()));

         Logger.setupTable("payment.csv",
                  new Tabulate(
                  new String[]{
                  "player.id",
                  "player.name",
                  "player.score",
                  "player.payment"
                  }, new String[]{
                  "ID ",
                  "Name               ",
                  "Score   ",
                  "$Payment (dollars)"
                  }, ",", 1, "."));


         Logger.println("round.csv", "#" +
                 DateFormat.getDateTimeInstance(
                     DateFormat.FULL, DateFormat.LONG)
                 .format(new Date()));

         Logger.setupTable("round.csv",
                  new Tabulate(
                  new String[]{
                  "timestamp",
                  "round.id",
                  "ticks",
                  "ticks.end.prob",
                  "value.initial",
                  "value.step.percent",
                  "value.step.chance",
                  "cost.min",
                  "cost.max",
                  "cost.viewable.others",
                  "groups.random.size",
                  "groups.allow.invest.attempt",
                  "treatment"
                  }, new String[]{
                  "TIME    ",
                  "ROUND ",
                  "TICKS ",
                  "END_CHANCE",
                  "START ",
                  "VAL_STEP_% ",
                  "VAL_CHANCE_UP ",
                  "COST_MIN ",
                  "COST_MAX ",
                  "COST_PUBLIC",
                  "GROUP_SIZE ",
                  "GROUP_ALLOW_INVESTMENT_ATTEMPTS ",
                  "TREATMENT"
                  }, ",", 1, "."));



         Logger.println("game.csv", "#" +
                 DateFormat.getDateTimeInstance(
                     DateFormat.FULL, DateFormat.LONG)
                 .format(new Date()));

         Logger.setupTable("game.csv",
                  new Tabulate(
                  new String[]{
                  "timestamp",
                  "tick",
                  "round.id",
                  "client.id",
                  "group.id",
                  "value",
                  "cost",
                  "score"
                  }, new String[]{
                  "TIME    ",
                  "TICK ",
                  "ROUND ",
                  "ID  ",
                  "GROUP ",
                  "VALUE    ",
                  "COST  ",
                  "SCORE  "
                  }, ",", 1, "."));


         Logger.println("event.csv", "#" +
                 DateFormat.getDateTimeInstance(
                     DateFormat.FULL, DateFormat.LONG)
                 .format(new Date()));

         Logger.setupTable("event.csv",
                  new Tabulate(
                  new String[]{
                  "timestamp",
                  "round.id",
                  "client.id",
                  "client.type",
                  "group.id",
                  "value",
                  "optimal",
                  "value.high",
                  "cost",
                  "score",
                  "invested",
                  "attempted",
                  "cost.min",
                  "cost.max",
                  "cost.public",
                  "treatment"
                  }, new String[]{
                  "TIME    ",
                  "ROUND ",
                  "ID  ",
                  "TYPE    ",
                  "GROUP ",
                  "VALUE ",
                  "OPTIMAL",
                  "HIGH_VALUE ",
                  "COST  ",
                  "SCORE  ",
                  "INVESTED ",
                  "ATTEMPTED ",
                  "COST_MIN ",
                  "COST_MAX ",
                  "COST_PUBLIC ",
                  "TREATMENT"
                  }, ",", 1, "."));
         Logger.debugInto("INFO", "INFO/*");
         Logger.debugInto("WARNING", "INFO/*");
         Logger.debugInto("WARNING", "WARNING/*");
         Logger.debugInto("WARNING", "ERROR/*");
      } catch (Exception ex) {
         Debug.print("ERROR", Game.class, "log-files",
                  "failed to setup output directory");
         ex.printStackTrace();
         System.exit(1);
      }
   }


   public static synchronized NetworkPlayer
            makeNetworkPlayer(QueuedMessenger connection, String name) {
      int id;

      if ((id = NetworkPlayer.nextNetworkPlayer()) != -1) {
         return new NetworkPlayer(connection, name, id);
      } else {
         return null;
      }
   }


   public static void signal(String signal) {
      signal(signal, null);
   }


   public static void signal(String signal, Message data) {
      state.transition(signal, data);
   }


   static RobotPlayer forceClassIn;// Force class into server.jar


   public abstract static class Player {
      final String name, type;
      final int id;
      public int score = 0;
      public double payment = 0;
      protected int optimal_investment = -1;
      protected boolean invested = false;


      public Player(int id, String name, String type) {
         this.id = id;
         this.name = name;
         this.type = type;
         synchronized (Game.playerMonitor) {
            players[id] = this;
         }
      }


      public abstract void gameData(Message data);


      public final void invest() {
         Game.tryInvest(id);
      }


      public String toString() {
         return name + "[" + (id + 1) + "]";
      }
   }


   public static void flushOutput() {
      Logger.println("score_log.txt", "---------------------------------");
      for (int i = 0; i < players.length; i++) {
         Logger.println("score_log.txt",
                  players[i] + ": " + players[i].score + " --> " + (players[i].payment));
         Logger.tabulate("payment.csv",
                  new Message().set("player.id", i + 1)
                  .set("player.name", players[i].name)
                  .set("player.score", players[i].score)
                  .set("player.payment", players[i].payment));
      }

      Logger.close();
   }



   public static void tryInvest(int id) {
      if (!roundEnable.go()) {
         return;
      } else {
         synchronized (investmentMonitor) {
            Message playerData = Rules.getPlayerRoundConfig(id);
            ArrayList group = (ArrayList) playerData.get("group");
            long cost = Math.round(playerData.getd("cost"));
            Message rules = Rules.getCurrentRound();
            boolean allowIA = rules.getp("groups.allow.invest.attempts", false);
            investedValue = Math.round(value);

            //System.out.println("player " + id + " trys to invest. cost:" + cost + " value:" + value + " investedValue:" + investedValue);

            if (value > cost) {
               long score = Math.round(value - cost);

               if (groupInvested(id)) {
                  //someone in the group has invested already!
                  if (allowIA) {
                     //Investment attempts allowed, record and process failed attempt
                     Logger.println("log.txt", "" + timestamp() +
                              ": Player " + players[id] +
                              " attempted to invest unsucsessfully (would-be NPV = " + score + ")");

                     Message logMsg = new Message("log")
                              .set("timestamp", timestamp_round())
                              .set("round.id", Rules.getRoundID())
                              .set("value", value)
                              .set("value.high", highestValue)
                              .set("client.id", id + 1)
                              .set("client.type", players[id].type)
                              .set("group.id", playerData.geti("group.id") + 1)
                              .set("cost", playerData.geti("cost"))
                              .set("score", score)
                              .set("invested", players[id].invested)
                              .set("attempted", true)
                              .set("cost.public", rules.getz("cost.viewable.others"))
                              .set("cost.min", rules.geti("cost.mean") - rules.geti("cost.radius"))
                              .set("cost.max", rules.geti("cost.mean") + rules.geti("cost.radius"))
                              .set("optimal", players[id].optimal_investment)
                              .set("treatment", rules.getz("treatment", null));

                     Logger.tabulate("game.csv", logMsg);
                     Logger.tabulate("event.csv", logMsg);

                     playerData.set("failedAttempt", true)
                              .set("timeOfAttempt", Math.round(timestamp_round() / 10) / 100.0)
                              .set("valueAtAttempt", investedValue);

                     players[id].gameData(new Message("round.disable")
                              .set("message", "Investment Attempted!"));
                  }
               } else {
                  //no one in the group has invested yet, allow the investment
                  players[id].invested = true;

                  Logger.println("log.txt", "" + timestamp() +
                           ": Player " + players[id] +
                           " invested (NPV = " + score + ")");
                  
                  String attempted = "N/A";
                  if(allowIA)
                     attempted = String.valueOf(true);

                  Message logMsg = new Message("log")
                           .set("timestamp", timestamp_round())
                           .set("round.id", Rules.getRoundID())
                           .set("value", value)
                           .set("value.high", highestValue)
                           .set("client.id", id + 1)
                           .set("client.type", players[id].type)
                           .set("group.id", playerData.geti("group.id") + 1)
                           .set("cost", playerData.geti("cost"))
                           .set("score", score)
                           .set("invested", players[id].invested)
                           .set("attempted", attempted)
                           .set("cost.public", rules.getz("cost.viewable.others"))
                           .set("cost.min", rules.geti("cost.mean") -
                           rules.geti("cost.radius"))
                           .set("cost.max", rules.geti("cost.mean") +
                           rules.geti("cost.radius"))
                           .set("optimal", players[id].optimal_investment)
                           .set("treatment", rules.getz("treatment", null));

                  Logger.tabulate("game.csv", logMsg);
                  Logger.tabulate("event.csv", logMsg);

                  Logger.println("score_log.txt", players[id].name + " earned " + score);
                  playerData.set("score", score);

                  double pointValue = rules.getd("cents.per.point", 1);
                  double payment = score * pointValue / 100.0;// in dollars
                  playerData.set("payment", payment);

                  for (Iterator i = group.iterator(); i.hasNext(); ) {
                     Player member = (Player) i.next();
                     Message groupMemberData = Rules.getPlayerRoundConfig(member.id);
                     assert (playerData.geti("group.id") == groupMemberData.geti("group.id"));

                     if (allowIA) {
                        //investment attempts allowed, send generic investment message to investor
                        //don't disable rest of group
                        if (member.id == id) {
                           Rules.getPlayerRoundConfig(id).set("successfulAttempt", true)
                                    .set("timeOfAttempt", Math.round(timestamp_round() / 10) / 100.0)
                                    .set("valueAtAttempt", investedValue);
                           member.gameData(new Message("round.disable")
                                    .set("message", "Investment Attempted!"));
                        }
                     } else {
                        //investment made, inform investor and disable rest of group
                        if (member.id == id) {
                           member.gameData(new Message("round.disable")
                                    .set("message", "You earned " + score + " points!")
                                    .set("score", score)
                                    .set("totalScore", players[id].score)
                                    .set("investedValue", investedValue));
                        } else {
                           member.gameData(new Message("round.disable")
                                    .set("message", "Earned nothing this round.")
                                    .set("score", 0)
                                    .set("totalScore", players[member.id].score)
                                    .set("investedValue", investedValue));
                           Logger.println("log.txt", "" + timestamp() + ": " +
                                    member + " lost opportunity.");

                           logMsg.unset("value")
                                    .set("optimal", member.optimal_investment)
                                    .set("client.id", member.id + 1)
                                    .set("client.type", member.type)
                                    .set("group.id", groupMemberData.geti("group.id") + 1)
                                    .set("score", 0)
                                    .set("invested", false)
                                    .set("attempted", "N/A")
                                    .set("cost", groupMemberData.geti("cost"));
                           Logger.tabulate("game.csv", logMsg);
                           Logger.tabulate("event.csv", logMsg);
                        }
                     }
                  }
               }
            } else {
               //invalid investment - reenable players investment button
               players[id].gameData(new Message("round.enable"));
            }
         }
      }
   }


   public static boolean groupInvested(int id) {
      synchronized (investmentMonitor) {
         Message playerData = Rules.getPlayerRoundConfig(id);
         ArrayList group = (ArrayList) playerData.get("group");
         for (Iterator i = group.iterator(); i.hasNext(); ) {
            Player member = (Player) i.next();
            if (member.invested == true) {
               return true;
            }
         }
         return false;
      }
   }


   public static void broadcast(Message message) {
      for (int i = 0; i < Rules.getGameConfig().geti("players"); i++) {
         Player player = (Player) players[i];
         if (player == null) {
            continue;
         }
         player.gameData(message);
      }
   }


   public static void nextRound(Message unused) {
      Message nextRound = Rules.getNextRound();
      Logger.println("log.txt", "" + timestamp() +
               ": Next round fetched");
      if (nextRound == null) {
         Terminal.message("No next round...");
         Game.signal("round.cancel");
      } else {
         startRound(unused);
      }
   }


   public static void cancelRound(Message unused) {
      Logger.println("log.txt", "" + timestamp() + ": Round " + Rules.getRoundID() +
               " Cancelled");
      roundEnable.stop();
      Logger.println("game.csv", "### Round " + Rules.getRoundID() + " Cancelled ###");
      Logger.println("event.csv", "### Round " + Rules.getRoundID() + " Cancelled ###");
      broadcast(new Message("round.end").set("round.complete", false));
   }


   static Date startTime = new Date();

   static Date startTime_round;


   static long timestamp_round() {
      Date now = new Date();
      long answer = 0;
      if (startTime_round != null) {
         answer = now.getTime() - startTime_round.getTime();
      }
      return answer;
   }


   static long timestamp() {
      Date now = new Date();
      long answer = 0;
      if (startTime != null) {
         answer = now.getTime() - startTime.getTime();
      }
      return answer;
   }


   static Random tickRandom = new Random();
   static double value, highestValue;

   private static double[] values = null;
   private static double[] costs = null;
   private static int preStartTicks = 0;
   private static int viewableTicks = 200;


   public static double[] getCosts() {
      return costs;
   }


   private static String[] commasplit(String s) {
      StringTokenizer st = new StringTokenizer(s, ", ");
      String[] tokens = new String[st.countTokens()];
      for (int i = 0; i < tokens.length; i++) {
         tokens[i] = st.nextToken();
      }
      return tokens;
   }


   private static int findColumn(String[] columns, String name) {
      int column;
      for (column = 0; column < columns.length; column++) {
         if (columns[column].equals(name)) {
            break;
         }
      }

      if (column == columns.length) {
         column = -1;
      }

      return column;
   }


   private static double[] makeUpValues(int ticks, double chance, int step, double percentToStep) {
      double value;
      values = new double[ticks];
      int maxvalue = Rules.getCurrentRound().geti("value.max", -1);

      if (Rules.getCurrentRound().getp("value.initial.at_cost", false)) {
         values[0] = value = costs[0];
      } //FIXME
      else {
         values[0] = value = Rules.getCurrentRound().getf("value.initial", 50);
      }

      for (int i = 1; i < ticks; i++) {
         if (percentToStep != -1) {
            if (tickRandom.nextDouble() < chance) {
               value = (1 + (percentToStep / 100.0)) * value;
            } else {
               value = (1 - (percentToStep / 100.0)) * value;
            }
         } else {
            value +=
                     (tickRandom.nextDouble() < chance
                     ? step
                     : -step);
         }
         if (value < 0) {
            value = 0;
         }
         if ((maxvalue != -1) && (value > maxvalue)) {
            value = maxvalue;
         }
         values[i] = value;
      }

      return values;
   }


   private static double[] valuesFromData(
            String dataname, String roundName, String indexName,
            String valueName, int indexOffset) {
      double[] values = null;
      String filename;

      if (dataname.indexOf(":") == -1) {
         filename = dataname;
         dataname = "" + Rules.getRoundID();
      } else {
         filename = dataname.substring(0, dataname.indexOf(":"));
         dataname = dataname.substring(dataname.indexOf(":") + 1);
      }
      try {
         BufferedReader reader = new BufferedReader(
                  new FileReader(filename));
         ArrayList valuesArray = new ArrayList();

         String[] header = commasplit(reader.readLine());
         String line;

         int target = Integer.parseInt(dataname);
         int roundID;
         int indexID;
         int valueID;

         roundID = findColumn(header, roundName);
         indexID = findColumn(header, indexName);
         valueID = findColumn(header, valueName);
         while ((line = reader.readLine()) != null) {
            if (line.startsWith("#")) {
               continue;
            }
            String[] data = commasplit(line);
            int round;
            int index;
            double value;
            try {
               round = Integer.parseInt(data[roundID]);
               index = Integer.parseInt(data[indexID]) + indexOffset;
               value = Double.parseDouble(data[valueID]);
            } catch (NumberFormatException ex) {
               continue;// and ignore
            }
            if (round == target) {
               if (index >= 0) {
                  if (valuesArray.size() == index) {
                     valuesArray.add(new Double(value));
                  } else if (valuesArray.size() > index) {
                     valuesArray.set(index, new Double(value));
                  }
               }
            }
         }

         values = new double[valuesArray.size()];
         for (int i = 0; i < values.length; i++) {
            values[i] = ((Double) valuesArray.get(i)).doubleValue();
         }
      } catch (Exception ex) {
         Debug.print("ERROR", Game.class, "read-values",
                  ex.toString());
         ex.printStackTrace();
         Game.signal("round.cancel");
      }

      return values;
   }


   public static int calculateCostForPlayer(
            int player, int meanCost, int radius) {
      Message playerConfig = Rules.getPlayerConfig(player);

      meanCost = playerConfig.geti("cost.mean", meanCost);
      radius = playerConfig.geti("cost.radius", radius);

      return meanCost
               + (int) ((2.0 * tickRandom.nextDouble() - 1.0) * radius);
   }


   public static double[] makeUpCosts(int players, boolean sameForAll, int meanCost, int radius) {
      double[] costs = new double[players];
      for (int i = 0; i < costs.length; i++) {
         if (sameForAll && i > 0) {// make all players have same cost
            costs[i] = costs[0];
         } else {
            costs[i] = calculateCostForPlayer(i, meanCost, radius);
         }
      }
      return costs;
   }


   public static int ticksBasedOnProb(double prob, int min, int max) {
      int ticks = min;
      while (tickRandom.nextDouble() > prob) {
         ticks++;
      }
      if ((max > min) && (ticks > max)) {
         ticks = max;
      }
      return ticks;
   }


   public static void calculateValuesAndCosts() {
      Message currentRound = Rules.getCurrentRound();

      preStartTicks = currentRound.geti("ticks.prestart", 0);
      viewableTicks = currentRound.geti("ticks.viewable", 200);

      if (!currentRound.has("costs")) {
         costs = makeUpCosts(players.length,
                  currentRound.getp("cost.same_for_all_players", false),
                  currentRound.geti("cost.mean"),
                  currentRound.geti("cost.radius"));
      } else {
         costs = valuesFromData(
                  currentRound.getz("costs"), "ROUND", "ID", "COST", -1);
      }

      if (!currentRound.has("values")) {
         int ticks;
         double chance = currentRound.getd("value.step.chance", .5);
         int step = currentRound.geti("value.step", 5);
         double percentToStep = currentRound.getd("value.step.percent", -1);
         int maxvalue = currentRound.geti("value.max", -1);
         if (currentRound.has("ticks.end.prob")) {
            int min = currentRound.geti("ticks.end.min", 0);
            int max = currentRound.geti("ticks.end.max", -1);
            ticks = ticksBasedOnProb(currentRound.getd("ticks.end.prob"),
                     preStartTicks + min, preStartTicks + max);
         } else {
            ticks = currentRound.geti("ticks");
         }
         values = makeUpValues(ticks, chance, step, percentToStep);
      } else {
         values = valuesFromData(
                  currentRound.getz("values"), "ROUND", "TICK", "VALUE", 0);
      }

      currentRound.set("ticks", values.length);

   }


   private static void doTick(int tick) {
      synchronized (investmentMonitor) {
         value = values[tick];
         if (value > highestValue) {
            highestValue = value;
         }
         currNumTicks++;
      }

      Logger.tabulate("game.csv",
               new Message("log")
               .set("timestamp", timestamp_round())
               .set("round.id", Rules.getRoundID())
               .set("tick", tick)
               .set("value", value));

      broadcast(new Message("round.tick")
               .set("value", value));
   }


   private static ThreadControl roundEnable = new ThreadControl();


   public static void startTicking() {
      roundEnable.start();
         new Thread() {
            public synchronized void run() {
               for (int player = 0; player < players.length; player++) {
                  players[player].invested = false;
               }
               int tick = 0;
               Delay delay = new Delay();
               int ticks = Rules.getCurrentRound()
                        .geti("ticks");
               int ticktime = Rules.getCurrentRound()
                        .geti("tick.duration.ms", 2000);
               if (preStartTicks > 0) {
                  System.err.println("\nsend leading ticks");
                  for (; tick < preStartTicks; tick++) {
                     long value = Math.round(values[tick]);

                     broadcast(new Message("round.tick")
                              .set("value", value));

                     Logger.tabulate("game.csv",
                              new Message("log")
                              .set("round.id", Rules.getRoundID())
                              .set("tick", tick)
                              .set("value", value));
                  }
               }

               Terminal.message("\nRound " + Rules.getRoundID() + " started.");

               delay.sleep(3000);
               broadcast(new Message("round.enable"));
               delay.sleep(1000);

               startTime_round = new Date();// set startTime of new round

               currNumTicks = 0;
               investedValue = 0;

               for (; tick < ticks && !allFinished(); tick++) {
                  if (!roundEnable.go()) {
                     return;
                  }
                  delay.mark();
                  doTick(tick);
                  delay.sleep(ticktime);
               }

               Game.signal("round.end");
            }
         }.start();
   }


   private static boolean allFinished() {
      if (Rules.getCurrentRound().getp("quickstop", false) == false) {
         return false;
      }
      int numFinished = 0;
      for (Enumeration e = groups.keys(); e.hasMoreElements(); ) {
         Integer groupID = (Integer) e.nextElement();
         ArrayList group = (ArrayList) groups.get(groupID);
         boolean groupDone = false;
         for (int i = 0; i < group.size(); i++) {
            Player player = (Player) group.get(i);
            if (player.invested) {
               groupDone = true;
            }
         }
         if (groupDone) {
            numFinished++;
         }
      }
      return (numFinished == groups.size());
   }


   private static Hashtable makeGroups(Message currentRound) {
      Hashtable result = null;
      if (currentRound.has("groups")) {// input file used to make groups
         //result = groupsFromData( //FIXME
         //        currentRound.getz("groups"), "ROUND", "ID", "", -1);
      } else {// make groups from player config
         result = groupsFromConfig(currentRound);
      }
      return result;
   }


   private static Hashtable groupsFromConfig(Message currentRound) {
      Hashtable result = new Hashtable();
      Hashtable playersNeedGroup = new Hashtable();
      Hashtable robotsNeedGroup = new Hashtable();
      // check if we need to distinguish robots from humans to put robots last
      if (currentRound.getp("groups.random.robots.with.remainder")) {
         for (int i = 0; i < players.length; i++) {
            if (players[i].type.equals("robot")) {
               robotsNeedGroup.put(new Integer(i), players[i]);
            } else {
               playersNeedGroup.put(new Integer(i), players[i]);
            }
         }
      } else {
         for (int i = 0; i < players.length; i++) {// no need to distinguish
            playersNeedGroup.put(new Integer(i), players[i]);
         }
      }

      // Now check for config file group specification for any player
      for (int playerID = 0; playerID < players.length; playerID++) {
         Message playerData = Rules.getPlayerRoundConfig(playerID);
         if (playerData.has("group.id")) {
            Integer groupID = new Integer(playerData.geti("group.id") - 1);
            ArrayList group;
            if (result.containsKey(groupID)) {
               group = (ArrayList) result.get(groupID);
            } else {
               group = new ArrayList();
               result.put(groupID, group);
            }
            Player player =
                     (Player) playersNeedGroup.remove(new Integer(playerID));
            if (player == null) {
               player =
                        (Player) robotsNeedGroup.remove(new Integer(playerID));
            }
            if (player == null) {
               System.err.println("Config can not set group for player " +
                        (playerID + 1));
            } else {
               group.add(player);
            }
         }
      }

      // Now do random groups for unspecified players from config file
      Random random = new Random();
      int groupSize = currentRound.geti("groups.random.size", 1);
      if (groupSize < 1) {
         groupSize = 1;
      }

      // NOTE:  max number of groups is the total players in game
      for (int i = 0; i < players.length; i++) {
         if (playersNeedGroup.isEmpty() && robotsNeedGroup.isEmpty()) {
            break;
         }
         Integer groupID = new Integer(i);
         ArrayList group;

         if (result.containsKey(groupID)) {
            group = (ArrayList) result.get(groupID);
         } else {
            group = new ArrayList();
            result.put(groupID, group);
         }
         while (group.size() < groupSize) {
            if (!playersNeedGroup.isEmpty()) {
               Enumeration e = playersNeedGroup.keys();
               int pick =
                        Math.abs(random.nextInt()) % playersNeedGroup.size();
               Integer key = null;
               while (pick >= 0) {
                  key = (Integer) e.nextElement();
                  pick--;
               }
               group.add(playersNeedGroup.remove(key));
            } else if (!robotsNeedGroup.isEmpty()) {
               Enumeration e = robotsNeedGroup.keys();
               int pick =
                        Math.abs(random.nextInt()) % robotsNeedGroup.size();
               Integer key = null;
               while (pick >= 0) {
                  key = (Integer) e.nextElement();
                  pick--;
               }
               group.add(robotsNeedGroup.remove(key));
            } else {
               break;
            }// Must break in case the last group can not fill
         }
      }
      return result;
   }


   public static void configurePlayer(Player player, Message playerData) {
      Message roundData = Rules.getCurrentRound();

      // set total score if config file indicates to do so
      if (playerData.has("player.score")) {
         player.score = playerData.geti("player.score");
      }
      playerData.set("score", 0);// reset score this round
      playerData.set("payment", 0);// reset $ payment for this round

      playerData.set("cost", Math.round(costs[player.id]));

      playerData.set("cost.viewable.others", new Message("shadowp")
               .adopt("cost.viewable.others", roundData)
               .adopt("cost.viewable.others", playerData)
               .getp("cost.viewable.others", true));

      if (roundData.has("cost.possible.shadow") &&
               roundData.getp("cost.possible.shadow", true)) {
         String shadowPossible = roundData.getTS("cost.possible.shadow", "true");
         Range range;

         if (shadowPossible.indexOf(':') != -1) {
            range = Range.parseRange(shadowPossible);
         } else {
            int roundCostBase = roundData.geti("cost.mean", 0);
            int roundCostVar = roundData.geti("cost.radius", 0);
            range = new Range(roundCostBase - roundCostVar,
                     roundCostBase + roundCostVar);
         }

         playerData.set("cost.possible.shadow", range);
      }
   }


   public static void configureGroup(ArrayList group, int id) {
      double[] costs = new double[group.size()];
      for (int i = 0; i < group.size(); i++) {
         Player player = (Player) group.get(i);
         Message playerData = Rules.getPlayerRoundConfig(player.id);
         costs[i] = playerData.geti("cost");
         playerData.set("cost.shadow", costs);
         playerData.set("group", group);
         playerData.set("group.id", id);
      }
   }


   static Hashtable groups;


   public static void startRound(Message unused) {
      Logger.println("log.txt", "" + timestamp() +
               ": Round " + Rules.getRoundID() + " started");

      highestValue = 0;// Reset highest value so far
      calculateValuesAndCosts();

      for (int i = 0; i < Rules.getGameConfig().geti("players"); i++) {
         Player player = players[i];
         Message playerData = Rules.getPlayerRoundConfig(i);
         configurePlayer(player, playerData);
      }

      groups = makeGroups(Rules.getCurrentRound());

      for (Enumeration e = groups.keys(); e.hasMoreElements(); ) {
         Integer groupID = (Integer) e.nextElement();
         ArrayList group = (ArrayList) groups.get(groupID);
         configureGroup(group, groupID.intValue());
      }

      Message currentRound = Rules.getCurrentRound();
      for (int i = 0; i < Rules.getGameConfig().geti("players"); i++) {
         Message playerConfig = Rules.getPlayerRoundConfig(i);
         Message logMsg = new Message()
                  .adopt("cost", playerConfig)
                  .set("client.id", i + 1)
                  .set("round.id", Rules.getRoundID())
                  .set("group.id", playerConfig.geti("group.id") + 1)
                  .set("groups.random.size", currentRound.geti("groups.random.size"))
                  .set("cost.min", currentRound.geti("cost.mean") -
                  currentRound.geti("cost.radius"))
                  .set("cost.max", currentRound.geti("cost.mean") +
                  currentRound.geti("cost.radius"))
                  .set("cost.public", currentRound.getz("cost.viewable.others"))
                  .set("treatment", currentRound.getz("treatment", null));
         Logger.tabulate("game.csv", logMsg);
      }

      for (int i = 0; i < Rules.getGameConfig().geti("players"); i++) {
         Player player = players[i];
         int ticks = Rules.getCurrentRound()
                  .geti("ticks");

         Message playerData = Rules.getPlayerRoundConfig(i);
         boolean shadow = playerData.getp("cost.viewable.others");
         Message startMsg = new Message("round.start")
                  .adopt(Rules.getCurrentRound().extract("opt."))
                  .adopt(playerData.extract("opt."))
                  .adopt("cost", playerData)
                  .adopt("cost.possible.shadow", playerData)
                  .adopt("opt.plot.yaxis.max", playerData)
                  .adopt("tick.duration.ms", Rules.getCurrentRound())
                  .set("ticks.viewable", viewableTicks)
                  .set("cost.shadow", shadow
                  ? playerData.get("cost.shadow")
                  : new double[0])
                  .set("ticks", ticks)
                  .set("totalScore", player.score)
                  .set("players", Rules.getGameConfig().geti("players"))
                  .set("groupSize", ((ArrayList) playerData.get("group")).size())
                  .set("round", Rules.getRoundID())
                  .set("cost.viewable.others",
                  Rules.getCurrentRound().getp("cost.viewable.others"))
                  .set("value.initial", Rules.getCurrentRound().geti("value.initial", 0));
         player.optimal_investment = NashEquilibrium.getInvestTarget(startMsg);
         player.gameData(startMsg);
      }

      Logger.tabulate("round.csv", Rules.getCurrentRound()
               .copy().set("timestamp", timestamp())
               .set("cost.min", currentRound.geti("cost.mean") -
               currentRound.geti("cost.radius"))
               .set("cost.max", currentRound.geti("cost.mean") +
               currentRound.geti("cost.radius")));
      value = Rules.getCurrentRound().geti("value.initial", 0);
      startTicking();
   }


   public static void gameReady(Message unused) {
      if (Terminal.ready()) {
         Terminal.message("All players connected.");
      }
   }


   public static void endRound(Message unused) {

      Logger.println("log.txt", "" + timestamp() +
               ": Round " + Rules.getRoundID() + " ended");
      Message endMsg = new Message("round.end");

      int winningScore = 0;
      int roundTime = Math.round(((float) currNumTicks * (float) Rules.getCurrentRound().geti("tick.duration.ms")) / 1000);

      for (int i = 0; i < players.length; i++) {
         Message playerData = Rules.getPlayerRoundConfig(i);
         if (playerData.geti("score", 0) > 0) {
            winningScore = playerData.geti("score");
         }
      }
      Message rules = Rules.getCurrentRound();
      long timestamp = timestamp_round();
      for (int id = 0; id < players.length; id++) {
         Message playerData = Rules.getPlayerRoundConfig(id);
         players[id].score += playerData.geti("score", 0);
         players[id].payment += playerData.getd("payment", 0);

         int winningValue = 0;

         ColorString table = new ColorString();

         table.append("           | ATTEMPTED INVESTMENT |\n");
         table.append("           |----------------------|\n");
         table.append("|   Cost   |   Value   |   Time   |\n");
         table.append("|---------------------------------|\n");

         ArrayList group = (ArrayList) playerData.get("group");

         Collections.sort(group, new PlayerByCostComparator());

         for (Iterator i = group.iterator(); i.hasNext(); ) {
            Player member = (Player) i.next();
            Message playerDataI = Rules.getPlayerRoundConfig(member.id);

            boolean bold = false;
            String color = null;

            if (member.id == id) {
               bold = true;
               color = "330066";
            }

            if (players[member.id].invested) {
               color = "00AA00";
               winningValue = playerDataI.geti("valueAtAttempt", 0);
            }

            table.append("|" + Padder.padC(playerDataI.geti("cost"), 10), color, null, bold);
            int value = playerDataI.geti("valueAtAttempt", -1);
            table.append("|" + Padder.padC((value == -1 ? "." : String.valueOf(value)), 11), color, null, bold);
            double time = playerDataI.getd("timeOfAttempt", -1);
            table.append("|" + Padder.padC((time == -1 ? "." : String.valueOf(time)), 10) + "|", color, null, bold);

            if (players[member.id].invested) {
               table.append("$", color, null, bold);
            }

            if (bold) {
               table.append("*", color, null, bold);
            }

            table.append("\n");
         }
         table.append("|---------------------------------|\n");
         table.append("|  [END]   ");
         table.append("|" + Padder.padC(".", 11));
         table.append("|" + Padder.padC(String.valueOf(Math.round(timestamp / 10) / 100.0), 10) + "|\n");
         table.append("|---------------------------------|\n");

         if (!players[id].invested && !playerData.getp("failedAttempt",false)) {
            
            String attempted = "N/A";
            if(rules.getp("groups.allow.invest.attempts", false))
                     attempted = String.valueOf(false);
            
            Message logMsg = new Message("log")
                     .set("timestamp", timestamp)
                     .set("round.id", Rules.getRoundID())
                     .set("value", value)
                     .set("value.high", highestValue)
                     .set("client.id", id + 1)
                     .set("client.type", players[id].type)
                     .set("group.id", playerData.geti("group.id") + 1)
                     .set("cost", playerData.geti("cost"))
                     .set("score", 0)
                     .set("invested", players[id].invested)
                     .set("attempted", attempted)
                     .set("optimal", players[id].optimal_investment)
                     .set("groups.random.size", rules.geti("groups.random.size"))
                     .set("cost.public", rules.getz("cost.viewable.others"))
                     .set("cost.min", rules.geti("cost.mean") -
                     rules.geti("cost.radius"))
                     .set("cost.max", rules.geti("cost.mean") +
                     rules.geti("cost.radius"))
                     .set("treatment", rules.getz("treatment", null));

            Logger.tabulate("game.csv", logMsg);
            Logger.tabulate("event.csv", logMsg);
         }
         //System.out.println(table.toHTMLString(false));
         players[id].gameData(
                  endMsg.set("round.complete", true)
                  .set("round.id", Rules.getRoundID())
                  .set("roundTime", roundTime)
                  .set("winningScore", winningScore)
                  .set("winningValue", winningValue)
                  .set("totalScore", players[id].score)
                  .set("score", playerData.geti("score"))
                  .set("invested", players[id].invested)
                  .set("AllowInvestAttempts", rules.getp("groups.allow.invest.attempts", false))
                  .set("groupSize", ((ArrayList) playerData.get("group")).size())
                  .set("resultsTable", table.toHTMLString(false)));
      }

      Messenger.reset(null);
      roundEnable.stop();
      Delay delay = new Delay();
      delay.sleep(500);// just to make sure all investments are in before round end

      String logMsg = new String("### Round " + Rules.getRoundID() + " Ended ###  All Players Finished = " + allFinished());
      Logger.println("game.csv", logMsg);
      Logger.println("event.csv", logMsg);
      Terminal.message("\nRound " + Rules.getRoundID() + " is over.");
   }


   public static void reprompt(Message unused) {
      if (Terminal.ready()) {
         Terminal.shell.setPrompt(state.getStateNow() + "> ");
      }
   }


   public static void quitGame(Message unused) {
      Logger.println("log.txt", "" + timestamp() + ": Game ended");
      try {
         Game.broadcast(new Message("game.over"));
         Game.flushOutput();
      } finally {
         Terminal.shell.stop();
         System.exit(0);
      }
   }

   // autorun implementation
   private final static ThreadControl autoControl = new ThreadControl(false);
   // set this to true for a one-time disable of the next autorun.
   private static boolean autoLock = false;
   private final static Thread autoThread;
   static {
      autoThread =
         new Thread() {
            public void run() {
               Message roundConfig = new Message();
               for (; ; ) {
                  autoControl.pause();
                  if (updateConfig) {
                     Rules.reconfigure();
                     Terminal.message("Game configuration updated!");
                  }
                  updateConfig = false;
                  roundConfig = Rules.previewNextRound();
                  if ((roundConfig == null) ||
                           roundConfig.getz("autorun", "false").equals("false")) {
                     autoControl.stop();
                     continue;
                  }
                  if (autoLock) {
                     autoLock = false;
                     continue;
                  }
                  long time = roundConfig.getl("autorun.wait", 5) * 1000;
                  System.out.println("Starting Round " + (Rules.getRoundID() + 1) +
                           " in " + (time / 1000) + " seconds\n" +
                           "--> use 'autostop' to bypass");
                  if (autoControl.go(time)) {
                     System.out.println("Starting Round " +
                              (Rules.getRoundID() + 1) + "!");
                     state.transition("round.autostart");
                  }
               }
            }
         };

      autoThread.setDaemon(true);
      autoThread.start();
   }


   public static void autoStart(Message x) {
      autoControl.start();
   }


   public static void autoLock(Message x) {
      autoControl.stop();
      autoLock = true;
   }


   public static void autoStop(Message x) {
      autoControl.stop();
   }


   /**
    * updateConfig will update the configuration with the latest version
    * of the config file.  The game will be reconfigured
    * either right away if a round is not currently running, or
    * after the current round is finished.
    */
   private static boolean updateConfig = false;


   public static void updateConfig(Message x) {
      if (!roundEnable.go()) {// if not mid-round
         Rules.reconfigure();// update configuration now
         Terminal.message("Game configuration updated!");
      } else {
         updateConfig = true;// else set to update after round over
         Terminal.message("Game configuration will be updated after round ends.");
      }
   }

}

class PlayerByCostComparator implements Comparator {


   public final int compare(Object a, Object b) {

      Game.Player p1 = (Game.Player) a;
      Message playerData1 = Rules.getPlayerRoundConfig(p1.id);
      int cost1 = playerData1.geti("cost");

      Game.Player p2 = (Game.Player) b;
      Message playerData2 = Rules.getPlayerRoundConfig(p2.id);
      int cost2 = playerData2.geti("cost");

      return cost1 - cost2;
   }
}

