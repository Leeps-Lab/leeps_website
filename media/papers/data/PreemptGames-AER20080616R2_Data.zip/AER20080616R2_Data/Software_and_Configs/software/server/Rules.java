package leeps.it.server;
import leeps.utility.text.XMLSMReader;
import leeps.utility.io.InputStreamScanner;
import leeps.utility.data.Message;
import leeps.utility.Debug;
import leeps.utility.Range;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import leeps.utility.Delay;

public class Rules {
    static final XMLSMReader xmlReader;
    static String configFile = null;
    static Rules configuration;

    static {
        XMLSMReader reader = null;
        try {
            reader = new XMLSMReader(
                    new InputStreamScanner(
                        Rules.class.getResourceAsStream("rules.stm")),
                    Rules.class);

            reader.setMessageConverter(
                    XMLSMReader.lowercaseMessageConverter);
        } catch (Exception ex) {
            Debug.print("ERROR", Rules.class, "static-init",
                    "Could not initialize Rules: " + ex.getMessage());
            System.exit(1);
        } finally {
            xmlReader = reader;
        }
    }

    static boolean setConfigFile(String configFile) {
        Rules.configFile = configFile;
        return reconfigure();
    }

    static boolean reconfigure() {
        Rules config = new Rules();
        if(!xmlReader.readFile(configFile, config)) {
            Debug.print("WARNING", Rules.class, "reconfigure",
                    "Failed to parse configFile.");
            return false;
        } else {
            configuration = config;
            return true;
        }
    }

    static Message getCurrentRound() {
        return configuration.getRound(roundID);
    }

    static Message getNextRound() {
        return configuration.getRound(++roundID);
    }

    static Message previewNextRound() {
        return configuration.getRound(roundID + 1);
    }

    static Message getPlayerConfig(int i) {
        return configuration.playerGlobal[i];
    }

    static Message getPlayerRoundConfig(int player) {
        Message[] playerConfig = 
            (Message[])getCurrentRound().get("players.config");
        if(player >= 0 && player < playerConfig.length)
            return playerConfig[player];
        else
            return null;
    }

    public static Message getGameConfig() { 
        return configuration.gameConfig; 
    }

    private static int roundID = 0;

    private static Message nextRound() {
        return configuration.getRound(++roundID);
    }

    /*-- Dymanic code --*/
    private Message[] rounds;
    private Message[] playerGlobal;
    private Message gameConfig;

    static int getRoundID() { 
        return roundID; 
    }

    private Message getRound(int roundID) {
        return roundID <= rounds.length 
            ? rounds[roundID-1] 
            : null;
    }

    /*-- XML Parsing Handler code follows --*/
    public void GAME(Message info) {
        int players;
        gameConfig = info;
        try {
            info.adopt(readDeploy(info.getz("deploy.file", "deploy.conf")));
        } catch(Exception ex) {
            Debug.print("ERROR", Rules.class, "read-deploy",
                    "Failed to read deploy file: " + ex.getMessage());
            ex.printStackTrace();
            System.exit(1);
        }

        rounds = new Message[info.geti("rounds")];
        players = info.geti("players");
        playerGlobal = new Message[players];

        for(int i = 0; i < rounds.length; i++) {
            Message[] playerArray = new Message[players];

            for(int p = 0; p < players; p++) {
                playerArray[p] = new Message("player.config");
            }

            rounds[i] = new Message("round")
                .set("players.config", playerArray)
                .set("round.id", i+1);
        }

        for(int p = 0; p < players; p++) {
            playerGlobal[p] = new Message("player.global");
        }
    }

    Range[] whichRounds = null;

    public void ROUND(Message info) {
        whichRounds = Range.parseRangeList(info.getz("id", "*"),
                "1:" + rounds.length);
        for(int r = 0; r < whichRounds.length; r++)
        for(int i = whichRounds[r].start; i <= whichRounds[r].end; i++) 
            if(i >= 1 && i <= rounds.length)
                rounds[i-1].adopt(info);
    }

    public void ROUND_END(Message info) {
        whichRounds = null;
    }

    public void PLAYER_GLOBAL(Message info) {
        Range[] whichPlayers = Range.parseRangeList(info.getz("id", "*"),
                "1:" + playerGlobal.length);
        for(int r = 0; r < whichPlayers.length; r++)
        for(int i = whichPlayers[r].start; i <= whichPlayers[r].end; i++) {
            if(i >= 1 && i <= playerGlobal.length) {
                playerGlobal[i-1].adopt(info);
            }
        }
    }

    public void PLAYER_IN_ROUND(Message info) {
        Range[] whichPlayers = Range.parseRangeList(info.getz("id", "*"),
                "1:" + playerGlobal.length);
        for(int rp = 0; rp < whichRounds.length; rp++)
        for(int ip = whichRounds[rp].start; ip <= whichRounds[rp].end; ip++) 
        for(int r = 0; r < whichPlayers.length; r++)
        for(int i = whichPlayers[r].start; i <= whichPlayers[r].end; i++) {
            if(ip >= 1 && ip <= rounds.length) {
                Message[] playerArray = 
                    (Message[])rounds[ip-1].get("players.config");
                if(i >= 1 && i <= playerArray.length) {
                    playerArray[i-1].adopt(info);
                }
            }
        }
    }

    private static String readFile(String file) throws IOException {
        StringBuffer buf = new StringBuffer();
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        while((line = reader.readLine()) != null) {
            buf.append(line);
        }
        return new String(buf);
    }

    private static Message readDeploy(String deploy)
        throws IOException {
        Message deployData = new Message();
        BufferedReader input = new BufferedReader(new FileReader(deploy));
        String line;
        while((line = input.readLine()) != null) {
            line = line.trim();
            int colon = line.indexOf(":");
            if(line.startsWith("#") || line.length() == 0 || colon == -1) 
                continue;
            String key = line.substring(0,colon).trim();
            String value = line.substring(colon+1).trim();
            /* // :: no one uses this code, so away it goes ::
              if(value.startsWith("@"))
                   value = readFile(value.substring(1));
            */
            deployData.set("deploy." + key, value);
        }
        return deployData;
    }

}
