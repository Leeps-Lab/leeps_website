package leeps.it.server;
import leeps.utility.CommandShell;
import leeps.utility.data.Message;
import leeps.utility.text.Tabulate;
import leeps.utility.Debug;
import leeps.utility.MemoryBar;
import leeps.utility.Logger;

public class Terminal {
    public static CommandShell shell;
    public static void doCommandLine() {
        shell = new CommandShell(
                System.in, System.out, System.err, 
                Game.state.getStateNow() + "> ", false);
        shell.setMethodHandler(Terminal.class, null);
        shell.setEOFCommand("quit");
        shell.run();
    }

    public static boolean command_quit(String[] args, CommandShell shell) {
        Game.signal("quit");
        Game.state.sync();
        return true;
    }

   
    public static boolean ready() { return shell != null; }

    private static int winwidth() {
        int winwidth = 80;
        if(leeps.utility.terminal.Terminal.loaded) {
            try {
                leeps.utility.terminal.Terminal.Winsize winsize
                    = leeps.utility.terminal.Terminal.getwinsize();
                // sanity check:
                if(winsize.col > 5 && winsize.col < 300) 
                    winwidth = winsize.col;
            } catch(Exception ex) {
            }
        }
        return winwidth;
    }

    public static boolean command_sinfo(String[] args, CommandShell shell) {
        shell.out.println(MemoryBar.makeTime(Game.startTime));
        shell.out.println(MemoryBar.memoryBar("Memory: ", winwidth()));
        shell.out.println("Game Config: " + 
                Server.commandLineConfig.getz("config.file"));
        shell.out.println("Output Files: " + Logger.listFiles());
        return true;
    }

    public static boolean command_rinfo(String[] args, CommandShell shell) {
        try {
            Message currentRound = Rules.getCurrentRound();
            if(args.length > 0) {
                if(args[0].equals("full")) {
                    shell.out.println("Full round config ::\n" + currentRound);
                }
            } else {
                shell.out.println("Round : " + currentRound.geti("round.id"));
                if (currentRound.getz("autorun").equals("true"))
                    shell.out.println("AutoRun: true (" + 
                        currentRound.geti("autorun.wait",5)+" second wait)");
                else shell.out.println("AutoRun: false");
                shell.out.println("Number of ticks : " + currentRound.geti("ticks"));
                shell.out.println("Ticks duration : " + currentRound.geti("tick.duration.ms"));
                shell.out.println("Groupsize : " + currentRound.geti("groups.random.size"));
                shell.out.println("Competitors costs viewable : " + currentRound.getp("cost.viewable.others"));
            }
        } catch(ArrayIndexOutOfBoundsException ex) {
            shell.out.println("Error: Round config not initialized");
            return false;
        }
        return true;
    }

    static Tabulate cinfo_display = new Tabulate(
            new String[] {
                "player.id",
                "player.name",
                "player.score",
                "player.cost",
                "player.invested"
            }, new String[] {
                "ID  ",
                "NAME               ",
                "SCORE  ",
                "COST  ",
                "INVESTED"
            });

    public static boolean command_cinfo(String[] args, CommandShell shell) {
        try {
            for(int i = 0; i < Game.players.length; i++) {
                if(Game.players[i] == null) {
                    shell.out.println("Error: Config for player " + i + " not initialized");
                    return false;
                }
            }
            shell.out.println(cinfo_display.header());
            Message playerStatus = new Message();
            for(int i = 0; i < Game.players.length; i++) {
                playerStatus.set("player.id", Game.players[i].id + 1);
                playerStatus.set("player.name", Game.players[i].name);
                playerStatus.set("player.score", Game.players[i].score);
                playerStatus.set("player.cost", Rules.getPlayerRoundConfig(i).geti("cost"));
                playerStatus.set("player.invested", Game.players[i].invested);
                shell.out.println(cinfo_display.row(playerStatus));
            }
        }
        catch(ArrayIndexOutOfBoundsException ex) {
            shell.out.println("Error: Player configs not initialized");
            return false;
        }
            return true;
    }

    public static boolean command_gc(String[] args, CommandShell shell) {
        shell.out.println(MemoryBar.memoryBar("Before GC: ", winwidth()));
        System.gc();
        shell.out.println(MemoryBar.memoryBar("After GC: ", winwidth()));
        return true;
    }

    public static void message(String message) {
        shell.show(message);
    }

    public static boolean command_go(String[] args, CommandShell shell) {
        Game.signal("round.start");
        return true;
    }

    public static boolean command_stop(String[] args, CommandShell shell) {
        Game.signal("round.cancel");
        return true;
    }

    public static boolean command_autostop(String[] args, CommandShell shell) {
        Game.signal("autostop");
        return true;
    }

    public static boolean command_debug(String[] args, CommandShell shell) {
        for(int i = 0; i < args.length; i++)
            Debug.configure(args[i]);
        return true;
    }

    public static boolean command_update(String[] args, CommandShell shell) {
        Game.signal("updateConfig");
        return true;
    }
    
    public static boolean command_help(String[] args, CommandShell shell) {
        shell.out.println(
             "help     -- display this help\n" +
             "go       -- run the next round\n" +
             "stop     -- stop the current round\n" +
             "autostop -- pause autorun for 1 round\n" +
             "sinfo    -- display info about the server\n" +
             "rinfo    -- display info about a round\n" +
             "              (try \"rinfo full\" for more info)\n" +
             "cinfo    -- display info about all clients\n" +
             "update   -- refresh game settings from config file before next round starts\n" +
             "gc       -- garbage collect (for us, not you)\n" +
             "debug    -- play with Debug (for us, not you)\n" +
             "quit     -- stop the server" 
             );
        return true;
    }
}
