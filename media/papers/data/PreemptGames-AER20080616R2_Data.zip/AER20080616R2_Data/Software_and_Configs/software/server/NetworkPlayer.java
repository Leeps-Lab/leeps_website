package leeps.it.server;
import leeps.utility.net.QueuedMessenger;
import leeps.utility.net.Messenger;
import leeps.utility.data.Message;
import java.util.LinkedList;

public class NetworkPlayer 
    extends Game.Player 
    implements Messenger.Receiver 
{
    private static LinkedList unconnected = new LinkedList();
    QueuedMessenger connection = null;
    static int disconnectedCount = 0;

    public static synchronized int nextNetworkPlayer() {
        return unconnected.size() > 0
            ? ((Integer)unconnected.removeFirst()).intValue()
            : -1;
    }

    public NetworkPlayer(QueuedMessenger connection, String name, int id) {
        super(id, name, "human");
        if(connection != null)
            renewConnection(connection);
    }

    public void renewConnection(QueuedMessenger connection) {
        this.connection = connection;
        connection.setReceiver(this);
        synchronized(NetworkPlayer.class) {
            disconnectedCount--;
            if(disconnectedCount == 0) {
                Game.signal("connect");
            }
        }
    }

    public synchronized static boolean allConnected() {
        return disconnectedCount == 0;
    }

    public void receiveDisconnect() {
        synchronized(NetworkPlayer.class) {
            disconnectedCount++;
            PlayerManager.playerDisconnected(name);
            Terminal.message("disconnected: " + name + "/" + id);
            Game.signal("disconnect");
        }
    }

    public void receiveMessage(Object data) {
        Message message = (Message)data;
        message.set("client.id", id);
        if(message.isType("error")) {
            System.err.println(
                    "Client " + id + "/" + name + " has errd: " + 
                    message.getz("message", "Unknown Error"));
        }

        if(message.isType("invest"))
            invest();
    }

    public void gameData(Message message) {
        connection.send(message);
    }

    public static void registerHole(int hole) {
        unconnected.add(new Integer(hole));
        disconnectedCount++;
    }
}
