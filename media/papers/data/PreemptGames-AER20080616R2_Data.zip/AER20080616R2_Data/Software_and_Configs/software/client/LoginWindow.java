package leeps.it.client;
import org.swixml.SwingEngine;

import javax.swing.Action;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.Window;

import javax.swing.JButton;
import javax.swing.AbstractButton;
import javax.swing.text.JTextComponent;
import javax.swing.JOptionPane;

import leeps.utility.net.QueuedMessenger;
import leeps.utility.net.Messenger;
import leeps.utility.Semaphore;
import leeps.utility.data.Message;

/**
 * Basic implementation of a loginWindow,
 * uses resource/loginWindow.xml
 * and requires swixml (and jdom)
 * to work.
 */
public class LoginWindow implements Messenger.Receiver {
    /** This semaphore locks up doLogin until a connection is made. */
    Semaphore connecting = new Semaphore(0);
    /** The connection to the server. */
    QueuedMessenger connection;
    /** True if we have logged in. */
    boolean loginState = false;
    /** Set by swixml through reflection. */
    public Window window, waitwindow;
    /** Set by swixml through reflection. */
    public JButton login;
    /** The login name is stored here if anyone cares. */
    public String loginName;

    /** Construct a new loginWindow,
     *  use doLogin to actually log in.
     */
    public LoginWindow(QueuedMessenger connection) throws Exception {
        this.connection = connection;
        connection.setReceiver(this);
        SwingEngine engine = new SwingEngine(this);
        engine.render(LoginWindow.class.getResource("loginWindow.xml"));
    }

    /** Shows the window and waits for a connection to be made.
     */
    public boolean doLogin() {
        window.show();
        connecting.down();
        synchronized(this) {
            return loginState;
        }
    }
    
    /** Set by swixml through reflection. */
    public AbstractButton relogin;
    /** Set by swixml through reflection. */
    public JTextComponent name;

    /** Used by swixml through reflection. */
    public Action sendLogin = new AbstractAction() {
        public void actionPerformed(ActionEvent e) {
            login.setEnabled(false);
            connection.send(new Message("login")
                    .set("name", loginName = name.getText())
                    .set("relogin", relogin.isSelected()));
        }
    };

    /** Handles input from the connection. */
    public void receiveMessage(Object data) {
        Message message = (Message)data;
        if(message.isType("login.accept")) {
            synchronized(this) {
                loginState = true;
            }
            window.dispose();
            try {
                SwingEngine engine = new SwingEngine(this);
                engine.render(LoginWindow.class.getResource("waitwindow.xml"));
                waitwindow.invalidate();
                waitwindow.show();
            } catch(Exception ex) {
                // oh well
            }
            connecting.up();
        }
        if(message.isType("login.reject")) {
            JOptionPane.showMessageDialog(window, 
                    message.getz("message", "Unknown Error"),
                    "Login Failed -- Try Again", 
                    JOptionPane.ERROR_MESSAGE);
            login.setEnabled(true);
        }
    }

    /** Handles a connection disconnect. */
    public void receiveDisconnect() {
        JOptionPane.showMessageDialog(window, 
                "The server disconnected", 
                "Login Failed", 
                JOptionPane.ERROR_MESSAGE);
        synchronized(this) {
            loginState = false;
        }
        connecting.up();
    }

    public void byebyeWaitWindow() {
        if(waitwindow != null) {
            waitwindow.dispose();
        }
        waitwindow = null;
    }
}
