package leeps.it.client;
import javax.swing.JComponent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Date;
import java.awt.Insets;
import leeps.utility.gui.ColorString;
import leeps.utility.Delay;
import leeps.utility.data.Message;

public class ITTicker extends JComponent {
    public LinkedList data = new LinkedList();
    private Color defaultBackground = Color.WHITE;
    int datalength;
    int shift = 0;
    int defaultStep = 2, step = 1;
    int defaultHz = 30, hz = 1;

    public void setStep(int step) {
        this.defaultStep = step;
    }

    public void setHz(int hz) {
        this.defaultHz = hz;
    }

    private void calculateDisplay(Graphics g) {
        datalength = 0; // fudge factor
        FontMetrics metric = g.getFontMetrics();

        synchronized(data) {
            for(Iterator it = data.iterator(); it.hasNext(); ) {
                String item = ((ColorString)it.next()).toPlainString();
                int width = metric.stringWidth(item);
                if(datalength == 0 && 
                        metric.stringWidth(item) < shift - getWidth()) {
                    shift -= width;
                    it.remove();
                } else {
                    datalength += width;
                }
            }
        }
    }

    long lasttime = -1;

    public synchronized void paint(Graphics g) {
        long time = new Date().getTime();
        if(lasttime == -1) lasttime = time;
        calculateDisplay(g);
        if(time - lasttime > 1000/hz && 
                datalength - shift > 0) {
            shift += step;
            lasttime = time;
        }
        g.setColor(getBackground());
        g.fillRect(0, 0, getWidth(), getSize().height);
        g.setColor(getForeground());
        calculateDisplay(g);
        int drawpos = getWidth() - shift;
        FontMetrics metric = g.getFontMetrics();

        synchronized(data) {
            for(Iterator it = data.iterator(); it.hasNext(); ) {
                if(drawpos >= getWidth()) break;
                ColorString st = (ColorString)it.next();
                String str = st.toPlainString();
                Color fg = st.getForegroundColor();
                if(fg != null) g.setColor(fg);
                g.drawString(str, drawpos, 20);
                drawpos += metric.stringWidth(str);
            }
        }

        if(datalength == 0) shift = 0;
        paintBorder(g);
        if(datalength > shift) {
            new Thread() {
                public void run() {
                    Delay delay = new Delay();
                    delay.sleep(1000/hz);
                    repaint();
                }
            }.start();
        }
    }

    int lastvalue = -1;

    protected Color baseColor = Color.BLACK;
    protected Color upColor = Color.BLUE;
    protected Color downColor = Color.RED;

    public synchronized void addValue(int value) {
        if(lastvalue == -1 || lastvalue == value) {
            data.add(new ColorString("" + value + "  ", baseColor));
        } else if(lastvalue < value) {
            data.add(new ColorString("" + value + "(+" +
                        (value - lastvalue) + ")  ", upColor));
        } else {
            data.add(new ColorString("" + value + "(" +
                        + (value - lastvalue) + ")  ", downColor));
        }
        lastvalue = value;
        repaint();
    }

    public Dimension getSize() {
        Insets ins = getInsets();
        if(ins == null) ins = new Insets(0,0,0,0);
        return new Dimension(super.getWidth(),
                20 + ins.top + ins.bottom);
    }

    public Dimension getMinimumSize() {
        Insets ins = getInsets();
        if(ins == null) ins = new Insets(0,0,0,0);
        return new Dimension(30 + ins.left + ins.right, 
                20 + ins.top + ins.bottom);
    }

    public Dimension getPreferredSize() {
        Insets ins = getInsets();
        if(ins == null) ins = new Insets(0,0,0,0);
        return new Dimension(80 + ins.left + ins.right, 
                20 + ins.top + ins.bottom);
    }

    public synchronized void clear() {
        data.clear();
        shift = 0;
        lastvalue = -1;
        repaint();
    }

    public void setBackground(Color c) {
        super.setBackground(c);
        defaultBackground = c;
    }

    public synchronized void initData(double mycost, double[] othercosts, 
            int domain, int range, Message extra) {
        clear();
        setVisible(extra.getp("visible", true));
        baseColor = ITPlot.getColor(extra, "basecolor", Color.BLACK);
        upColor =   ITPlot.getColor(extra, "upcolor", Color.BLUE);
        downColor = ITPlot.getColor(extra, "downcolor", Color.RED);
        setBackground(ITPlot.getColor(extra, "background", defaultBackground));
        hz = extra.geti("hz", defaultHz);
        step = extra.geti("value.step", defaultStep);
    }
}
