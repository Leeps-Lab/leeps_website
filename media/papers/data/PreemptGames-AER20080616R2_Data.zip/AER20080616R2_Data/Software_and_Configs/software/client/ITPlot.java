package leeps.it.client;
import leeps.utility.gui.plot.Plot;
import leeps.utility.gui.plot.Graph;
import leeps.utility.gui.plot.TextGraph;
import leeps.utility.gui.plot.LineGraph;
import leeps.utility.gui.plot.RangeGraph;
import leeps.utility.gui.plot.BackgroundGraph;
import leeps.utility.data.Message;
import leeps.utility.Range;
import java.awt.Graphics;
import java.awt.Component;
import java.awt.Color;
import java.awt.Label;

public class ITPlot extends Plot {
    Color costColor       = new Color(0xFF, 0x00, 0x00);
    Color shadowCostColor = new Color(0xCC, 0x66, 0x66);
    Color shadowPossibleColor = new Color(0xDD, 0xEB, 0xFF);
    Color valueColor      = new Color(0x33, 0x33, 0xCC);
    Color backgroundColor = new Color(0x99, 0x99, 0x99);
    float costWidth = -1.0f;
    float valueWidth = -1.0f;
    float axisWidth = -1.0f;
    float labelsWidth = -1.0f;
    int numxAxisLabels = 5;
    String xAxisLabel = "x";
    int numyAxisLabels = 5;
    String yAxisLabel = "y";
    boolean cover = true;
    int lowestPossibleCost = 0;
    
    public void setCostWidth(float width) {
        costWidth = width;
    }

    public void setValueWidth(float width) {
        valueWidth = width;
    }

    public void setAxisWidth(float width) {
        axisWidth = width;
    }

    public void setLabelsWidth(float width) {
        labelsWidth = width;
    }
    
    public void setNumAxisLabels(int numX, int numY) {
        numxAxisLabels = numX;
        numyAxisLabels = numY;
    }
    
    public void setAxisLabels(String xlabel, String ylabel) {
        xAxisLabel = xlabel;
        yAxisLabel = ylabel;
    }
    
    LineGraph valueGraph = null;
    LineGraph valueGraphCover = null;
    
    public void setCostColor(Color c) {
        costColor = c;
    }

    public void setShadowCostColor(Color c) {
        shadowCostColor = c;
    }
    
    public void setShadowPossibleColor(Color c) {
        shadowPossibleColor = c;
    }
    
    public void setValueColor(Color c) {
        valueColor = c;
    }

    public void setBackgroundColor(Color c) {
        backgroundColor = c;
    }
    
    public void plotValue(double value) {
        if(cover == true) {
            if(!(value > lowestPossibleCost))
                valueGraphCover.addData(value);
            cover = false;
        }
        valueGraph.addData(value);
        valueGraph.removeFirst();
        valueGraphCover.removeFirst();
    }

    static Color getColor(Message m, String key, Color def) {
        if(!m.has(key))
            return def;
        try {
            String color = m.getz(key); 
            Color result = (Color)org.swixml.converters.ColorConverter.conv(
                    Color.class,
                    new org.jdom.Attribute("color", color));
            if(result != null) return result;
            else return def;
        } catch(Exception ex) {
            return def;
        }
    }

    RangeGraph possible_graph = null;
    Range possible_cost = null;
    double[] shadow_costs = new double[0];
    LineGraph[] shadow_graphs = new LineGraph[0];
    LineGraph cost_graph = null;
    LineGraph time_axis = null;
    LineGraph value_axis = null;
    LineGraph[] time_axis_ticks = new LineGraph[0];
    LineGraph[] value_axis_ticks = new LineGraph[0];
    TextGraph time_axis_label = null;
    TextGraph value_axis_label = null;
    TextGraph[] time_axis_labels = new TextGraph[0];
    TextGraph[] value_axis_labels = new TextGraph[0];
    double current_cost;
    int range;

    /** The cost ``curves'' for this round,
     * <code>mycost</code> is drawn darker, the others are
     * for reference only.
     */
    public void initData(double mycost, double[] othercosts,
            Range possible_cost, int initial_data[],
            int range, Message extra, int tickDurationMs) {
        cover = true;
        current_cost = mycost;
        int xmax = initial_data.length;
        double xSize = (double)initial_data.length+(initial_data.length * 0.2);
        clearGraphs();
        setDomain(-30, xSize);
        setRange(-30, (double)(range + (range*0.05)));      
        this.range = range;
        new BackgroundGraph(this, 
                getColor(extra, "backgroundcolor", backgroundColor));
        if(possible_cost != null) {
            RangeGraph shadow =
                new RangeGraph(this, 
                        getColor(extra, "shadowpossiblecolor", shadowPossibleColor),
                        2, 0.0, xSize);
            shadow.addData(possible_cost.start, possible_cost.end);
            shadow.addData(possible_cost.start, possible_cost.end);
            this.possible_cost = possible_cost;
            this.possible_graph = shadow;
            lowestPossibleCost = possible_cost.start;
        } else {
            this.possible_cost = null;
            this.possible_graph = null;
            lowestPossibleCost = (int) current_cost; 
        }
        
        
        shadow_graphs = new LineGraph[othercosts.length];
        shadow_costs = new double[othercosts.length];
        for(int i = 0; i < othercosts.length; i++) {
            float shadowWidth = extra.getf("costwidth", costWidth);
            for(int j = 0; j < othercosts.length; j++) {
                if(i != j){
                    if(othercosts[i] == othercosts[j]){
                        shadowWidth = (float)(1.5*shadowWidth);
                    }
                }
            }
            if(othercosts[i] == current_cost){
                shadowWidth = (float)(1.5*shadowWidth);
            }
            LineGraph shadow =
                new LineGraph(this, 
                        getColor(extra, "shadowcostcolor", shadowCostColor),
                        2, 0, xSize,
                        shadowWidth);
            shadow.addData(othercosts[i]);
            shadow.addData(othercosts[i]);
            shadow_graphs[i] = shadow;
            shadow_costs[i] = othercosts[i];
        }
        cost_graph =
            new LineGraph(this, getColor(extra, "costcolor", costColor),
                    2, 0, xSize,
                    extra.getf("costwidth", costWidth));
        cost_graph.addData(mycost);
        cost_graph.addData(mycost);

        valueGraph = 
            new LineGraph(this, getColor(extra, "valuecolor", valueColor),
                    xmax, 0, xmax,
                    extra.getf("valuewidth", valueWidth));
        for(int i = 0; i < initial_data.length; i++) {
            valueGraph.addData(initial_data[i]);
        }
        
        if(lowestPossibleCost > 0) {
            valueGraphCover = 
                new LineGraph(this, getColor(extra, "backgroundcolor", backgroundColor),
                        xmax, 0, xmax,
                        5);
            for(int i = 0; i < initial_data.length; i++) {
                valueGraphCover.addData(initial_data[i]);
            }
        }

        setAxisLabels(extra.getz("xaxis.label", xAxisLabel), extra.getz("yaxis.label", yAxisLabel));
        setNumAxisLabels(extra.geti("xaxis.numlabels", numxAxisLabels), extra.geti("yaxis.numlabels", numyAxisLabels));
        setAxisWidth(extra.getf("axiswidth", axisWidth));
        setLabelsWidth(extra.getf("labelswidth", labelsWidth));
      
        time_axis = new LineGraph(this, Color.black, 2, 0, xSize, axisWidth);
        time_axis.addData(0);
        time_axis.addData(0);

        value_axis = new LineGraph(this, Color.black, 2, 0, 0, axisWidth);
        value_axis.addData(0);
        value_axis.addData(range);

        time_axis_ticks = new LineGraph[numxAxisLabels+1];
        value_axis_ticks = new LineGraph[numyAxisLabels+1];
        
        time_axis_labels = new TextGraph[numxAxisLabels+1];
        value_axis_labels = new TextGraph[numyAxisLabels+1];
       
        time_axis_label = new TextGraph(this, Color.black, xAxisLabel, 0.90*getDomainMax(), -20);
        value_axis_label = new TextGraph(this, Color.black, yAxisLabel, -30, range, true, false, false);
       
        for(int i = 1; i <= numxAxisLabels; i++) {
            LineGraph vertLabel = new LineGraph(this, Color.black, 2,
                                                (xmax/numxAxisLabels) * i,
                                                (xmax/numxAxisLabels) * i,
                                                axisWidth);
            vertLabel.addData(0);
            vertLabel.addData(-3);
            time_axis_ticks[i] = vertLabel;
            int conversionToSeconds = 1000 / tickDurationMs;
            double time = (double)((xmax - xmax/numxAxisLabels*i) / conversionToSeconds);
            int itime = (int)time;
            if(time == itime) {
                Integer text = new Integer(itime);
                time_axis_labels[i] = new TextGraph(this, Color.black, text.toString(), 
                        (xmax/numxAxisLabels) * i, -20, false, true, false);
            }else {
                time_axis_labels[i] = new TextGraph(this, Color.black, "", 0, 0, false, true, false);
            }
        }
        
        for(int i = 1; i <= numyAxisLabels; i++) {
            LineGraph horizLabel = new LineGraph(this, Color.black, 2, -3, 0, axisWidth);
            horizLabel.addData(range/numyAxisLabels * i);
            horizLabel.addData(range/numyAxisLabels * i);
            value_axis_ticks[i] = horizLabel;
            String text = new Integer((int)(range/numyAxisLabels*i)).toString();
            value_axis_labels[i] = new TextGraph(this, Color.black, text, 
                    -20, (range/numyAxisLabels * i), false, false, true);
        }
    }

    /** Increases the range until it is above the passed in currentValue. 
     * Also, adds more to labels and redraws Y Axis label */
    public void increaseRangeAbove(double currentValue) {
        while (range < currentValue) {
            range = range + range/numyAxisLabels;
            numyAxisLabels++;
        }

        value_axis = new LineGraph(this, Color.black, 2, 0, 0, axisWidth);
        value_axis.addData(0);
        value_axis.addData(range);

        value_axis_labels = new TextGraph[numyAxisLabels+1];
        value_axis_ticks = new LineGraph[numyAxisLabels+1];
        for(int i = 1; i <= numyAxisLabels; i++) {
            LineGraph horizLabel = new LineGraph(this, Color.black, 2, -3, 0, axisWidth);
            horizLabel.addData(range/numyAxisLabels * i);
            horizLabel.addData(range/numyAxisLabels * i);
            value_axis_ticks[i] = horizLabel;
            String text = new Integer((int)(range/numyAxisLabels*i)).toString();
            value_axis_labels[i] = new TextGraph(this, Color.black, text, 
                    -20, (range/numyAxisLabels * i), false, false, true);
        }
        setRange(-30, (double)(range + (range*0.05)));      
    }
}
