package leeps.it.client;
import org.swixml.SwingEngine;
import javax.swing.Action;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JTabbedPane;
import javax.swing.AbstractButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.KeyStroke;
import leeps.utility.data.Message;

/**
 * Implements the ITClient.UI interface. Defines a user interface for the 
 * investment timing client ITClient.
 *
 * @see ITClient.UI
 */
public class ITWindow implements ITClient.UI {
    private final ITClient client;
    private double cost;
    private String title;

    /**
     * Sets the ITClient used, and creates the game window.
     */
    private Message windowConfig;
    
    public ITWindow(ITClient client) {
        this.client = client;
        makeGameWindow();
    }

    public Action investAction = new AbstractAction() {
        public void actionPerformed(ActionEvent e) {
           investButton.setEnabled(false);
            client.invest();
        }
    };

    public JFrame window = null;
    public AbstractButton investButton;
    public ITPlot plot;
    public ITTicker ticker;
    public JLabel totalScore, currentValue;
    public JTextArea historyText;
    public JTextPane currentPane;
    public StringBuffer currentText;
    public JTabbedPane mainTabs, historyTabs;
    
    /**
     * Creates the game window from 'gamewindow.xml', if it does not alreaady
     * exist.
     */
    
    private void makeGameWindow() {
        if(window == null) 
        try {
            SwingEngine engine = new SwingEngine(this);
            engine.getTaglib().registerTag("plot", ITPlot.class);
            engine.getTaglib().registerTag("ticker", ITTicker.class);
            engine.render(ITWindow.class.getResource("gamewindow.xml"));
            window.setTitle(title);
            window.setVisible(false);
            plot.setVisible(false);
            window.validate();
            
            investButton.getInputMap(investButton.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("released SPACE"), "invest");    
            investButton.getActionMap().put("invest", investAction);

        } catch (Exception ex) {
            client.fatal("Could not make game window: " + ex.getMessage());
        }
    }

    /**
     * Updates the display with new data.
     */
    public void initData(double mycost, double[] othercosts, 
            int[] initial_data, int range, Message extra) {
    
    
        
        mainTabs.setSelectedIndex(0);
        currentValue.setText("Value: 0");

        plot.initData(this.cost = mycost, othercosts, 
                (leeps.utility.Range)extra.get("cost.possible.shadow", null),
                initial_data, range, extra.extract("plot."), extra.geti("tick.duration.ms"));
        ticker.initData(mycost, othercosts, initial_data.length, 
                range, extra.extract("ticker."));
        
        if (extra.has("totalScore"))
            totalScore.setText(""+extra.geti("totalScore"));
        mainTabs.setSelectedIndex(0); 
        investButton.setEnabled(false);
        plot.setVisible(false);
        window.setVisible(true);
        window.validate();

        windowConfig = new Message(extra);
        
        currentText = new StringBuffer();
        currentText.append("<font face=\"Monospaced\"></font>");
        
        addToPane("Round " + extra.geti("round") + "\n");
        
        addToPane("You have a cost of " + (int)mycost + "\n");
       
        int numCompetitors = extra.geti("groupSize") - 1;
        if(windowConfig.getp("plot.client.message1", false) == true) {
            if(numCompetitors == 0)
                addToPane("You have no competitors\n");
            else if(numCompetitors == 1)
                addToPane("You have 1 competitor\n");
            else
                addToPane("You have " + numCompetitors + " competitors\n");
        }
        if(windowConfig.getp("plot.client.message7", false) == true && numCompetitors > 0) {
            if(windowConfig.getp("cost.viewable.others", false) == true) {
                boolean equalCosts = true;
                for(int i = 0; i < othercosts.length; i++) {
                    if(mycost != othercosts[i]) equalCosts = false;
                }
                if(equalCosts)
                    addToPane("All players have the same cost\n");
            }
        }
        if(windowConfig.getp("plot.client.message8", false) == true && numCompetitors > 0) {
            if(windowConfig.getp("cost.viewable.others", false) == false) {
                addToPane("All costs are private information\n");
            }
        }
        if(windowConfig.getp("cost.viewable.others", false) == true && numCompetitors > 0) {
            addToPane("Competitors costs are indicated by " + extra.getz("plot.shadowcostcolor") + " lines\n");
        }
    }

    public void plotValue(double value) {
        if(value >= plot.getRangeMax()) {
            plot.increaseRangeAbove(value);
        }
        plot.plotValue(value);
        currentValue.setText("Value:"+(int)value);
        ticker.addValue((int)value - (int)cost);
    }

    public void disable(Message message) {
        investButton.setEnabled(false);
        investButton.setText(message.getz("message"));
        
        if(message.has("score")){
           int yourScore = message.geti("score");
           int investedValue = message.geti("investedValue");
           if(windowConfig.getp("plot.client.message4", false) == true) {
              if(yourScore > 0)
                 addToPane("You invested at a value of " +
                    investedValue + ",\nand earned a profit of " + yourScore +
                    "\n");
           }
         
           totalScore.setText(""+message.geti("totalScore"));
        }
    }
    
    
    //stolen from leeps.utility.gui.ColorString, then modified
    private void enticize(String s, StringBuffer sb) {
        for(int i = 0; i < s.length(); i++) {
            char c;
            switch(c = s.charAt(i)) {
                case '\n': sb.insert(sb.length()-7, "<br>"); break;
                case '&': sb.insert(sb.length()-7, "&amp;"); break;
                case ' ': sb.insert(sb.length()-7, "&nbsp;"); break;
                default: sb.insert(sb.length()-7, c); break;
            }
        }
    }

    
    private void addToPane(String s){
       enticize(s, currentText);
       currentPane.setText(currentText.toString());
    }

    public void endRound(Message message) {
       
        if (message.getp("round.complete")) {
            
            int roundTime = message.geti("roundTime");
            int winningValue = message.geti("winningValue");
            
            addToPane("\n");
  
            
            if(message.has("totalScore")){
               totalScore.setText(""+message.geti("totalScore"));
            }        
            
            if(message.getp("AllowInvestAttempts",false)){
               addToPane(message.getz("resultsTable"));
            }
            
            addToPane("\n");
            if(winningValue==0){
               if(message.geti("groupSize",1) != 1)
                  addToPane("Nobody Invested\n");
            }else if(message.getp("invested",false)){
               addToPane("You Invested at " + winningValue + "\n");
            }else{
               addToPane("Somebody Invested at " + winningValue + "\n");
            }
            
            historyText.append("\t" + message.geti("round.id") + "\t\t\t\t" +
                    message.geti("score") + "\n"); 
            
            historyTabs.setSelectedIndex(historyTabs.indexOfTab("Summary"));
            
            JTextPane roundPane = new JTextPane();
            roundPane.setContentType("text/html");
            roundPane.setText(currentText.toString());
            
            historyTabs.addTab(""+message.geti("round.id"),roundPane);
          
        }
        investButton.setEnabled(false);       
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void close() {
        window.dispose();
    }

    public void enable() {
        investButton.setEnabled(true);
        investButton.setText("invest!");
        plot.setVisible(true);
    }
}
