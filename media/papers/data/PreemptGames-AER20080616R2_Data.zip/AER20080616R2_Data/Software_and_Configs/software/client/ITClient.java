package leeps.it.client;
import leeps.utility.net.QueuedMessenger;
import leeps.utility.net.Messenger;
import java.applet.Applet;
import javax.swing.JOptionPane;
import java.net.Socket;
import leeps.utility.sm.StateMachineParser;
import leeps.utility.sm.StateMachine;
import leeps.utility.io.InputStreamScanner;
import leeps.utility.data.Message;

/** An Investment Timing client. 
 */
public class ITClient extends Applet implements Messenger.Receiver {

    /** Game "state", useful for switching on strings. */
    StateMachine state;
    /** The connection to the server. */
    QueuedMessenger connection;
    /** Implementation of the visual interface to the game. */
    private UI ui;
    /** Global because we need to clean up the waitwindow 
     * when the game starts. */
    LoginWindow login;

    String host;
    int port;
    
    /**
     * Connects to the server, puts up a login window, and
     * waits for a successful login. We don't do this in start
     * because we really want this to happen once only.
     */
    public void init() {
        host = getParameter("host");
        port = Integer.parseInt(getParameter("port"));
        startup();
    }

    public static void main(String[] args) {
        ITClient client = new ITClient();
        client.host = args[0];
        client.port = Integer.parseInt(args[1]);
        client.startup();
    }
    /**
     * Creates the connection to the server, the login window, and the state
     * machine. Then asks for login, and if successful, creates the user
     * interface.
     */
    private void startup() {
        try {
            System.err.println("connection to server ...");
            connection = makeConnection();
            System.err.println("building login window...");
            login = new LoginWindow(connection);
            System.err.println("constructing game controller...");
            try {
                state = StateMachineParser.parse(new InputStreamScanner(
                            ITClient.class.getResourceAsStream("client.stm")),
                        ITClient.class, Message.class).build(this);
            } catch (Exception ex) {
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                    "Initialization failed: " + ex,
                    "Startup Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        System.err.println("trying to login...");
        if(!login.doLogin())
            return;

        System.err.println("building user interface...");
        ui = new ITWindow(this);
        ((ITWindow)ui).setTitle(login.loginName + " :: Investment Timing"); 
        System.err.println("attaching network stream...");
        connection.setReceiver(this);
    }

    /** Builds a QueuedMessenger connected to the server */
    private QueuedMessenger makeConnection() throws Exception {
        return QueuedMessenger.createSocketMessenger(
                new Socket(host, port));
    }
    
    /**
     * Sends an 'invest' message to the server.
     */
    public void invest() {
        connection.send(new Message("invest"));
    }
    
    /**
     * Closes the user interface, ends the game, and closes the connection to
     * the server.
     */
    public void stop() {
    }

    /** handler for the connection */
    public void receiveMessage(Object data) {
        Message message = (Message)data;
        state.transition(message.type(), message);
    }

    /** handler for the connection */
    public void receiveDisconnect() {
        if(!isGameOver())
            JOptionPane.showMessageDialog(this, 
                    "The server is no longer connected\r\n" +
                    "you may need to relogin.",
                    "Please note that: ...",
                    JOptionPane.ERROR_MESSAGE);
    }

    /** Send fatal errors to the server. */
    public void fatal(String message) {
        // tell server
        connection.send(new Message("error")
                .set("message", message));
        connection.close();
        // tell console
        System.err.println(message);
        try { // try to quit,
            System.exit(1);
        } catch(Exception ex) { // must be an applet
            try {
                JOptionPane.showMessageDialog(null, 
                        message,
                        "Fatal Error", 
                        JOptionPane.ERROR_MESSAGE);
            } catch(Exception exx) {
            }
        }
    }

    /**
     * Called by the statemachine; a round is over.
     */
    public void endRound(Message message) {
        ui.endRound(message);
    }
    
    /**
     * Any user interface for this investment timing client must implement
     * this interface.
     * @see ITWindow
     */
    public interface UI {
        /**
         * Adds the given data to the user interface. This is called
         * at the start of every round.
         */
        public void initData(double mycost, double[] othercosts, 
                int[] initial_data, int range, Message extra);
        public void plotValue(double value);
        public void enable();
        public void disable(Message message);
        public void endRound(Message message);
        public void close();
    };
    
    /**
     * Starts a new round with the data given from the received message.
     * The user interface is then given the new data.
     *
     * @see ITClient.UI#initData(double[], double[], int[], int[], int , Message)
     */
    public void startRound(Message message) {
        login.byebyeWaitWindow();
        ui.initData(message.getd("cost"), 
                (double[])message.get("cost.shadow", new double[0]),
                (int[])message.get("data.init", new int[message.geti("ticks.viewable")]),
                message.geti("plot.yaxis.max"),
                message);
    }

    public void enableUI(Message unused) {
        ui.enable();
    }

    public void disableUI(Message message) {
        ui.disable(message);
    }

    public void tick(Message message) {
        ui.plotValue(message.getd("value"));
    }

    /** Set gameover to true so that the 
     * disconnected handler doesn't print an error.
     * Use setGameOver so that it's synchronized.
     */
    boolean gameover = false; 

    /** call this when the server indicates that the game is over.
     */
    synchronized public void setGameOver(Message unused) {
        System.err.println("Uhoh, the server shut down ...");
        gameover = true;
    }

    /** true if the game is over.
     */
    synchronized boolean isGameOver() {
        return gameover;
    }
}
