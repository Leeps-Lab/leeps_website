####################
##  DO SUBJECTS DO SIGNIFICANTLY WORSE AGAINST THE EMPIRICAL DISTRIBUTION
##  OF INVESTMENT CHOICES THAN BNE AGENTS? 
####################


P <- read.table("INSERT-PATH-TO_Data.csv",header=TRUE,sep=",")



P<-P[P$structure=="C",]

P$score<-P$score*(P$invested==TRUE)



#################
## CREATE GROUP VARIABLE
#################


P$ident<-as.numeric(factor(interaction(P$round,P$group,P$session)))

P$n<-1


#################
## TELL PROGRAM TO DISREGARD NON-ATTEMPTS
#################


#P[P$attempted==FALSE,]$value<-1000


#################
## GET SIZE OF GROUPS
#################

P$size<-ave(P$n,P$ident,FUN=sum)
P<-P[P$size==3,]


#################
## REORDER AND RANK
#################


P$rank<-ave(P$time,P$ident,FUN=rank)

#################
## CONVERT INTO ROW'S VALUES
#################

P$first<-(P$rank==1)*P$value
P$first<-ave(P$first,P$ident,FUN=sum)

P$second<-(P$rank==2)*P$value
P$second<-ave(P$second,P$ident,FUN=sum)

P$third<-(P$rank==3)*P$value
P$third<-ave(P$third,P$ident,FUN=sum)

#################
## CONVERT INTO ROW'S COSTS
#################

P$firstc<-(P$rank==1)*P$cost
P$firstc<-ave(P$firstc,P$ident,FUN=sum)

P$secondc<-(P$rank==2)*P$cost
P$secondc<-ave(P$secondc,P$ident,FUN=sum)

P$thirdc<-(P$rank==3)*P$cost
P$thirdc<-ave(P$thirdc,P$ident,FUN=sum)


#################
## CONVERT INTO ROW'S SCORE
#################

P$firsts<-(P$rank==1)*P$score
P$firsts<-ave(P$firsts,P$ident,FUN=sum)


P$seconds<-(P$rank==2)*P$score
P$seconds<-ave(P$seconds,P$ident,FUN=sum)

P$thirds<-(P$rank==3)*P$score
P$thirds<-ave(P$thirds,P$ident,FUN=sum)


#################
## CONVERT INTO ROW'S ID
#################

P$firsti<-(P$rank==1)*P$uniquesub
P$firsti<-ave(P$firsti,P$ident,FUN=sum)


P$secondi<-(P$rank==2)*P$uniquesub
P$secondi<-ave(P$secondi,P$ident,FUN=sum)

P$thirdi<-(P$rank==3)*P$uniquesub
P$thirdi<-ave(P$thirdi,P$ident,FUN=sum)


P2<-P[P$rank==1,]


#################
## SEPARATE AND STACK
#################

P.12<-P2[,c("treatment","high_val_round","first","second","thirdc","thirds","thirdi")]
P.13<-P2[,c("treatment","high_val_round","first","third","secondc","seconds","secondi")]
P.23<-P2[,c("treatment","high_val_round","second","third","firstc","firsts","firsti")]

names(P.12)<-c("treatment","high_val_round","first","second","cost","score","id")
names(P.13)<-c("treatment","high_val_round","first","second","cost","score","id")
names(P.23)<-c("treatment","high_val_round","first","second","cost","score","id")

P2<-rbind(P.12,P.13,P.23)

low<-P2[P2$treatment=="Low",]
high<-P2[P2$treatment=="High",]

low$op<- (-0.001895*((low$cost)^2))+(0.97302235*low$cost)+14.2864917
high$op<- (-0.0024833*((high$cost)^2))+(1.06949379*high$cost)+10.3335244

low$ea<-(low$op-low$cost)*(low$op<low$first & low$op<low$second & low$op<=low$high_val_round)
high$ea<-(high$op-high$cost)*(high$op<high$first & high$op<high$second & high$op<=high$high_val_round)

low$diff <- low$ea-low$score 
high$diff <- high$ea-high$score 



co.low<-as.vector(tapply(low$dif, low$id,sum))
co.high<-as.vector(tapply(high$dif, high$id,sum))

co.low<-co.low[2:37]
co.high<-co.high[2:37]

##  Generate medians of differences

median(co.low)
median(co.high)


##  Test difference from 0

wilcox.test(co.low)
wilcox.test(co.high)


#  Generate Figure 7

layout(matrix(c(1,2),1,2))

hist(co.low, xlab="BNE Gains", ylab="Frequency", main="Low",xlim=c(-30,30),ylim=c(0,12))
abline("h"=0)
hist(co.high, xlab="BNE Gains", ylab="Frequency", main="High",xlim=c(-30,30),ylim=c(0,12))
abline("h"=0)

