## source("/Users/roprea/Desktop/CDFS.R",echo=TRUE)

IT <- read.table("/Users/roprea/@Projects/Investment Timing/Analysis/IT.csv",header=TRUE,sep=",",row.names=1)


IT$prem<-(IT$value/IT$cost)-1

IT[,"pred"]<-IT[,"treatment"]
levels(IT[,"pred"])<-list("1.18"="1.18","1.8"="1.8","1.49"="1.49a","1.5"="1.49b")
IT$pred<-as.numeric(as.character(IT$pred))
IT$pred<-IT$pred*110


##--HOW MUCH CENSORING

dat<-IT
dat[,"inv"]<-as.factor(dat[,"invested"])
levels(dat[,"inv"])<-list("1"="TRUE","0"="FALSE")
dat$inv<-as.numeric(as.character(dat$inv))
mean(dat$inv)
dat<-dat[dat$high_value>=dat$pred,]
mean(dat$inv)


##--CUT OUT FAILED INVESTMENTS
IT<-IT[IT$invested==TRUE,]


layout(matrix(c(1,3,4,2,5,6),3,2,byrow=FALSE))


plot.ecdf(IT[IT$treatment=="1.18",]$prem,do.points=FALSE,verticals=TRUE,col.hor="lightblue",col.vert="lightblue",xlim=c(0,1),xlab="Premium",ylab="CDF",main="(a) \n \n All Data")
abline("h"=0.5,col="gray")
lines(ecdf(IT[IT$treatment=="1.49a",]$prem),do.points=FALSE,verticals=TRUE,col.hor="red",col.vert="red")
lines(ecdf(IT[IT$treatment=="1.49b",]$prem),do.points=FALSE,verticals=TRUE,col.hor="darkblue",col.vert="darkblue")
lines(ecdf(IT[IT$treatment=="1.8",]$prem),do.points=FALSE,verticals=TRUE,col.hor="lightgreen",col.vert="lightgreen")
abline("v"=0.18,col="lightblue", lty=2)
abline("v"=0.49,col="red", lty=2)
abline("v"=0.5,col="darkblue", lty=2)
abline("v"=0.8,col="lightgreen", lty=2)
legend("bottomright", legend=c("Low","Medium A","Medium B","High"),col=c("lightblue","red","darkblue","lightgreen"),cex=1.25,bg="white",lty=c(1,1,1,1),box.lwd="white")


##--CUT OUT ALL INFEASIBLE PERIODS

IT<-IT[IT$high_value>=IT$pred,]



plot.ecdf(IT[IT$treatment=="1.18",]$prem,do.points=FALSE,verticals=TRUE,col.hor="lightblue",col.vert="lightblue",xlim=c(0,1),xlab="Premium",ylab="CDF",main="(b) \n \n Feasible Draws")
abline("h"=0.5,col="gray")
lines(ecdf(IT[IT$treatment=="1.49a",]$prem),do.points=FALSE,verticals=TRUE,col.hor="red",col.vert="red")
lines(ecdf(IT[IT$treatment=="1.49b",]$prem),do.points=FALSE,verticals=TRUE,col.hor="darkblue",col.vert="darkblue")
lines(ecdf(IT[IT$treatment=="1.8",]$prem),do.points=FALSE,verticals=TRUE,col.hor="lightgreen",col.vert="lightgreen")
abline("v"=0.18,col="lightblue", lty=2)
abline("v"=0.49,col="red", lty=2)
abline("v"=0.5,col="darkblue", lty=2)
abline("v"=0.8,col="lightgreen", lty=2)


##-----------------------



plot.ecdf(IT[IT$treatment=="1.18" & IT$round>60,]$prem,do.points=FALSE,verticals=TRUE,col.hor="red",col.vert="red",xlim=c(0,0.5),xlab="Premium",ylab="CDF",main="(c)\n \n Low: Early vs. Late  (Feasible Draws)")
abline("h"=0.5,col="gray")
abline("v"=0.18,col="gray")
lines(ecdf(IT[IT$treatment=="1.18" & IT$round<40 ,]$prem),do.points=FALSE,verticals=TRUE,col.hor="blue",col.vert="blue")
legend("bottomright", legend=c("Early","Late"),col=c("blue","red"),cex=1.25,bg="white",lty=c(1,1),box.lwd="white")

##-----------------------



plot.ecdf(IT[IT$treatment=="1.49a" & IT$round>60,]$prem,do.points=FALSE,verticals=TRUE,col.hor="red",col.vert="red",xlim=c(0,1),xlab="Premium",ylab="CDF",main="(e) \n \n Medium A: Early vs. Late (Feasible Draws)")
abline("h"=0.5,col="gray")
abline("v"=0.49,col="gray")
lines(ecdf(IT[IT$treatment=="1.49a" & IT$round<40,]$prem),do.points=FALSE,verticals=TRUE,col.hor="blue",col.vert="blue")


##-----------------------

plot.ecdf(IT[IT$treatment=="1.8" & IT$round>60,]$prem,do.points=FALSE,verticals=TRUE,col.hor="red",col.vert="red",xlim=c(0,2),xlab="Premium",ylab="CDF",main="(d) \n \n High: Early vs. Late (Feasible Draws)")
abline("h"=0.5,col="gray")
abline("v"=0.8,col="gray")
lines(ecdf(IT[IT$treatment=="1.8" & IT$round<40,]$prem),do.points=FALSE,verticals=TRUE,col.hor="blue",col.vert="blue")

##-----------------------


plot.ecdf(IT[IT$treatment=="1.49b" & IT$round>60,]$prem,do.points=FALSE,verticals=TRUE,col.hor="red",col.vert="red",xlim=c(0,1),xlab="Premium",ylab="CDF",main="(f) \n \n Medium B: Early vs. Late (Feasible Draws)")
abline("h"=0.5,col="gray")
abline("v"=0.5,col="gray")
lines(ecdf(IT[IT$treatment=="1.49b" & IT$round<40,]$prem),do.points=FALSE,verticals=TRUE,col.hor="blue",col.vert="blue")


#################





