require(dplyr)
require(ggplot2)
require(plyr)
require(grid)
## Assuming that we've loaded our data. ticks_allHotelling



# Create "AllNames" - List of all-Human Periods ----
{
  AllNames <- ticks_allHotelling[!duplicated(paste(ticks_allHotelling$session,ticks_allHotelling$name)),]
  AllNames <- dplyr::filter(
    AllNames, 
    robot == "humans")
  AllNames <- dplyr::select(
    AllNames,
    name, session, treatment
  )
  
  substrRight <- function(x, n){
    substr(x, nchar(x)-n+1, nchar(x))
  }
  
  AllNames <- dplyr::mutate(
    AllNames, 
    session = ifelse(treatment == "D",
                     yes = paste(session,"S",sep=""),
                     no = as.character(session)),
    treatment = ifelse(treatment == "D", 
                       yes = "Discrete",
                       no = ifelse(treatment == "CI",
                                   yes = "Continuous Instant",
                                   no = "Continuous Slow")),
    Silo = substrRight(name,1)
    
  )
  
}


# Create AvgDist Dataset for Discrete time treatments ----
{
  #    takes about 
  AvgDistDS <- data.frame(name="",Time=0,AvgDistAbs=0,AvgDist=0,treatment="Discrete")
  AvgDistDS <- AvgDistDS[-1,]
  TreatmentSubset <- subset(AllNames,treatment=="Discrete")
  PeriodsNames <- unique(TreatmentSubset$name)
  
  for (NAME in PeriodsNames){
    Temp <- subset(ticks_allHotelling,name==NAME)
    Temp$CountOrd <- rep(1:4, nrow(Temp)/4)
    Temp$ActinOrd <- unlist (with( Temp, tapply(strategy0,Temp$subperiod, sort)) )
    
    TIME <- unique(Temp$subperiod)
    
    ord1 <- subset(Temp, CountOrd==1)
    ord2 <- subset(Temp, CountOrd==2)
    ord3 <- subset(Temp, CountOrd==3)
    ord4 <- subset(Temp, CountOrd==4)             
    ABS <- I( ( abs(ord1$ActinOrd-0.25)+abs(ord2$ActinOrd-0.25)+abs(ord3$ActinOrd-0.75)+abs(ord4$ActinOrd-0.75) ) / 4 )
    AvgDist <- I( ( (ord1$ActinOrd-0.25)+(ord2$ActinOrd-0.25)+(ord3$ActinOrd-0.75)+(ord4$ActinOrd-0.75) ) / 4 )
    
    NewDataFrame <- data.frame(name=rep(NAME,length(ABS)),
                               Time=TIME,
                               AvgDistAbs=ABS,
                               AvgDist=AvgDist,
                               treatment="Discrete")
    
    AvgDistDS <- rbind(AvgDistDS,NewDataFrame)
    
  }
  
  
  HistwNormDist <- function(X,breaks=50,xlim=range(breaks)){
    #A function that produces a hist iwth normal dist
    h<-hist(X,breaks,xlim=xlim,main=deparse(substitute(X)),xlab=deparse(substitute(X)))
    xfit<-seq(min(X),max(X),length=40) 
    yfit<-dnorm(xfit,mean=mean(X),sd=sd(X)) 
    yfit <- yfit*diff(h$mids[1:2])*length(X) 
    lines(xfit, yfit, col="grey", lwd=2)
  }
  
  # Average Average Distance
  for (i in unique(AvgDistDS$Time)){
    temp <- subset(AvgDistDS, Time==i)
    ABS <- mean(temp$AvgDistAbs)
    AvgDist <- mean(temp$AvgDist)
    
    NewDataFrame <- data.frame(name="Overall",
                               Time=i,
                               AvgDistAbs=ABS,
                               AvgDist=AvgDist,
                               treatment="Discrete")
    AvgDistDS <- rbind(AvgDistDS,NewDataFrame)
  }
  
  
}

#####

# Create AvgDist Dataset for Continuous Instant time treatments ----
{
  AvgDistCI <- data.frame(name="",Time=0,AvgDistAbs=0,AvgDist=0,treatment="Continuous Slow")
  AvgDistCI <- AvgDistCI[-1,]
  TreatmentSubset <- subset(AllNames,treatment=="Continuous Instant")
  PeriodsNames <- unique(TreatmentSubset$name)
  
  for (NAME in PeriodsNames){
    Temp <- subset(ticks_allHotelling,name==NAME)
    Temp$CountOrd <- rep(1:4, nrow(Temp)/4)
    Temp$ActinOrd <- unlist (with( Temp, tapply(strategy0,I(max(Temp$secondsLeft)-secondsLeft), sort)) )
    
    TIME <- unique(Temp$secondsLeft)
    TIME <- I(max(TIME)-TIME)
    
    ord1 <- subset(Temp, CountOrd==1)
    ord2 <- subset(Temp, CountOrd==2)
    ord3 <- subset(Temp, CountOrd==3)
    ord4 <- subset(Temp, CountOrd==4)             
    ABS <- I( ( abs(ord1$ActinOrd-0.25)+abs(ord2$ActinOrd-0.25)+abs(ord3$ActinOrd-0.75)+abs(ord4$ActinOrd-0.75) ) / 4 )
    AvgDist <- I( ( (ord1$ActinOrd-0.25)+(ord2$ActinOrd-0.25)+(ord3$ActinOrd-0.75)+(ord4$ActinOrd-0.75) ) / 4 )
    
    NewDataFrame <- data.frame(name=rep(NAME,length(ABS)),
                               Time=TIME,
                               AvgDistAbs=ABS,
                               AvgDist=AvgDist,
                               treatment="Continuous Instant")
    
    AvgDistCI <- rbind(AvgDistCI,NewDataFrame)
    
  }
  
  # Average Average Continuous Instant 
  for (i in seq(0.5,179.5,1)){
    temp <- subset(AvgDistCI, Time>i-0.5 & Time<i+0.5)
    ABS <- mean(temp$AvgDistAbs)
    AvgDist <- mean(temp$AvgDist)
    
    NewDataFrame <- data.frame(name="Overall",
                               Time=i,
                               AvgDistAbs=ABS,
                               AvgDist=AvgDist,
                               treatment="Continuous Instant")
    AvgDistCI <- rbind(AvgDistCI,NewDataFrame)
  }
  
}


# Create AvgDist Dataset for Continuous SLow time treatments ----
{
  AvgDistCS <- data.frame(name="",Time=0,AvgDistAbs=0,AvgDist=0,treatment="Continuous Slow")
  AvgDistCS <- AvgDistCS[-1,]
  TreatmentSubset <- subset(AllNames,treatment=="Continuous Slow")
  PeriodsNames <- unique(TreatmentSubset$name)
  
  for (NAME in PeriodsNames){
    Temp <- subset(ticks_allHotelling,name==NAME)
    Temp$CountOrd <- rep(1:4, nrow(Temp)/4)
    Temp$ActinOrd <- unlist (with( Temp, tapply(strategy0,I(max(Temp$secondsLeft)-secondsLeft), sort)) )
    
    TIME <- unique(Temp$secondsLeft)
    TIME <- I(max(TIME)-TIME)
    
    ord1 <- subset(Temp, CountOrd==1)
    ord2 <- subset(Temp, CountOrd==2)
    ord3 <- subset(Temp, CountOrd==3)
    ord4 <- subset(Temp, CountOrd==4)             
    ABS <- I( ( abs(ord1$ActinOrd-0.25)+abs(ord2$ActinOrd-0.25)+abs(ord3$ActinOrd-0.75)+abs(ord4$ActinOrd-0.75) ) / 4 )
    AvgDist <- I( ( (ord1$ActinOrd-0.25)+(ord2$ActinOrd-0.25)+(ord3$ActinOrd-0.75)+(ord4$ActinOrd-0.75) ) / 4 )
    
    NewDataFrame <- data.frame(name=rep(NAME,length(ABS)),
                               Time=TIME,
                               AvgDistAbs=ABS,
                               AvgDist=AvgDist,
                               treatment="Continuous Slow")
    
    AvgDistCS <- rbind(AvgDistCS,NewDataFrame)
    
  }
  
  # Average Average Continuous SLow 
  for (i in seq(0.5,179.5,1)){
    temp <- subset(AvgDistCS, Time>i-0.5 & Time<i+0.5)
    ABS <- mean(temp$AvgDistAbs)
    AvgDist <- mean(temp$AvgDist)
    
    NewDataFrame <- data.frame(name="Overall",
                               Time=i,
                               AvgDistAbs=ABS,
                               AvgDist=AvgDist,
                               treatment="Continuous Slow")
    AvgDistCS <- rbind(AvgDistCS,NewDataFrame)
  }
  
}

## plot Continuous slow ----
ggplot(AvgDistCS, aes(x=Time, y=AvgDistAbs, group=name)) +
  geom_line(colour="grey60") +
  geom_line(data=AvgDistCS[AvgDistCS$name=="Overall",], size=2) +
  ylim(0,0.4)

## For discrete time treatment, convert periods into seconds. ----
AvgDistDS$Time <- 3*AvgDistDS$Time


## Appears to be issue with AvgDist metric at time==180 for all continuous time treatments
# this issue appears to be the result of ticks secondsLeft==180 repeat twice, so I'll delete and time > 179.9
AvgDistCI <- subset(AvgDistCI,Time <= 179.9)
AvgDistCS <- subset(AvgDistCS,Time <= 179.9)

## Combine all AvgDistData ----
AvgDistData <- rbind(AvgDistDS, AvgDistCI, AvgDistCS)


#Summary stats on AvgDist fronm Eq by treatment and by learning level
ticks_allHotelling.temp <- subset(ticks_allHotelling,,c("period","name","Learning_Sense_1","Learning_Sense_2"))
ticks_allHotelling.temp <- ticks_allHotelling.temp[!duplicated(ticks_allHotelling.temp$name),]

AvgDistData <- merge(AvgDistData, 
                     ticks_allHotelling.temp, 
                     by.x = c("name"), 
                     by.y = c("name"),
                     all.x=TRUE) 




# Summary stats

# Average Distance from Eq - Not Including robot treatments
ddply(subset(AvgDistData,name!="Overall"),.(treatment),summarize,
      AvgScore = mean(AvgDistAbs),
      SDScore = sd(AvgDistAbs),
      N = length(AvgDistAbs))

# Overall Average Distance from Eq - Not Including robot treatments


#  Avg Dist from Eq by Learning Level
ddply(subset(AvgDistData,name!="Overall"),.(treatment,Learning_Sense_2),summarize,
      AvgScore = round(mean(AvgDistAbs),4),
      SDScore = round(sd(AvgDistAbs),4),
      N = length(AvgDistAbs))

# Table 3: Attainment of Near-Equilibrium Location Formations by Treatment
# Percent time within 1% of Pure NE - (% of time/subperiods AvgDistEq < 0.01)
ddply(subset(AvgDistData,name!="Overall"),.(treatment,Learning_Sense_2),summarize,
      Percent_01 = round(length(AvgDistAbs[AvgDistAbs<00.0025]) / length(AvgDistAbs),4)*100,
      Percent_05 = round(length(AvgDistAbs[AvgDistAbs<0.0125]) / length(AvgDistAbs),4)*100,
      N = length(AvgDistAbs))

#Overall
ddply(subset(AvgDistData,name!="Overall"),.(treatment),summarize,
      Percent_01 = round(length(AvgDistAbs[AvgDistAbs<00.0025]) / length(AvgDistAbs),4)*100,
      Percent_05 = round(length(AvgDistAbs[AvgDistAbs<0.0125]) / length(AvgDistAbs),4)*100,
      N = length(AvgDistAbs))


# Robust? - not as clear, but pretty good support. 
# Percent time within 1% of Pure NE - (% of time/subperiods AvgDistEq < 0.01)
ddply(subset(AvgDistData,name!="Overall"),.(treatment,Learning_Sense_1),summarize,
      Percent_01 = round(length(AvgDistAbs[AvgDistAbs<00.0025]) / length(AvgDistAbs),4)*100,
      Percent_05 = round(length(AvgDistAbs[AvgDistAbs<0.0125]) / length(AvgDistAbs),4)*100,
      N = length(AvgDistAbs))







## Plot

## plot discrete
library(ggplot2)
plot1 <- ggplot(AvgDistData[AvgDistData$treatment=="Discrete",], aes(x=Time, y=AvgDistAbs, group=name)) +
  geom_line(color="grey60") +
  geom_line(data=AvgDistData[AvgDistData$name=="Overall" & AvgDistData$treatment=="Discrete",], size=2) +
  ylim(0,0.4) +
  ggtitle("Discrete") + 
  theme(plot.title = element_text(lineheight=.8, face="bold"))

## plot Continuous slow
plot2 <- ggplot(AvgDistData[AvgDistData$treatment=="Continuous Slow",], aes(x=Time, y=AvgDistAbs, group=name)) +
  geom_line(colour="grey60") +
  geom_line(data=AvgDistData[AvgDistData$name=="Overall" & AvgDistData$treatment=="Continuous Slow",], size=2) +
  ylim(0,0.4) +
  ggtitle("Continuous Slow") + 
  theme(plot.title = element_text(lineheight=.8, face="bold"))


## plot Continuous instant
plot3 <- ggplot(AvgDistData[AvgDistData$treatment=="Continuous Instant",], aes(x=Time, y=AvgDistAbs, group=name)) +
  geom_line(colour="grey60") +
  geom_line(data=AvgDistData[AvgDistData$name=="Overall" & AvgDistData$treatment=="Continuous Instant",], size=2) +
  ylim(0,0.4) +
  ggtitle("Continuous Instant") + 
  theme(plot.title = element_text(lineheight=.8, face="bold"))


library(gridExtra)
# Overall, Average AvgDist over the period 
grid.arrange(plot1,plot2,plot3)

#Multi Plot####
#  SUMMARY OF AVGDIST OVER TIME
# used in paper, 
TitleSize = 14
LegendSize = 12
AxisSize = 11

# In paper
  ggplot(data=AvgDistGraph, aes(x=Period, y=AvgDist, group=session,shape=treatment,colour=treatment)) + 
  geom_point(size=3.5) +
  geom_line(size = 1.5) +
  #ggtitle(paste("Average Distance from Equilibrium  (by treatment, by session, average of each full period)")) + 
  ylim(0,0.22) +
  labs(colour = "Treatment")  +
  theme_bw() + 
  xlab("              Period (12 periods each session)") + ylab("    Average Distance \n    from Pure Nash Equilibrium") + 
  theme(plot.title = element_text(lineheight=1, hjust = 0, face="bold", size =TitleSize),
        legend.position= "top",
        legend.text = element_text(size=LegendSize),
        legend.title = element_text(size = LegendSize),
        axis.title  = element_text(hjust=0),
        axis.text = element_text(size=AxisSize),
        axis.title.x = element_text(size=AxisSize+1),
        axis.title.y = element_text(size=AxisSize+2),
        plot.title = element_text(size = TitleSize),
        legend.key = element_blank()) +
  geom_hline(yintercept = c(0.1715),colour="#808080",linetype="longdash") +
  scale_colour_manual(name="Treatment:    ",
                      breaks=c("Discrete","Continuous Slow","Continuous Instant"),
                      labels=c("Discrete       ","Continuous Slow      ","Continuous Instant"),
                      values=c("Red","DarkGreen", "Blue")) 
#For PDF: 10in by 4.5in

# Is AvgDist sig different from zero? ----
temp = as.data.frame(
  dplyr::summarize(
    dplyr::group_by(AvgDistGraph, Period, session, treatment),
    AvgAvgDist = mean(AvgDist),
    MedAvgDist = median(AvgDist))
)
t.test(temp[temp$treatment == "Discrete",]$AvgAvgDist)
t.test(temp[temp$treatment == "Continuous Instant",]$AvgAvgDist)
t.test(temp[temp$treatment == "Continuous Slow",]$AvgAvgDist)

t.test(temp[temp$treatment == "Discrete",]$MedAvgDist)
t.test(temp[temp$treatment == "Continuous Instant",]$MedAvgDist)
t.test(temp[temp$treatment == "Continuous Slow",]$MedAvgDist)
# actually, this isn't the right way to do this... use blocked bootstrap standard errors. 



########
# plots AvgAbsDist in human-only location games averaged period-by-period over all silos in each treatment.  

AvgDistGraph2 = dplyr::summarize(
  dplyr::group_by(AvgDistGraph, treatment, Period),
  AvgDist = mean(AvgDist)
  )

#for plot "AvgAbsDist by period and treatment"
# Figure 4: AvgAbsDist by period and treatment
ggplot(data=AvgDistGraph2, aes(x=Period, y=AvgDist, shape=treatment, colour=treatment, group = treatment)) + 
  geom_line(aes(colour = treatment, shape=treatment), size = 1.5) +
  geom_point(aes(colour = treatment),size=3.5) +
  #ggtitle(paste("Average Distance from Equilibrium  (by treatment, by session, average of each full period)")) + 
  #ylim(0,0.22) +
  labs(colour = "Treatment")  +
  theme_bw() + 
  xlab("              Period (12 periods each session)") + ylab("    Average Distance \n    from Pure Nash Equilibrium") + 
  theme(plot.title = element_text(lineheight=1, hjust = 0, face="bold", size =TitleSize),
        legend.position= "top",
        legend.text = element_text(size=LegendSize),
        legend.title = element_text(size = LegendSize),
        axis.title  = element_text(hjust=0),
        axis.text = element_text(size=AxisSize),
        axis.title.x = element_text(size=AxisSize+1),
        axis.title.y = element_text(size=AxisSize+2),
        plot.title = element_text(size = TitleSize),
        legend.key = element_blank()) +
  geom_hline(yintercept = c(0.1715),colour="#808080",linetype="longdash") +
  scale_colour_manual(name="Treatment:    ",
                      breaks=c("Discrete","Continuous Slow","Continuous Instant"),
                      labels=c("Discrete       ","Continuous Slow      ","Continuous Instant"),
                      values=c("Red","DarkGreen", "Blue")) +
  scale_shape(guide = 'none')
#for pdf 10in by 4.5in



# plot called "average distance from Equilibrium. avgdist on aveage, by traement, over the period"
#plot with focus on average of avg dist metric
# note: for periods, each period, for cont time treatments, summary each seccond. 
#Figure 5 "AvgAbsDist by second, by treatment over the period"
ggplot(dplyr::filter(AvgDistData, name=="Overall"), aes(x=Time, y=AvgDistAbs,color=treatment)) +
  geom_line(size = 2) +
#   geom_line(aes(x=Time, y = 0.264*(1/Time) + 0.140*(Time-1)/Time),xend = 180, yend = .1,
#             size = 1.5, alpha = 0.5, color = "Red") +
#   geom_line(aes(x=Time, y = 0.264*(1/Time) + 0.0632*(Time-1)/Time),xend = 180, yend = .1,
#             size = 1.5, alpha = 0.5, color = "Blue") +
#   geom_line(aes(x=Time, y = 0.264*(1/Time) + 0.0478*(Time-1)/Time),xend = 180, yend = .1,
#             size = 1.5, alpha = 0.5, color = "DarkGreen") +
  ggtitle(paste("Average Distance from Equilibrium (on average by second, by treatment, over the period)")) + 
  xlab("               Time (seconds)") + ylab("     Average Distance \n    from Pure Nash Equilibrium") + 
  theme_bw() + 
  ylim(0,0.18) +
  xlim(0,180) +
  scale_x_continuous(breaks = seq(0,180,60)) +
  theme(plot.title = element_text(lineheight=1, hjust = 0, face="bold", size =TitleSize),
        legend.position= "top",
        legend.text = element_text(size=LegendSize),
        legend.title = element_text(size = LegendSize),
        axis.title  = element_text(hjust=0),
        axis.text = element_text(size=AxisSize),
        axis.title.x = element_text(size=AxisSize+1),
        axis.title.y = element_text(size=AxisSize+2),
        plot.title = element_text(size = TitleSize),
        legend.key = element_blank())  +  
  geom_hline(yintercept = c(0.1715),colour="#808080",linetype="longdash") +
  scale_colour_manual(name="Treatment:    ",
                      breaks=c("Discrete","Continuous Slow","Continuous Instant"),
                      labels=c("Discrete       ","Continuous Slow      ","Continuous Instant"),
                      values=c("Red","DarkGreen", "Blue")) 
  #10 by 4.5



################
# New graph summarizing results
AvgDistData2 <- data.frame(Period=NULL, AvgAbsDist=NULL, Treatment=NULL)
temp <- subset(AvgDistData, name != "Overall")
for (treatmnt in unique(AvgDistData$treatment)){
  temp2 <-  subset(temp, treatment == treatmnt)
#   if (treatmnt == "Discrete"){
#     for (per in unique(temp2$period)){
#       CurPeriod = per - 2
#       temp3 <- subset(temp2, period == per)
#       for (tim in unique(temp3$Time)){
#         print(paste(treatmnt, "  ", CurPeriod,"  ",tim))
#         temp4 <- subset(temp3, Time == tim)
#         AvgDistMetric <- median(temp4$AvgDistAbs)
#         PeriodTime = CurPeriod + (tim / 180)
#         AvgDistData2 <- rbind(AvgDistData2, 
#                               data.frame(Period=PeriodTime,
#                                          AvgAbsDist=AvgDistMetric,
#                                          Treatment=treatmnt))
#       }
#     } 
#   } else 
    {
    for (per in unique(temp2$period)){
      CurPeriod = per - 2
      temp3 <- subset(temp2, period == per)
      for (tim in seq(from=5,to=175,by=10)){
        print(paste(treatmnt, "  ", CurPeriod,"  ",tim))
        temp4 <- subset(temp3, Time > tim - 5 & Time < tim + 5)
        AvgDistMetric <- median(temp4$AvgDistAbs)
        PeriodTime = CurPeriod + (tim / 180)
        AvgDistData2 <- rbind(AvgDistData2, 
                              data.frame(Period=PeriodTime,
                                         AvgAbsDist=AvgDistMetric,
                                         Treatment=treatmnt))
      }
    } 
    
  }
}

ggplot(AvgDistData2, aes(x=Period, y=AvgAbsDist, color=Treatment)) +
  geom_line(size = 1) +
  ggtitle(paste("Average Distance from Equilibrium \n  (for each treatment, the median of 10-second intervals, over full session)")) + 
  ylim(0,0.2) +
  xlab("               Periods (each lasts 180 seconds)") + ylab("     Average Distance   from Pure Nash Equilibrium") + 
  theme_bw() + 
  facet_wrap(~Treatment,ncol = 1) +
  theme(plot.title = element_text(lineheight=1, hjust = 0, face="bold", size =TitleSize),
        legend.position= "top",
        legend.text = element_text(size=12),
        legend.title = element_text(size = 12),
        axis.title  = element_text(hjust=0),
        axis.text = element_text(size=AxisSize),
        axis.title.x = element_text(size=AxisSize+1),
        axis.title.y = element_text(size=AxisSize+2),
        strip.text.x = element_blank()) +  
  scale_colour_manual(name="Treatment:    ",
                      breaks=c("Discrete","Continuous Slow","Continuous Instant"),
                      labels=c("Discrete       ","Continuous Slow      ","Continuous Instant"),
                      values=c("Red","DarkGreen", "Blue")) +
  geom_vline(xintercept = 1:13, color="grey")



################
# OVERALL AVERAGE AVERAGE DISTANCE FROM EQUILIBRIUM FOR EACH TREATMENT
median(subset(AvgDistData, treatment == "Discrete"& name != "Overall")$AvgDistAbs)
mean(subset(AvgDistData, treatment == "Discrete" & name == "Overall")$AvgDistAbs)
median(subset(AvgDistData, treatment == "Continuous Slow"& name != "Overall")$AvgDistAbs)
mean(subset(AvgDistData, treatment == "Continuous Slow" & name == "Overall")$AvgDistAbs)
median(subset(AvgDistData, treatment == "Continuous Instant"& name != "Overall")$AvgDistAbs)
mean(subset(AvgDistData, treatment == "Continuous Instant" & name == "Overall")$AvgDistAbs)



########################
#Trying to do the new Noissar Regression for convergence
library(plyr)
library(reshape2)
library(quantmod)

NewTemp <- melt(AvgDistData[1:3],id=c("name","Time"))
merge(NewTemp,AvgDistData)

###
# 
RandAvgDistABSGenerator <- function(n){
  #given an integer, 
  # returns a vector of that length with AvgDistABS of random iid values. 
  p1 <- c(runif(n,0,1))
  p2 <- c(runif(n,0,1))
  p3 <- c(runif(n,0,1))
  p4 <- c(runif(n,0,1))
  
  absDIST <- function(x){
    # x = c(1,2,3,4)
    x <- sort(x)
    abs <- ( abs(x[1]-0.25) + abs(x[2]-0.25) + abs(x[3]-0.75) + abs(x[4]-0.75) )  / 4
    return(abs)
  }
  
  temp <- data.frame(p1=p1,p2=p2,p3=p3,p4=p4,absdist=0)
  temp$absdist <- apply(temp[,1:4],1,absDIST)
  
  return(temp$absdist)
  
}




RandAvgDistGenerator <- function(n){
  #given an integer, 
  # returns a vector of that length with AvgDist of random iid values. 
  
  p1 <- c(runif(n,0,1))
  p2 <- c(runif(n,0,1))
  p3 <- c(runif(n,0,1))
  p4 <- c(runif(n,0,1))
  
  absDIST <- function(x){
    # x = c(1,2,3,4)
    x <- sort(x)
    AvgDist <- ( (x[1]-0.25) + (x[2]-0.25) + (x[3]-0.75) + (x[4]-0.75) )  / 4
    return(AvgDist)
  }
  
  temp <- data.frame(p1=p1,p2=p2,p3=p3,p4=p4,absdist=0)
  temp$absdist <- apply(temp[,1:4],1,absDIST)
  
  return(temp$absdist)
  
}






# Compare AvgDist to Uniform Dist  
  # Discrete time Average Dist compared to uniform dist
t.test(AvgDistDS$AvgDistAbs, mu=0.1714702, conf.level=0.99)
  # pvale=0.00, 99%conf interval = (0.1393789, 0.1448893)

# CS time Average Dist compared to uniform dist
t.test(AvgDistCS$AvgDistAbs, mu=0.1714702, conf.level=0.99)
  # pvale=0.00, 99%conf interval = (0.07396408, 0.07500000)

# CI time Average Dist compared to uniform dist
t.test(AvgDistCI$AvgDistAbs, mu=0.1714702, conf.level=0.99)
  # pvale=0.00, 99%conf interval = (0.06461310, 0.06579826)

################################################################
# Compare AvgDist (without absolution values) to uniform dist, and to pure NE
ggplot(AvgDistData, aes(x=Time, y=AvgDist, group=name)) +
  #  geom_line(colour="grey50") +
  #  geom_line(data=AvgDistData[AvgDistData$treatment=="Discrete",],colour="skyblue") +
  #  geom_line(data=AvgDistData[AvgDistData$treatment=="Continuous Slow",], colour="darkolivegreen1") +
  #  geom_line(data=AvgDistData[AvgDistData$treatment=="Continuous Instant",],colour="rosybrown1") +  
  geom_line(data=AvgDistData[AvgDistData$name=="Overall" & AvgDistData$treatment=="Discrete",], size=1, colour="Red") +
  geom_line(data=AvgDistData[AvgDistData$name=="Overall" & AvgDistData$treatment=="Continuous Slow",], size=1, colour="Blue") +
  geom_line(data=AvgDistData[AvgDistData$name=="Overall" & AvgDistData$treatment=="Continuous Instant",], size=1, colour="DarkGreen") +
  ylim(-0.06,0.06) +
  xlab("Time") + ylab("Average Distance from Pure Nash Equilibrium")

## plot discrete
library(ggplot2)
plot1 <- ggplot(AvgDistData[AvgDistData$treatment=="Discrete",], aes(x=Time, y=AvgDist, group=name)) +
  geom_line(color="grey60") +
  geom_line(data=AvgDistData[AvgDistData$name=="Overall" & AvgDistData$treatment=="Discrete",], size=2) +
  ylim(-0.4,0.4) +
  ggtitle("Discrete") + 
  theme(plot.title = element_text(lineheight=.8, face="bold"))

## plot Continuous slow
plot2 <- ggplot(AvgDistData[AvgDistData$treatment=="Continuous Slow",], aes(x=Time, y=AvgDist, group=name)) +
  geom_line(colour="grey60") +
  geom_line(data=AvgDistData[AvgDistData$name=="Overall" & AvgDistData$treatment=="Continuous Slow",], size=2) +
  ylim(-0.4,0.4) +
  ggtitle("Continuous Slow") + 
  theme(plot.title = element_text(lineheight=.8, face="bold"))


## plot Continuous instant
plot3 <- ggplot(AvgDistData[AvgDistData$treatment=="Continuous Instant",], aes(x=Time, y=AvgDist, group=name)) +
  geom_line(colour="grey60") +
  geom_line(data=AvgDistData[AvgDistData$name=="Overall" & AvgDistData$treatment=="Continuous Instant",], size=2) +
  ylim(-0.4,0.4) +
  ggtitle("Continuous Instant") + 
  theme(plot.title = element_text(lineheight=.8, face="bold"))

library(gridExtra)
grid.arrange(plot1,plot2,plot3)

# discrete
mean(AvgDistDS$AvgDist)
sd(AvgDistDS$AvgDist)
t.test(AvgDistDS$AvgDist, conf.level=0.99)

# CS
mean(AvgDistCS$AvgDist)
sd(AvgDistCS$AvgDist)
t.test(AvgDistCS$AvgDist, conf.level=0.99)

# CI
mean(AvgDistCI$AvgDist)
sd(AvgDistCI$AvgDist)
t.test(AvgDistCI$AvgDist, conf.level=0.99)


#histogram
layout(matrix(c(1,2,3), 3, 1, byrow = TRUE))
HistwNormDist(AvgDistDS$AvgDist, xlim=c(-0.4,0.4))
HistwNormDist(AvgDistCS$AvgDist, xlim=c(-0.4,0.4))
HistwNormDist(AvgDistCI$AvgDist, xlim=c(-0.4,0.4))

# Collect variances of period distributions
sdDS = c() 
for (i in unique(subset(AvgDistDS,name!="Overall")$name)){sdDS=c(sdDS,sd(subset(AvgDistDS,name!=i)$AvgDist))}
sdCS = c() 
for (i in unique(subset(AvgDistCS,name!="Overall")$name)){sdCS=c(sdCS,sd(subset(AvgDistCS,name!=i)$AvgDist))}
sdCI = c() 
for (i in unique(subset(AvgDistCI,name!="Overall")$name)){sdCI=c(sdCI,sd(subset(AvgDistCI,name!=i)$AvgDist))}

layout(matrix(c(1,2,3), 3, 1, byrow = TRUE))
hist(sdDS,xlim=c(0,0.2))
abline(v=0.144,col="red")
hist(sdCS,xlim=c(0,0.2))
abline(v=0.144,col="red")
hist(sdCI,xlim=c(0,0.2))
abline(v=0.144,col="red")


#continued from above
length(AvgDistDS$AvgDistAbs[(AvgDistDS$AvgDistAbs)<0.0125]) / length(AvgDistDS$AvgDistAbs)
length(AvgDistCS$AvgDistAbs[(AvgDistCS$AvgDistAbs)<0.0125]) / length(AvgDistCS$AvgDistAbs)
length(AvgDistCI$AvgDistAbs[(AvgDistCI$AvgDistAbs)<0.0125]) / length(AvgDistCI$AvgDistAbs)


# Compare AvfDist to eachother. 
t.test(AvgDistCI$AvgDist,AvgDistCS$AvgDist, conf.level=0.99)
t.test(AvgDistCI$AvgDist,AvgDistDS$AvgDist, conf.level=0.99)
t.test(AvgDistDS$AvgDist,AvgDistCS$AvgDist, conf.level=0.99)


# sort the AvgDistData dataset
temp <- arrange(AvgDistData,name,Time)

# Reg of three diff results over time
regDS <- lm(AvgDistAbs~Time,data=subset(AvgDistData,treatment=="Discrete"))
regCS <- lm(AvgDistAbs~Time,data=subset(AvgDistData,treatment=="Continuous Slow"))
regCI <- lm(AvgDistAbs~Time,data=subset(AvgDistData,treatment=="Continuous Instant"))


# Distribution of AvgDistAbs metric given uniform random actions. 
#refers to a.1, a collection of AvgDistAbs from 9,999,999 simulated games
mean(a.1)
median(a.1)
sd(a.1)
h=hist(a.1, 100,
     main="Distribution of AvgDistAbs metric given uniform random actions.",
     xlab="AvgDistAbs",
)
xfit<-seq(min(a.1),max(a.1),length=40) 
yfit<-dnorm(xfit,mean=mean(a.1),sd=sd(a.1)) 
yfit <- yfit*diff(h$mids[1:2])*length(a.1) 
lines(xfit, yfit, col="black", lwd=2)

#Now 
mean(b.1)
median(b.1)
sd(b.1)
h=hist(b.1, 100,
       main="Distribution of AvgDist metric given uniform random actions.",
       xlab="AvgDistAbs",
)
xfit<-seq(min(b.1),max(b.1),length=40) 
yfit<-dnorm(xfit,mean=mean(b.1),sd=sd(b.1)) 
yfit <- yfit*diff(h$mids[1:2])*length(a.1) 
lines(xfit, yfit, col="black", lwd=2)



# Tests for Autocorrelation

#discrete
res = regDS$res 
n = length(res) 
mod2 = lm(res[-n] ~ res[-1]) 
summary(mod2)
#With p-val close to zero, simple autocorrelation likely. correcting for this: 


# continuous slow
res = regCS$res 
n = length(res) 
mod2 = lm(res[-n] ~ res[-1]) 
summary(mod2)


# continuous instant





## Robust checks
# just look at continuous time treatments, just look at later periods

ggplot(subset(AvgDistData,treatment!="Overall" & period>10), aes(x=Time, y=AvgDistAbs, group=treatment,color=treatment)) +
  #  geom_line(colour="grey50") +
  stat_smooth(size=2) +
  #  geom_line(data=AvgDistData[AvgDistData$treatment=="Discrete",],colour="skyblue") +
  #  geom_line(data=AvgDistData[AvgDistData$treatment=="Continuous Slow",], colour="darkolivegreen1") +
  #  geom_line(data=AvgDistData[AvgDistData$treatment=="Continuous Instant",],colour="rosybrown1") +  
  #  geom_line(data=AvgDistData[(AvgDistData$name!="Overall" & AvgDistData$treatment=="Discrete" & AvgDistData$period>8),], size=2, colour="Blue") +
  #  geom_line(data=AvgDistData[AvgDistData$name!="Overall" & AvgDistData$treatment=="Continuous Slow" & AvgDistData$period>8,], size=2, colour="Green") +
  #  geom_line(data=AvgDistData[AvgDistData$name!="Overall" & AvgDistData$treatment=="Continuous Instant" & AvgDistData$period>8,], size=2, colour="red") +
  coord_cartesian(ylim = c(0, 0.2)) +
  xlab("Time") + ylab("Average Distance from Pure Nash Equilibrium") +
  theme(legend.position="none")
  





## hist/pdf of Avg Dist by treatments
plot1 = ggplot(AvgDistData[AvgDistData$name!="Overall",], aes(AvgDistAbs)) +
  geom_histogram(aes(y=..density..),binwidth=0.01) +
  facet_grid(~ treatment) + 
  theme_bw() + 
  theme(
    strip.text = element_text(size = 19),
    strip.background = element_rect(fill = "white", color = "white"),
    axis.title = element_text(size = 18),
    axis.text = element_text(size = 16, color = "grey12"),
    title = element_text()
  ) + 
  xlab("Observations of Average Absolute Distance") + ylab("Density") #+
  #geom_vline(xintercept = 0,colour="DarkRed", linetype = "longdash")
# plot 9in by 4in


## CDF
plot2 = ggplot(AvgDistData[AvgDistData$name!="Overall",], aes(AvgDistAbs, colour = treatment)) + 
  stat_ecdf(size=1) +
  xlim(min(AvgDistData$AvgDistAbs),max(AvgDistData$AvgDistAbs)) + 
  theme_bw() + 
  ggtitle("CDF of Average Absolute Distances") + 
  theme(plot.title = element_text(size = 18),
        strip.background = element_rect(fill = "white", color = "white"),
        axis.title = element_text(size = 15),
        axis.text = element_text(size = 14, color = "grey12"),
        legend.key = element_blank(),
        legend.text = element_text(size=12),
        legend.title = element_text(size = 12)) + 
  xlab("Average Absolute Distance") + ylab("Cumulative Density") +
  guides(colour = guide_legend(override.aes = list(size=6))) +
  scale_colour_manual(name="Treatment:    ",
                      breaks=c("Discrete","Continuous Slow","Continuous Instant"),
                      labels=c("Discrete       ","Continuous Slow      ","Continuous Instant"),
                      values=c("Red","DarkGreen", "Blue")) 
# 9 by 6
  
grid.arrange(plot1,plot2,widths=c(0.55, 0.37), nrow=1) #image dimensions 1306 by 361



#####
# Percent of time subjects are certain distancr from eq
temp <- table(as.vector(subset(AvgDistData, treatment == "Discrete")$AvgDistAbs))
names(temp)[temp == max(temp)]
length(subset(AvgDistData, treatment == "Continuous Slow" & AvgDistAbs < 0.0125)$AvgDistAbs) / length(subset(AvgDistData, treatment == "Continuous Slow")$AvgDistAbs)


# percent of time uniform random action are from...
sum(RandAvgDistABSGenerator(100000) < 0.0125) / 100000




###########
# between CS and CI
ks.test(subset(AvgDistData,name!="Overall" & treatment=="Continuous Slow")$AvgDistAbs,
        subset(AvgDistData,name!="Overall" & treatment=="Continuous Instant")$AvgDistAbs)

#between CI and discrete and CS and Discrete
ks.test(subset(AvgDistData,name!="Overall" & treatment=="Discrete")$AvgDistAbs,
        subset(AvgDistData,name!="Overall" & treatment=="Continuous Instant")$AvgDistAbs)
ks.test(subset(AvgDistData,name!="Overall" & treatment=="Discrete")$AvgDistAbs,
        subset(AvgDistData,name!="Overall" & treatment=="Continuous Slow")$AvgDistAbs)


# Plot for all treatments, AvgDistAbs
{
  # but first recorting factor levels to be in correct order
  AvgDistCS$name <- 
    factor(AvgDistCS$name,
           levels = c("4P-CS-L0-a", "4P-CS-L1-a", "4P-CS-L2-a","4P-CS-L3-a", "4P-CS-L4-a", "4P-CS-L5-a",
                      "4P-CS-L6-a", "4P-CS-L7-a", "4P-CS-L8-a","4P-CS-L9-a", "4P-CS-L10-a","4P-CS-L11-a",
                      "4P-CS-L0-b", "4P-CS-L1-b", "4P-CS-L2-b","4P-CS-L3-b", "4P-CS-L4-b", "4P-CS-L5-b",
                      "4P-CS-L6-b", "4P-CS-L7-b", "4P-CS-L8-b","4P-CS-L9-b", "4P-CS-L10-b","4P-CS-L11-b",
                      "4P-CS-L0-c", "4P-CS-L1-c", "4P-CS-L2-c","4P-CS-L3-c", "4P-CS-L4-c", "4P-CS-L5-c",
                      "4P-CS-L6-c", "4P-CS-L7-c", "4P-CS-L8-c","4P-CS-L9-c", "4P-CS-L10-c","4P-CS-L11-c",
                      "Overall"))
  AvgDistDS$name <- 
    factor(AvgDistDS$name,
           levels = c("4P-D-L0-a", "4P-D-L1-a", "4P-D-L2-a","4P-D-L3-a", "4P-D-L4-a", "4P-D-L5-a",
                      "4P-D-L6-a", "4P-D-L7-a", "4P-D-L8-a","4P-D-L9-a", "4P-D-L10-a","4P-D-L11-a",
                      "4P-D-L0-b", "4P-D-L1-b", "4P-D-L2-b","4P-D-L3-b", "4P-D-L4-b", "4P-D-L5-b",
                      "4P-D-L6-b", "4P-D-L7-b", "4P-D-L8-b","4P-D-L9-b", "4P-D-L10-b","4P-D-L11-b",
                      "4P-D-L0-c", "4P-D-L1-c", "4P-D-L2-c","4P-D-L3-c", "4P-D-L4-c", "4P-D-L5-c",
                      "4P-D-L6-c", "4P-D-L7-c", "4P-D-L8-c","4P-D-L9-c", "4P-D-L10-c","4P-D-L11-c",
                      "Overall"))
  AvgDistCI$name <- 
    factor(AvgDistCI$name,
           levels = c("4P-CI-L0-a", "4P-CI-L1-a", "4P-CI-L2-a","4P-CI-L3-a", "4P-CI-L4-a", "4P-CI-L5-a",
                      "4P-CI-L6-a", "4P-CI-L7-a", "4P-CI-L8-a","4P-CI-L9-a", "4P-CI-L10-a","4P-CI-L11-a",
                      "4P-CI-L0-b", "4P-CI-L1-b", "4P-CI-L2-b","4P-CI-L3-b", "4P-CI-L4-b", "4P-CI-L5-b",
                      "4P-CI-L6-b", "4P-CI-L7-b", "4P-CI-L8-b","4P-CI-L9-b", "4P-CI-L10-b","4P-CI-L11-b",
                      "4P-CI-L0-c", "4P-CI-L1-c", "4P-CI-L2-c","4P-CI-L3-c", "4P-CI-L4-c", "4P-CI-L5-c",
                      "4P-CI-L6-c", "4P-CI-L7-c", "4P-CI-L8-c","4P-CI-L9-c", "4P-CI-L10-c","4P-CI-L11-c",
                      "Overall"))
  
                      
                      
 }

# Each and every period played, 
ggplot(subset(AvgDistCS,name!="Overall"), aes(Time,AvgDistAbs)) + geom_line() + facet_wrap(~name, nrow=3) +
  ggtitle("AvgDistAbs for Continuous Slow") +
  theme(plot.title = element_text(face="bold", size=15))
ggplot(subset(AvgDistDS,name!="Overall"), aes(Time,AvgDistAbs)) + geom_line() + facet_wrap(~name, nrow=3) +
  ggtitle("AvgDistAbs for Discrete") +
  theme(plot.title = element_text(face="bold", size=15))
ggplot(subset(AvgDistCI,name!="Overall"), aes(Time,AvgDistAbs)) + geom_line() + facet_wrap(~name, nrow=3) +
  ggtitle("AvgDistAbs for Continuous Instant") +
  theme(plot.title = element_text(face="bold", size=15))

# Is  

library(dplyr)
t.test(dplyr::filter(AvgDistCS,name!="Overall")$AvgDistAbs)





install.packages("plm")
library(plm)
regDS <- plm(AvgDistAbs ~ Time, data=AvgDistDS, index="name")
summary(regDS)
pbgtest(regDS)

regCS <- plm(AvgDistAbs ~ Time, data=AvgDistCS, index="name")
summary(regCS)
pbgtest(regCS)

regCI <- plm(AvgDistAbs ~ Time, data=AvgDistCI, index="name")
summary(regCI)
pbgtest(regCI)
#pbgtest - all have p-values of zero, serial correlation. 


ggplot(subset(AvgDistData,name=="Overall"), aes(Time,AvgDistAbs,color=treatment)) + geom_line(size=1.5) + 
  ggtitle("AvgDistAbs on Avgerage for All Periods, by Treatment") +
  theme(plot.title = element_text(face="bold", size=15))

regDS <- arima(AvgDistDS$AvgDistAbs,order=c(1,0,0))
regDS
hist(regDS$residuals)
qqnorm(regDS$residuals)
shapiro.test(regDS$residuals)

regCS <- arima(AvgDistCS$AvgDistAbs,order=c(1,0,0))
regCS

regCI <- arima(AvgDistCI$AvgDistAbs,order=c(1,0,0))
regCI




# Simple OLS Regression
reg.temp <- lm(AvgDistAbs ~ Time + factor(treatment) + Time*factor(treatment),data=subset(AvgDistData.temp,name=="Overall"))

AvgDistData <- arrange(AvgDistData,name,treatment,Time)
AvgDistData.temp <- subset(AvgDistData)
plot(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs,
     ylim=c(0,.2), 
     col="pink",
     pch=8,
     xlab="Time",
     ylab="AvgDistABS")
lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs, 
      col = "pink",
      lty= 3 )

regDS <- lm(AvgDistAbs ~ Time, data=subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete"))
abline(regDS,col="red")

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$Time,
       subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$AvgDistAbs,
        ylim=c(0,.2), 
        col="skyblue", type="l")

regCS <- lm(AvgDistAbs ~ Time, data=subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow"))
abline(regCS,col="blue")

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$AvgDistAbs,
      ylim=c(0,.2), 
      col="light green")

regCI <- lm(AvgDistAbs ~ Time, data=subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant"))
abline(regCI,col="green")
legend(25,0.2,inset=0.5,title="Treatment",
       c("Discrete","Continuous Slow","Continuous Instant"), fill=c("red","blue","green"),horiz=TRUE)

##
arima(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$AvgDistAbs,c(1,0,0))

plot(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time[-1],diff(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs))
regDS <- lm(diff(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs) ~ subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time[-1])
abline(regDS)
arima((subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs),c(1,0,0))

plot(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$Time[-1],diff(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$AvgDistAbs))
regCS <- lm(diff(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$AvgDistAbs) ~ subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$Time[-1])
abline(regCS)
summary(regCS)
arima((subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$AvgDistAbs),c(1,0,0))


plot(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$Time[-1],diff(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$AvgDistAbs))
regCI <- lm(diff(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$AvgDistAbs) ~ subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$Time[-1])
abline(regCI)
summary(regCI)
arima((subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$AvgDistAbs),c(1,0,0))



# Model with 1/t estimates
AvgDistData <- arrange(AvgDistData,name,treatment,Time)
AvgDistData.temp <- subset(AvgDistData)
plot(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs,
     ylim=c(0,.2), 
     col="pink",
     pch=8,
     xlab="Time",
     ylab="AvgDistABS")
lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs, 
      col = "pink",
      lty= 3 )

regDS <- lm(AvgDistAbs ~ I(1/(Time)), data=subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete"))
fit2line = predict(regDS, data.frame(Time = 0:180)) 
lines(0:180 ,fit2line, col="red", lwd=3) 

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$AvgDistAbs,
      ylim=c(0,.2), 
      col="skyblue", type="l")

regCS <- lm(AvgDistAbs ~ I(1/(Time)), data=subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow"))
fit2line = predict(regCS, data.frame(Time = 0:180)) 
lines(0:180 ,fit2line, col="blue", lwd=3) 

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$AvgDistAbs,
      ylim=c(0,.2), 
      col="light green")

regCI <- lm(AvgDistAbs ~ I(1/(Time)), data=subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant"))
#regCI.temp <- lm(log(AvgDistAbs) ~ log(I(1/(Time))), data=subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant"))
fit2line = (exp(predict(regCI, data.frame(Time = 0:180))))
lines(0:180 ,fit2line, col="green", lwd=3) 

legend(25,0.2,inset=0.5,title="Treatment",
       c("Discrete","Continuous Slow","Continuous Instant"), fill=c("red","blue","green"),horiz=TRUE)


# Model with 1/t^k estimates
AvgDistData <- arrange(AvgDistData,name,treatment,Time)
AvgDistData.temp <- subset(AvgDistData)
plot(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs,
     ylim=c(0,.2), 
     col="pink",
     pch=8,
     xlab="Time",
     ylab="AvgDistABS")
lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs, 
      col = "pink",
      lty= 3 )

regDS.temp <- lm(log(AvgDistAbs) ~ log(I(1/(Time))), data=subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete"))
k = regDS.temp$coefficients[2]
regDS <- lm(AvgDistAbs ~ I(1/(Time^k)), 
            data=subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete"))
fit2line = (predict(regDS, data.frame(Time = 0:180)))
lines(0:180 ,fit2line, col="red", lwd=3) 

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$AvgDistAbs,
      ylim=c(0,.2), 
      col="skyblue", type="l")

regCS.temp <- lm(log(AvgDistAbs) ~ log(I(1/(Time))), data=subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow"))
k = regCS.temp$coefficients[2]
regCS <- lm(AvgDistAbs ~ I(1/(Time^k)), 
            data=subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow"))
fit2line = (predict(regCS, data.frame(Time = 0:180)))
lines(0:180 ,fit2line, col="blue", lwd=3) 

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$AvgDistAbs,
      ylim=c(0,.2), 
      col="light green")

regCI.temp <- lm(log(AvgDistAbs) ~ log(I(1/(Time))), data=subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant"))
k = regCI.temp$coefficients[2]
regCI <- lm(AvgDistAbs ~ I(1/(Time^k)), 
            data=subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant"))
fit2line = (predict(regCI, data.frame(Time = 0:180)))
lines(0:180 ,fit2line, col="green", lwd=3) 

legend(25,0.2,inset=0.5,title="Treatment",
       c("Discrete","Continuous Slow","Continuous Instant"), fill=c("red","blue","green"),horiz=TRUE)

plot(regDS$residuals,col="red")
points(regCS$residuals,col="blue")
points(regCI$residuals,col="green")
abline(h=0,col='grey')

# Noussair Method
# used in paper

AvgDistData <- arrange(AvgDistData,name,treatment,Time)
AvgDistData.temp <- subset(AvgDistData, (name=="Overall" | period >= 9) & Time >= 1)
# restrict to periods after period....

AvgDistData.temp$AvgDistAbsDiff <- unlist(by(AvgDistData.temp[,"AvgDistAbs"],AvgDistData.temp[,"name"],function(x) c(NA,diff(x)) ))
AvgDistData.temp$AvgDistAbsPrev <- AvgDistData.temp$AvgDistAbs - AvgDistData.temp$AvgDistAbsDiff
AvgDistData.temp$name = as.factor(AvgDistData.temp$name)

plot(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs,
     ylim=c(0,0.22), 
     col="pink",
     pch=8,
     xlab="Time",
     ylab="AvgDistABS")
abline(h=0.1715,col='grey')
lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs, 
      col = "pink",
      lty= 3 )

regDS <- lm(AvgDistAbs ~ 0 + name:I(1/Time) + I((Time-1)/Time), data=subset(AvgDistData.temp,name!="Overall" & treatment=="Discrete"))
fit2line = (predict(regDS, data.frame(Time = 0:180, name = "4P-D-L11-c")))
lines(0:180 ,fit2line, col="red", lwd=3) 

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$AvgDistAbs,
      ylim=c(0,.2), 
      col="skyblue", type="l")

regCS <- lm(AvgDistAbs ~ 0 + name:I(1/Time) + I((Time-1)/Time), data=subset(AvgDistData.temp,name!="Overall" & treatment=="Continuous Slow" & Time > 0))
fit2line = (predict(regCS, data.frame(Time = 0:180, name = "4P-CS-L11-b")))
lines(0:180 ,fit2line, col="blue", lwd=3) 

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$AvgDistAbs,
      ylim=c(0,.2), 
      col="light green")

regCI <- lm(AvgDistAbs ~ 0 + name:(I(1/Time)) + I((Time-1)/Time), data=subset(AvgDistData.temp,name!="Overall" & treatment=="Continuous Instant" & Time > 0))
fit2line = (predict(regCI, data.frame(Time = 0:180, name="4P-CI-L6-b")))
lines(0:180 ,fit2line, col="green", lwd=3) 

legend(25,0.22,inset=0.5,title="Treatment",
       c("Discrete","Continuous Slow","Continuous Instant"), fill=c("red","blue","green"),horiz=TRUE)
#plot(regDS$residuals,col="red")
#points(regCS$residuals,col="blue")
#points(regCI$residuals,col="green")
#abline(h=0,col='grey')


##### Grpah with Noussair method
ggplot(AvgDistData[AvgDistData$name=="Overall",], aes(x=Time, y=AvgDistAbs,color=treatment)) +
  geom_line(size = 2, alpha = 0.1) +
  geom_line(aes(x=Time, y = 0.264*(1/Time) + 0.140*(Time-1)/Time),xend = 180, yend = .1,
            size = 1.5, alpha = 1, color = "Red") +
  geom_line(aes(x=Time, y = 0.264*(1/Time) + 0.0632*(Time-1)/Time),xend = 180, yend = .1,
            size = 1.5, alpha = 1, color = "Blue") +
  geom_line(aes(x=Time, y = 0.264*(1/Time) + 0.0478*(Time-1)/Time),xend = 180, yend = .1,
            size = 1.5, alpha = 1, color = "DarkGreen") +
  ggtitle(paste("Average Distance from Equilibrium   (on average by second, by treatment, over the period)")) + 
  xlab("               Time (seconds)") + ylab("     Average Distance \n    from Pure Nash Equilibrium") + 
  theme_bw() + 
  ylim(0,0.18) +
  xlim(0,180) +
  theme(plot.title = element_text(lineheight=1, hjust = 0, face="bold", size =19),
        legend.position= "top",
        legend.text = element_text(size=12),
        legend.title = element_text(size = 12),
        axis.title  = element_text(hjust=0),
        axis.text = element_text(size=AxisSize),
        axis.title.x = element_text(size=AxisSize+1),
        axis.title.y = element_text(size=AxisSize+2)) +  
  geom_hline(yintercept = c(0.1715),colour="#808080",linetype="longdash") +
  scale_colour_manual(name="Treatment:    ",
                      breaks=c("Discrete","Continuous Slow","Continuous Instant"),
                      labels=c("Discrete       ","Continuous Slow      ","Continuous Instant"),
                      values=c("Red","DarkGreen", "Blue")) 



# Convergence Patterns over time in hotelling 4-player game ----
# Table 2, Estimates of Equation 4, Convergence Targets by Treatment
library(stargazer)
regNoussa <- lm(AvgDistAbs ~ 0 + I(1/Time) + treatment:I((Time-1)/Time), data=subset(AvgDistData.temp,name!="Overall" & Time >= 1))
summary(regNoussa)
stargazer(regNoussa)

regNoussa <- lm(AvgDistAbs ~ 0 + treatment:I(1/Time) + treatment:I((Time-1)/Time), data=subset(AvgDistData.temp,name=="Overall" & Time >= 1))
summary(regNoussa)

#Test that beta_22 and beta_23 are stat different (result 3)
AvgDistData.temp$CI = ifelse(AvgDistData.temp$treatment == "Continuous Instant", 0, 1)
AvgDistData.temp$CS = ifelse(AvgDistData.temp$treatment == "Continuous Slow", 0, 1)
AvgDistData.temp$DS = ifelse(AvgDistData.temp$treatment == "Discrete", 0, 1)
summary(
  lm(AvgDistAbs ~ 0 + I(1/Time) + I((CI-CS)*(Time-1)/Time) + I(DS*(Time-1)/Time) + I(CS*(Time-1)/Time), 
     data=subset(AvgDistData.temp,name!="Overall" & Time >= 1))
)

# simple linear model
  refSimLin <- lm(AvgDistAbs ~ 0 + treatment + treatment:((Time)), data=subset(AvgDistData.temp,name!="Overall" & Time >= 1))
summary(refSimLin)
stargazer(refSimLin)


# True Noussair Method
# "Noussair Convergence (Noussair et al. 1995)"
AvgDistData.temp <- subset(AvgDistData)

AvgDistData.temp$AvgDistAbsDiff <- unlist(by(AvgDistData[,"AvgDistAbs"],AvgDistData[,"name"],function(x) c(NA,diff(x)) ))
AvgDistData.temp$AvgDistAbs.tminus1.over.t <- AvgDistData.temp$AvgDistAbsPrev / AvgDistData.temp$AvgDistAbs
test <- function(x) {if (x=="Discrete") 1 else 0}
AvgDistData.temp$D.DS <- apply(as.matrix(AvgDistData.temp$treatment),1, test)
test <- function(x) {if (x=="Continuous Instant") 1 else 0}
AvgDistData.temp$D.CI <- apply(as.matrix(AvgDistData.temp$treatment),1, test)
test <- function(x) {if (x=="Continuous Slow") 1 else 0}
AvgDistData.temp$D.CS <- apply(as.matrix(AvgDistData.temp$treatment),1, test)  

#the traditional Noussair convergence regression
reg <- lm(AvgDistAbs ~ 0 + I(D.DS*(1/Time)) + I(D.CS*(1/Time)) + I(D.CI*(1/Time)) + I((Time-1)/Time), data=subset(AvgDistData.temp,name=="Overall"))
summary(reg)

plot(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs,
     ylim=c(0,0.22), 
     col="pink",
     pch=8,
     xlab="Time",
     ylab="AvgDistABS")
abline(h=0.1715,col='grey')
lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Discrete")$AvgDistAbs, 
      col = "pink",
      lty= 3 )
fit2line = (predict(reg, data.frame(D.DS=1, D.CS=0,D.CI=0,Time = 0:180,AvgDistAbs.tminus1.over.t=(-1:179/0:180))))
lines(0:180 ,fit2line, col="red", lwd=3) 

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Slow")$AvgDistAbs,
      ylim=c(0,.2), 
      col="skyblue", type="l")
fit2line = (predict(reg, data.frame(D.DS=0, D.CS=1,D.CI=0,Time = 0:180,AvgDistAbs.tminus1.over.t=(-1:179/0:180))))
lines(0:180 ,fit2line, col="blue", lwd=3) 

lines(subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$Time,
      subset(AvgDistData.temp,name=="Overall" & treatment=="Continuous Instant")$AvgDistAbs,
      ylim=c(0,.2), 
      col="light green")
fit2line = (predict(reg, data.frame(D.DS=0, D.CS=0,D.CI=1,Time = 0:180,AvgDistAbs.tminus1.over.t=(-1:179/0:180))))
lines(0:180 ,fit2line, col="green", lwd=3) 

legend(25,0.22,inset=0.5,title="Treatment",
       c("Discrete","Continuous Slow","Continuous Instant"), fill=c("red","blue","green"),horiz=TRUE)




