
library(plyr)
library(reshape2)
source("HotellingLocSimFunctions.R")
source("GrandMetricsPlots.R")

######################
# Runs simulation in which agents Best Respond
#comlumns:, period, player, startegy0, payoff and 'name' (random number initially)

#   All "Intant Moves" can move anywhere on action space
#   No - "simultaneous_sharespot" => subjects move simultaneously, and can share the same spot
#   "simultaneous_noshare" => subjects move simultaneously, and can't share the same spot
#   "turn_based_sharespot" => subjects take turns in order of subject number (s1, s2..., sn) - location sharing okay
#   "turn_based_noshare" => subjects take turns in order of subject number (s1, s2..., sn) - no location sharing
#   "random_move_sharespot" => which subject moves is random, subject can share a location
#   "random_move_noshare" => which moves is random, subject don't share the same spot
#
#   # All "incremental Moves", can only move one-left, one-right, or stay. 
#   "Increment_sharespot" - simultaneous move, players CAN share same spot
#   "Increment_noshare"   - simultaneous move, players CANNOT share same spot
#   "TurnBased_Increment_noshare" - turn based move (s1, s2, ... sn), players CANNOT share same spot
#   "TurnBased_Increment_sharespot" - turn based, players CAN share same spot



data<-data.frame(cbind(subperiod=0,subject=1:4),strategy0=round(runif(4,0,1),2),payoff=0,name="sim")
#2013 10 05 Something is wrong with the BRls func.... it allows jumps
countr = 0
ptm <- proc.time()
while (!EqTester(data, epsilon=0.015) & (max(data$subperiod) < 300)){
  
  data=CreateNewperiod(data,method = "simultaneous_sharespot")
  countr = countr + 1
  if ((countr %% 20) == 0) {playerPlot(data,"sim")}
  print(countr)
  
} 
playerPlot(data,"sim")
print( proc.time() - ptm)


#####################

#FYI: each loop in the for loop below takes about 20seconds. 
store = data.frame(PeriodsToEq=NULL, Treatment=NULL)
maxTime = 600 #set max number of periods to run

ptm <- proc.time()
treatments =  c("simultaneous_noshare","simultaneous_noshare",
                "Increment_sharespot","Increment_noshare",
                "turn_based_sharespot","turn_based_noshare",
                "TurnBased_Increment_sharespot")
  
for (i in 1:7000){
  
  treat = treatments[i %% length(treatments)+1]
  
  print(paste(" Overall Time:", round((proc.time() - ptm)[1]/60,2),"Minutes"))
  data<-data.frame(cbind(subperiod=0,subject=1:4),strategy0=round(runif(4,0,1),2),payoff=0,name="sim")
  
  #2013 10 05 Something is wrong with the BRls func.... it allows jumps
  
  countr = 0
  while (!EqTester(data, epsilon=0.015) & (max(data$subperiod) < maxTime)){
    
    data=CreateNewperiod(data,method = treat)
    countr = countr + 1
    if ((countr %% 100) == 0) {playerPlot(data,"sim")} #debugging
    
  } 
  
  if (countr == maxTime) {countr = "No Converge"}
  new = data.frame(PeriodsToEq=as.character(countr), Treatment=treat)
  store = rbind(store,new)
  
  #debugging
  print(new)
  playerPlot(data,"sim") #final plot
  
}
save(store, file = "SimulationResultsStore.RData")



store2 <- dplyr::mutate(
  store, 
  Converge = ifelse(PeriodsToEq == "No Converge", 0, 1)
  
  )

dplyr::summarize(
  dplyr::group_by(store2, Treatment),
  PercentConvg = sum(Converge) / length(Converge),
  total = length(Converge)
)





