
##################################################################
# A collection of functions to help run Hotelling simulations
#
#
##################################################################
library(plyr)
library(reshape2)
library(taRifx)
library(dplyr)

#errors
#not goin tto NE
#something wrong with the BR finder



#Payoff Functions################################################################

payoff <- function(data,player,custdenst="uniform",func=func){
  #data (likely a subset), the period you want to calc payoffs for
  #action, the action you want to calc payoffs for. 
  # func must be a saved function (that you create)
  # e.g.:  func=x, x<-function{x-2}, then the cust density function is x-2
  
  #current player's strategy  
  currPeriod <- subset(data,subperiod==max(data$subperiod))
  
  #find current action choices, and put into vector
  ActionVector <- currPeriod$strategy0
  
  for (i in ActionVector) {ActionVector[i]=round(ActionVector[i],2)}
  
  #the player's current action
  action <- subset(currPeriod,subject==player)$strategy0
  
  #find action above and below player's "action" (NA if no such strategy exists),
  #call the strategy above stratAbove, call the action below stratBelow
  #then find and define the market boundries (lowerBoundry and upperBoundry)
  
  # if the player is the lowest action choice:
  if (is.na(sort(ActionVector[ActionVector<action],TRUE)[1])) {
    stratBelow <- 0
    
    # else the strategy below is the action choice just below this player's:
  } else { stratBelow <- sort(ActionVector[ActionVector<action],TRUE)[1] }
  
  # if the player with highest action choice:
  if (is.na(sort(ActionVector[ActionVector>action],FALSE)[1])) {
    stratAbove <- 1
    
    # else the strategy above is the action choice just above this player's:
  } else { stratAbove <- sort(ActionVector[ActionVector>action],FALSE)[1] }
  
  
  #Calc Payoffs 
  
  if (custdenst=="uniform"){
    
    #defineing a uiform cust dentity function
    func <- function(x){
      (x-x)+1
    }
  }
  
  # One Player Game, Trivial Result: if the player is one of the middle players
  if (action==min(ActionVector) & action==max(ActionVector)){ 
    lowerBoundry <- 0
    upperBoundry <- 1
    
  } else {
    #working with a uniform customer density            
    if (action<=min(ActionVector)){ 
      #if the left edge player
      lowerBoundry <- 0
      upperBoundry <- action+(stratAbove-action)/2
      
    } else
      if (action>=max(ActionVector)) {
        #else, if right edge player
        lowerBoundry <- action-(action-stratBelow)/2
        upperBoundry <- 1
        
      } else {
        #for all center players
        lowerBoundry <- action-(action-stratBelow)/2
        upperBoundry <- action+(stratAbove-action)/2
        
      }
  }
  
  # should two players share the same location: 
  #find number of players in this action choice (if num>1, then payoffs are split)
  PAYOFFSS <- integrate(func,lowerBoundry,upperBoundry)$value
  num=length(ActionVector[ActionVector==action])
  PAYOFFSS <- 100*PAYOFFSS/num
  PAYOFFSS <- round(PAYOFFSS,6)
  
  #end for non-uniform customer density    
  
  return(PAYOFFSS)
}


payoffss <- function(data,per){
  #given data, and a period, 
  #returns that data/period with payoff information
  
  library(taRifx)
  currPeriod <- subset(data,subperiod==per)
  sortPeriod <- sort(currPeriod,f= ~ strategy0)
  
  #payoff calc
  
  #need to see if any two players in in the same spot, if they are, then payoffs are split
  
  counter = 0
  for (player in currPeriod$subject){
    
    counter=counter+1
    action = subset(currPeriod,subject==player)$strategy0
    
    currPeriod$payoff[counter]<-payoff(currPeriod,player)
    
  }
  #retrurns the original data frame, for that period, with correct payoff info
  currPeriod
  
}
#payoffss(data,0)

#Instantious Best Response##########################
#for player (an int), calc the best response to the most recent period
InstBestRespns <- function(player,data,place = 1){
  #this function takes one player, and finds the best response over all poosible locations. 
  #it returns the number/location in interger form of the best (and nearest) location response. 
  #place refers to which spot you want (e.g. 1 is top payoffs, 2 is second tip payoffs etc)
  
  library(taRifx)
  currPeriod <- subset(data,subperiod==max(data$subperiod) & subject!=player)
  
  currAction <- subset(data,subperiod==max(data$subperiod) & subject==player)$strategy0
  currPayoff <-  subset(data,subperiod==max(data$subperiod) & subject==player)$payoff
  
  #create vector for all possible actions
  Actions <- data.frame(cbind(action=1:100*0.01),payoff=0,dist=0)
  for (i in 1:100){
    
    #current player's strategy
    strat=round(i/100,2)
    
    #take other players' actions, and plug in out hypothetical, loop
    temp = (rbind(currPeriod,data.frame(subperiod=max(data$subperiod),subject=player,strategy0=strat,payoff=0,name="sim")))
    
    Actions$payoff[i]=payoff(temp,player)
  }
  
  #creates column reflecting the distance between each possible action, & the player's currentAction (aka, distance)
  Actions$dist = as.integer(abs(Actions$action - currAction) * 100)
  
  
  #this next section says, if the strategy associated with the max payoff is equal to the payoff of the previous payoff, 
  #stick with the previous action
  
  #should a new location result in higher payoffs, go to it, 
  #and should there be multiple locations that result in higher payoffs, go to the one nearest.
  #sort first by distance (min to furthest), then sort by payoff (highest to lowest)
  #a <- dplyr::arrange(Actions, desc(payoff), dist)
  
  b = Actions[order(Actions$dist,decreasing=FALSE),]
  a = b[order(b$payoff,decreasing=TRUE),]
  BR = round(a$action[place],2)
  
  return(BR)
}
#InstBestRespns(1,data)

#Cont Time Best Resonse##########################
#for player (an int), calc the best response to the most recent period of: move Left, move Right or Stay
BRlrs <- function(player,data,place = 1, NumMoves = 1){
  #this function takes one player, and given the locations of the other player's in the most recent period, 
  # it finds the best response (left, right or stay). 
  # it returns the number/location in decimal in[0,1] form of that response. 
  # NumMoves: how many increments can you move? default 1
  
  library(taRifx)
  #currPeriod <- subset(data,subperiod==max(data$subperiod) & subject!=player)
  currPeriod <- dplyr::filter(data,subperiod==max(data$subperiod) & subject!=player)
  
  #sortPeriod <- sort(currPeriod,f= ~ strategy0)
  sortPeriod <- dplyr::arrange(currPeriod, strategy0)

  
  #currAction <- subset(data,subperiod==max(data$subperiod) & subject==player)$strategy0
  #currPayoff = subset(data,subperiod==max(data$subperiod) & subject==player)$payoff
  currAction <- dplyr::filter(data,subperiod==max(data$subperiod) & subject==player)$strategy0
  currPayoff <- dplyr::filter(data,subperiod==max(data$subperiod) & subject==player)$payoff
  

  
  Options = data.frame(Payoffs = NULL, Position = NULL)   
  for (i in -NumMoves:NumMoves){
    
    if (currAction+(i/100) > 0 & currAction+(i/100) < 1){
      tempdata = (rbind(sortPeriod,data.frame(subperiod=max(data$subperiod),subject=player,strategy0=(currAction+(i/100)),payoff=0,name="sim")))
      temppayoff = payoff(tempdata,player)
      
      Options = rbind(Options,data.frame(temppayoff = temppayoff, Position = currAction + i/100))    
    }
    
  }
  
  Options <- sort(Options, f = ~-temppayoff)
  
  #in case of tie, stay
  if (max(Options$temppayoff) == currPayoff){
    BR <- currAction
  } else BR <- Options$Position[place]
  
  if (place > length(Options$Position)){BR <- currAction}
  
  
  
  #and, my answer
  return(round(BR,2))
  
  
  
}




#Carry Over###########################
#function that carries over from previous period the action choice of player (an int)
CarryOver <- function(player,data){
  
  currperiod <- subset(data,subperiod==max(subperiod) & subject==player)
  return(currperiod$strategy0)
  
}

############
Newperiod <- function(data){
  #creates a new period, with blank action choices and payoffs. 
  #just a simple step
  prevperiod <- subset(data,subperiod==max(subperiod))
  nextperiod=data.frame(cbind(subperiod=max(data$subperiod)+1,subject=1:max(data$subject)),strategy0=prevperiod$strategy,payoff=0,name="sim")  
  nextperiod=payoffss(nextperiod,max(nextperiod$subperiod))
  return(nextperiod)
  
}



########################
CreateNewperiod <- function(data,method = "simultaneous_sharespot"){
  #this function just calcs the best-responce for all players, 
  #Plus finds payoffs
  #
  # method - how subjects change their strategy
  #   All "Intant Moves" can move anywhere on action space
  #   "simultaneous_sharespot" => subjects move simultaneously, and can share the same spot
  #   "simultaneous_noshare" => subjects move simultaneously, and can't share the same spot
  #   "turn_based_sharespot" => subjects take turns in order of subject number (s1, s2..., sn) - location sharing okay
  #   "turn_based_noshare" => subjects take turns in order of subject number (s1, s2..., sn) - no location sharing
  #   "random_move_sharespot" => which subject moves is random, subject can share a location
  #   "random_move_noshare" => which moves is random, subject don't share the same spot
  #
  #   # All "incremental Moves", can only move one-left, one-right, or stay. 
  #   "Increment_sharespot" - simultaneous move, players CAN share same spot
  #   "Increment_noshare"   - simultaneous move, players CANNOT share same spot
  #   "TurnBased_Increment_noshare" - turn based move (s1, s2, ... sn), players CANNOT share same spot
  #   "TurnBased_Increment_sharespot" - turn based, players CAN share same spot
  
  prevperiod <- subset(data,subperiod==max(subperiod))
  nextperiod <- Newperiod(data)
  
  #STRUCTURE HOW AGENTS MAKE DECISIONS
  #e.g. simultanious move?, sequential?, which best-response to play?, etc.
  cnt = 1
  for (i in 1:max(nextperiod$subject)){
    #for each subject, select ther new location
    
    # simultaneous_sharespot
    if (method == "simultaneous_sharespot"){
      #"simultaneous_sharespot" => subjects move simultaneously, and can share the same spot
      BR <- InstBestRespns(i,prevperiod)
      nextperiod$strategy0[cnt] = round(BR,2)
      cnt = cnt + 1
    } else
      
      # simultaneous_noshare
      if (method == "simultaneous_noshare"){
        #"simultaneous_noshare" => subjects move simultaneously, and can't share the same spot
        ##If a player's BR isthe location another player is on, go to the 2nd BR
        BR <- InstBestRespns(i,prevperiod) 
        OPS = subset(nextperiod,subject!=i)$strategy0
        counter=1
        while (BR %in% OPS){
          BR = InstBestRespns(i,prevperiod,counter)
          counter=counter+1
        }
        nextperiod$strategy0[cnt] = round(BR,2)
        cnt = cnt + 1
      } else 
        
        if (method == "turn_based_sharespot"){
          BR <- InstBestRespns(i,nextperiod) 
          
          nextperiod$strategy0[cnt] = round(BR,2)
          cnt = cnt + 1
          
        } else  
          if (method == "turn_based_noshare"){
            BR <- InstBestRespns(i,nextperiod) 
            
            OPS = subset(nextperiod,subject!=i)$strategy0
            counter=1
            while (BR %in% OPS){
              BR = InstBestRespns(i,prevperiod,counter)
              counter=counter+1
            }
            
            nextperiod$strategy0[cnt] = round(BR,2)
            cnt = cnt + 1
            
          } else 
            if (method == "random_move_sharespot"){
              # a little complicated, so I'll explain, 
              # even though this is a for-loop player over 1:max(nextperiod$subject)
              # this stops after only one player. 
              # 1. player randomly chosen
              # 2. calc BR for this player, 
              # 3. update stragies, and return - it stops the loop after only one player
              
              Player <- sample(1:max(nextperiod$subject), 1)
              BR <- InstBestRespns(Player,nextperiod) 
              nextperiod$strategy0[Player] = round(BR,2)
              nextperiod = payoffss(nextperiod,max(nextperiod$subperiod))
              data=rbind(data,nextperiod)
              return(data)
              
            } else 
              if (method == "random_move_noshare"){
                Player <- sample(1:max(nextperiod$subject), 1)
                BR <- InstBestRespns(Player,nextperiod) 
                
                OPS = subset(nextperiod,subject!=i)$strategy0
                counter=1
                while (BR %in% OPS){
                  BR = InstBestRespns(i,prevperiod,counter)
                  counter=counter+1
                }
                
                nextperiod$strategy0[Player] = round(BR,2)
                nextperiod = payoffss(nextperiod,max(nextperiod$subperiod))
                data=rbind(data,nextperiod)
                return(data)
                
              } else 
                if (method == "Increment_sharespot"){
                  BR <- BRlrs(i,prevperiod) 
                  nextperiod$strategy0[cnt] = round(BR,2)
                  cnt = cnt + 1
                  
                } else 
                  if (method == "Increment_noshare"){
                    BR = BRlrs(i,prevperiod)
                    
                    OPS = subset(prevperiod,subject!=i)$strategy0
                    counter=1
                    NumMoves = 1
                    while (BR %in% OPS){
                      counter=counter+1
                      BR = BRlrs(i,prevperiod,place = counter,NumMoves)
                      NumMoves=NumMoves+1
                    }
                    
                    nextperiod$strategy0[cnt] = round(BR,2)
                    cnt = cnt + 1
                    
                  } else 
                    if (method == "TurnBased_Increment_noshare"){
                      BR = BRlrs(i,nextperiod)
                      
                      OPS = subset(prevperiod,subject!=i)$strategy0
                      counter=1
                      NumMoves = 1
                      while (BR %in% OPS){
                        counter=counter+1
                        BR = BRlrs(i,prevperiod,place = counter,NumMoves)
                        NumMoves=NumMoves+1
                      }
                      
                      nextperiod$strategy0[cnt] = round(BR,2)
                      cnt = cnt + 1
                      
                    } else 
                      if (method == "TurnBased_Increment_sharespot"){
                        BR <- BRlrs(i,nextperiod) 
                        
                        nextperiod$strategy0[cnt] = round(BR,2)
                        cnt = cnt + 1
                        
                      } else return(print("Sorry, Unfamiliar Best Response Scheme"))
    
    
    # For Instant Move:
    # BY WHAT ORDER/SYSTEM TO SUBJECTS MOVE?
    
  }
  
  #calc new payoffs for each location
  nextperiod = payoffss(nextperiod,max(nextperiod$subperiod))
  
  
  #add this row to the existing dataset
  data=rbind(data,nextperiod)
  
  
  return(data)
  
}
#CreateNewperiod(data)

##############
EqTester <- function(data,epsilon=0.01){
  #this function returns TRUE if the 'data''s most recent subperiod is near equilibrium. 
  
  currPeriod = subset(data,subperiod==max(data$subperiod))
  ActionVector <- currPeriod$strategy0
  ActionVector = sort(ActionVector)
  
  ABS = (abs(ActionVector[1]-0.25) + abs(ActionVector[2]-0.25) + abs(ActionVector[3]-0.75) + abs(ActionVector[4]-0.75))/4
  
  return(ABS <= epsilon)  
  
}







