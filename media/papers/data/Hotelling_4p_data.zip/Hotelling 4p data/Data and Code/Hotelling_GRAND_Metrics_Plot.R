
multHist <- function(x,TITLE="TREATMENT"){
  #x needs to take the form c("ticks20120101","treatmentname1","ticks20120101","treatmentname2",...)
  
  FullHistData = c()
  FirstHistData = c()
  SecHistData = c()
      
  for (n in c((1:(length(x)/2))*2)) {
    p_full<-subset(get(x[n-1]), name==x[n])
    
    #for continuous time
    if (sum(p_full$secondsLeft)!=0)  {  
            
            #sets min and max secondsLeft
      mini<-min(p_full$secondsLeft)
      maxi<-max(p_full$secondsLeft)
      
      #creating subsets for 1st and 2nd half of data
      p_1stHalf<-subset(p_full, secondsLeft>=mini+(maxi-mini)/2)
      p_2ndHalf<-subset(p_full, secondsLeft<mini+(maxi-mini)/2)
      
    }
    
    # now, for discrete time
    else {
      
      mini<-min(p_full$subperiod)
      maxi<-max(p_full$subperiod)
      
      #create subsets
      p_full<-p_full[ -c(length(p_full$period):(length(p_full$period)-max(p_full$playersInGroup)+1)),] #removing duplicate period data in ticks
      p_1stHalf<-subset(p_full, subperiod<=0.5*maxi-mini)
      p_2ndHalf<-subset(p_full, subperiod>0.5*maxi-mini)    
      
    }          
    
    #Given Subset information, now:
    #convert subset data into 1000 sample data set
    #cycle for full hist data
    for (i in c(1:20)){
      i=i/100
      count = length(subset(p_full, strategy0>=(i*5-0.05) & strategy0<(i*5))$strategy)
      FullHistData=append(FullHistData,rep((0.025+(i*5-0.05)),((count*1000)%/%length(p_full$strategy0))))
    }
    
    #cycle for 1st-half hist plot data
    for (i in c(1:20)){
      i=i/100
      count = length(subset(p_1stHalf, strategy0>=(i*5-0.05) & strategy0<(i*5))$strategy)
      FirstHistData=append(FirstHistData,rep((0.025+(i*5-0.05)),((count*1000)%/%length(p_1stHalf$strategy0))))
    }
    
    #cycle for 2st-half hist plot data
    for (i in c(1:20)){
      i=i/100
      count = length(subset(p_2ndHalf, strategy0>=(i*5-0.05) & strategy0<(i*5))$strategy)
      SecHistData=append(SecHistData,rep((0.025+(i*5-0.05)),((count*1000)%/%length(p_2ndHalf$strategy0))))
    }
  }
    
  #histograms
  
  X_break=c((0:20)*0.05)
  layout(matrix(c(1,2,3), 1, 3, byrow = TRUE))
  
  hist(FullHistData, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main=paste("Full",TITLE,sep=" ") , col="grey")
  abline(v=0.25, col="grey", lty=2)
  abline(v=0.75, col="grey", lty=2)
  
  hist(FirstHistData, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main="First Half", col="grey")
  abline(v=0.25, col="grey", lty=2)
  abline(v=0.75, col="grey", lty=2)
  
  hist(SecHistData,breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1),main="Second Half", col="grey")
  abline(v=0.25, col="grey", lty=2)
  abline(v=0.75, col="grey", lty=2)
  
}
     
############################################################################################

#for discrete time sessions - the first 50 periods (discrete) or 1st 50 seconds (continuous time)
firstFiftyHist <- function(x,TITLE="TREATMENT"){
  #x needs to take the form c("ticks20120101","treatmentname1","ticks20120101","treatmentname2",...)
  
  FullHistData = c()
  FirstHistData = c()
  SecHistData = c()
  
  for (n in c((1:(length(x)/2))*2)) {
    p_full<-subset(get(x[n-1]), name==x[n])
    
    #for continuous time
    if (sum(p_full$secondsLeft)!=0)  {  
      
      #sets min and max secondsLeft
      mini<-min(p_full$secondsLeft)
      maxi<-max(p_full$secondsLeft)
      
      #creating subsets for 1st 50 and later part of data
      p_1stHalf<-subset(p_full, secondsLeft>=49)
      p_2ndHalf<-subset(p_full, secondsLeft<49)
      
    }
    
    # now, for discrete time
    else {
      
      mini<-min(p_full$subperiod)
      maxi<-max(p_full$subperiod)
      
      #create subsets
      p_full<-p_full[ -c(length(p_full$period):(length(p_full$period)-max(p_full$playersInGroup)+1)),] #removing duplicate period data in ticks
      p_1stHalf<-subset(p_full, subperiod<=49)
      p_2ndHalf<-subset(p_full, subperiod>49)    
      
    }          
    
    #Given Subset information, now:
    #convert subset data into 1000 sample data set
    #cycle for full hist data
    for (i in c(1:20)){
      i=i/100
      
      
      
      count = length(subset(p_full, strategy0>=(i*5-0.05) & strategy0<(i*5))$strategy)
      FullHistData=append(FullHistData,rep((0.025+(i*5-0.05)),((count*1000)%/%length(p_full$strategy0))))
      
    }
    
    #cycle for 1st-half hist plot data
    for (i in c(1:20)){
      i=i/100
      count = length(subset(p_1stHalf, strategy0>=(i*5-0.05) & strategy0<(i*5))$strategy)
      FirstHistData=append(FirstHistData,rep((0.025+(i*5-0.05)),((count*1000)%/%length(p_1stHalf$strategy0))))
      
    }
    
    #cycle for 2st-half hist plot data
    for (i in c(1:20)){
      i=i/100
      count = length(subset(p_2ndHalf, strategy0>=(i*5-0.05) & strategy0<(i*5))$strategy)
      SecHistData=append(SecHistData,rep((0.025+(i*5-0.05)),((count*1000)%/%length(p_2ndHalf$strategy0))))
      
    }
  }
  
  #histograms
  
  X_break=c((0:20)*0.05)
  layout(matrix(c(1,2,3), 1, 3, byrow = TRUE))
  
  hist(FullHistData, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1),ylim=c(0,1500), main=paste("Full",TITLE,sep=" ") , col="grey")
  abline(v=0.25, col="grey", lty=2)
  abline(v=0.75, col="grey", lty=2)
  
  hist(FirstHistData, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1),ylim=c(0,900), main="First 50 Seconds/Subperiods", col="grey")
  abline(v=0.25, col="grey", lty=2)
  abline(v=0.75, col="grey", lty=2)
  
  hist(SecHistData,breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1),ylim=c(0,1200), main="After 50 Seconds/Subperiods", col="grey")
  abline(v=0.25, col="grey", lty=2)
  abline(v=0.75, col="grey", lty=2)
  
}
#########################################################################################################



playerPlot <- function(data, treatname, cont=TRUE, MainTitle="Action Choice Plot",xLab="Time", yLab="Position",robot=FALSE,session=""){
  # Plots subject actions to different colors
  # "data" is the ticks file you want to work with
  # "name" is the name of the period/block you're interested in
  # cont time - this actually reads teh data and if continuous time, runs code for it
  #              if discrete time, it'll run code over subperiods
  # this function produces a plot. 
  # only works for four-players. 
  # robot. with some sessions, we ran robot agents. the robot section marks off the parts of time
  #        in which robots had constant strategies
  
  #naming initial variables and setup.
  X1=treatname
  p4<-subset(data, name==X1)
  payoffs=c()
  location=c()
  
  if (session != ""){if (length(unique(p4$session))==1){session =  as.character(unique(p4$session))}}
  
  #test if period is continuous time or not (this will change the plotting quite a bit)
  # main issue: Cont Time, secondsLeft counts down, while Discrete time subperiods count up. 
  if (sum(unique((subset(data, name==X1))$subperiod))==0){cont=TRUE}else{cont=FALSE}
  
  #if statement, continuous vs discrete time treatment? 
  #distinction is needed because the ticks report doesn't have seconds with discrete (subperiod) periods. 
  if (cont==TRUE){  
    
    #for continuous time, set up plot
    
    plot(I(max(p4$secondsLeft+1)-p4$secondsLeft),p4$strategy0, type="n", 
         main=paste(X1,"- Continuous Time - Color=Player",session,sep=" "), 
         ylim=c(0,1),
         ylab=yLab , 
         xlab=xLab
    )
    abline(v=max(p4$secondsLeft), col = "gray", lty=1)
    
    maxlength=max(p4$secondsLeft)
    minlength=min(p4$secondsLeft)
    
  }  else { 
    
    #discrete time, set up plot 
    xLab="Periods"
    plot(p4$subperiod,p4$strategy0, type="n", main=paste(X1,"- Continuous Time - Color=Player",session,sep=" "),ylab=yLab , xlab=xLab, ylim=c(0,1), )
    abline(v=max(p4$subperiod), col = "gray", lty=1)
    
    maxlength=max(p4$subperiod)
    minlength=min(max(p4$subperiod))
  }
  
  #adding verticle lines for where robts change their strategies 
  # this reveals strechs of time where robots actions are constant, 
  # ie where we expect subjects to try to best respond.  
  if (robot == TRUE){
    
    #need to change this for 12 to six players 
    botData <- subset(p4,subject>6)
    index <- c()
    
    #if continuosu time
    if (sum(unique((subset(data, name==X1))$subperiod))==0){
      #code to draw boxes where robots are constant. 
      starts = c() #vector of all starts of periods of constant robots
      stops = c() #VECTOR of all ends of long periods of constant robot actions
      MaxTime = max(botData$secondsLeft)
      subjs = unique(p4$subject)
      for (cnt in 20:(length(subt$strategy0)-20)){
        status = c()
        for (robo in unique(botData$subject)){
          subt <- subset(botData,subject==robo)
          if (subt$strategy0[cnt]==subt$strategy0[cnt-1] && subt$strategy0[cnt]==subt$strategy0[cnt+1]){
            status = c(status,"continueflat")
            } else {
            if (subt$strategy0[cnt]!=subt$strategy0[cnt-1] && subt$strategy0[cnt]==subt$strategy0[cnt+1]){
              status = c(status,"endmove")
            } else {
              if (subt$strategy0[cnt]==subt$strategy0[cnt-1] && subt$strategy0[cnt]!=subt$strategy0[cnt+1]){
                status = c(status,"startmove")
                } else {
                  if (subt$strategy0[cnt]!=subt$strategy0[cnt-1] && subt$strategy0[cnt]!=subt$strategy0[cnt+1]){
                status = c(status,"contMove")
                  }
                }
              } 
            }
        }
        #We've created out 'status' vector for this second, 
        # now let's check if this is a start or stop of a long period of constant robot actions
        
        if (length(status[status=="continueflat"])>=1 
            && length(status[status=="startmove"])>=1 
            && length(status[status=="contMove"])==0){
          Mark = MaxTime - subt$secondsLeft[cnt]
          stops = c(stops,Mark)
        } else
          if (length(status[status=="continueflat"])>=2 
              && length(status[status=="endmove"])>=1 
              && length(status[status=="contMove"])==0){
            Mark = MaxTime - subt$secondsLeft[cnt]
            starts = c(starts,Mark)
          }
      }
      
    } #end of the continuous time section
    
    else #for discrete time now:
      
    { if (sum(unique((subset(data, name==X1))$subperiod))!=0){
      #code to draw boxes where robots are constant. 
      starts = c() #vector of all starts of periods of constant robots
      stops = c() #VECTOR of all ends of long periods of constant robot actions
      MaxTime = max(botData$subperiod)
      subjs = unique(p4$subject)
      for (cnt in 2:(length(subt$strategy0)-2)){
        status = c()
        for (robo in unique(botData$subject)){
          subt <- subset(botData,subject==robo)
          if (subt$strategy0[cnt]==subt$strategy0[cnt-1] && subt$strategy0[cnt]==subt$strategy0[cnt+1]){
            status = c(status,"continueflat")
          } else {
            if (subt$strategy0[cnt]!=subt$strategy0[cnt-1] && subt$strategy0[cnt]==subt$strategy0[cnt+1]){
              status = c(status,"endmove")
            } else {
              if (subt$strategy0[cnt]==subt$strategy0[cnt-1] && subt$strategy0[cnt]!=subt$strategy0[cnt+1]){
                status = c(status,"startmove")
              } else {
                if (subt$strategy0[cnt]!=subt$strategy0[cnt-1] && subt$strategy0[cnt]!=subt$strategy0[cnt+1]){
                  status = c(status,"contMove")
                }
              }
            } 
          }
        }
        #We've created out 'status' vector for this second, 
        # now let's check if this is a start or stop of a long period of constant robot actions
        
        if (length(status[status=="continueflat"])>=1 
            && length(status[status=="startmove"])>=1 
            && length(status[status=="contMove"])==0){
          Mark = subt$subperiod[cnt]
          stops = c(stops,Mark)
        } else
          if (length(status[status=="continueflat"])>=2 
              && length(status[status=="endmove"])>=1 
              && length(status[status=="contMove"])==0){
            Mark = subt$subperiod[cnt]
            starts = c(starts,Mark)
          }
      }
      
    }
    }
    
    #draw background rectangles for time-spells in which robots are constant
    stops=stops[stops>min(starts)]
    stops=c(stops,MaxTime)
    StopCnt = 1
    StartCnt = 1
    while (StartCnt < length(starts)+1){
      while (starts[StartCnt]==stops[StopCnt]){
        StopCnt=StopCnt+1
        StartCnt = StartCnt + 1}
      while (starts[StartCnt]>stops[StopCnt]){
        StopCnt=StopCnt+1}
      rect(stops[StopCnt], 0, starts[StartCnt], 1 , col="pink")    
      #print(c(starts[StartCnt],stops[StopCnt]))
      StartCnt = StartCnt + 1
    }
    
    abline(v=index, col = "gray", lty=2) 
     
  }
  
  
  #Drawing a different colored line for each player's actions
  # for loop over each player's actions. 
  ActionColors=c("red","blue","black","orange")
  COUNTER=1
  
  for (PLAYER in unique((subset(data, name==X1))$subject)) {     #(PLAYER in 7:9){#
    OnePLayersActions <- subset(p4, subject==PLAYER)
    if (cont==TRUE){
      points(I(max(OnePLayersActions$secondsLeft)-OnePLayersActions$secondsLeft),OnePLayersActions$strategy0, type="p" ,col=ActionColors[COUNTER])  
    } else {
      lines(OnePLayersActions$strategy0, type="p" ,col=ActionColors[COUNTER])
      
    }
    
    #data for subtitle (below), player payoffs information. 
    payoffs[COUNTER]=mean(OnePLayersActions$payoff)
    location[COUNTER]=COUNTER*(maxlength-minlength)/5
    
    COUNTER=COUNTER+1
  }
  
  
  mtext((paste
         ("Red Payoffs: ",round(payoffs[1],digits=2),
          " - Blue Payoffs: ",round(payoffs[2],digits=2),
          " - Black Payoffs: ",round(payoffs[3],digits=2),
          " - Orange Payoffs: ",round(payoffs[4],digits=2))  
  )
  )
  
  #ref lines. outline of space, plus equilibrium actions. 
  abline(h=0.25, col = "gray", lty=1)
  abline(h=0.75, col = "gray", lty=1)
  abline(h=0, col = "gray", lty=1)
  abline(h=1, col = "gray", lty=1)
  abline(v=0, col = "gray", lty=1)
  
}

hotellingPlot <- function(data, treatname, cont=TRUE, MainTitle="Action Choice Plot",xLab="Time", yLab="Position"){
  # Plots subject actions to different colors - sorted by edge, center1, center2 and right-edge player
  # "data" is the ticks file you want to work with
  # "name" is the name of the period/block you're interested in
  # cont is: TRUE for continuous time, FALSE is this period/block is discrete time (uses subperiods). 
  # this function produces a plot. 
  
  
  X1=treatname
  p4<-subset(data, name==X1)
  
  
  if (sum(unique((subset(data, name==X1))$subperiod))==0){  #for continuous time
    
    plot(I(max(p4$secondsLeft)-p4$secondsLeft),p4$strategy0, type="n", main=paste(X1,"- Continuous Time - Colors Sorted",sep=" "), ylim=c(0,1),
         ylab=yLab , xlab=xLab
    )
    abline(v=max(p4$secondsLeft), col = "gray", lty=1)
    
    #Drawing a different colored line for each player's actions
    #Sorting & Attaching
    #Note with ConG-Time, seconds left counts down!
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,I(max(p4$secondsLeft)-secondsLeft), sort)) )
    
    ord1 <- subset(p4, L1==1)
    ord2 <- subset(p4, L1==2)
    ord3 <- subset(p4, L1==3)
    ord4 <- subset(p4, L1==4)
    
    lines(ord1$L2, type="p" ,col="red")
    lines(ord2$L2, type="p" ,col="blue")
    lines(ord3$L2, type="p" ,col="black")
    lines(ord4$L2, type="p" ,col="orange")
    
  }
  
  else{ #discrete time
    
    plot(p4$subperiod-1,p4$strategy0, type="n", main=paste(X1,"- Discrete Time - Colors Sorted",sep=" "),ylab=yLab , xlab=xLab, ylim=c(0,1), )
    abline(v=max(p4$subperiod), col = "gray", lty=1)
    
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,p4$subperiod, sort)) )
    
    ord1 <- subset(p4, L1==1)
    ord2 <- subset(p4, L1==2)
    ord3 <- subset(p4, L1==3)
    ord4 <- subset(p4, L1==4)
    
    lines(ord1$L2, type="p" ,col="red")
    lines(ord2$L2, type="p" ,col="blue")
    lines(ord3$L2, type="p" ,col="black")
    lines(ord4$L2, type="p" ,col="orange")
    
  }
  
  abline(h=0.25, col = "gray", lty=1)
  abline(h=0.75, col = "gray", lty=1)
  abline(h=0, col = "gray", lty=1)
  abline(h=1, col = "gray", lty=1)
  abline(v=0, col = "gray", lty=1)
  
  
  
}






quickPlot <- function(data, treatname, eq=NULL, MainTitle="Action Choice Plot",xLab="Time", yLab="Position") {
  #Plot function good for any number of subjects
  
  plot_temp<-subset(data, name==treatname)
  
  if (sum(plot_temp$secondsLeft)!=0)
    
  {
    
    plot(I(max(plot_temp$secondsLeft)-plot_temp$secondsLeft),plot_temp$strategy0, type="n", main=paste(treatname,"- Continuous Time",sep=" "),
         ylab=yLab , xlab=xLab, ylim=c(0,1)
    )
    for (i in unique(plot_temp$subject)) {
      tempdata<-subset(plot_temp, subject==i)
      lines(tempdata$strategy0, type="p" ,col="black")
      
    }
  }
  
  else
    
  {
    plot(plot_temp$subperiod,plot_temp$strategy0, type="n", main=paste(treatname,"- Discrete Time",sep=" "), ylim=c(0,1),
         ylab=yLab , xlab=xLab )
    for (i in unique(plot_temp$subject)) {
      tempdata<-subset(plot_temp, subject==i)
      lines(tempdata$strategy0, type="p" ,col="black")
    }    
    
  }
  
  
  abline(h=0, col = "gray", lty=1)
  abline(h=1, col = "gray", lty=1)
  abline(v=0, col = "gray", lty=1)
  
  for (i in eq){
    abline(h=i, col = "gray", lty=1)
  }
  
}


histHotelling <- function(data, treatname, HISTS = 1) {
  
  if (HISTS == 1){
  p_full<-subset(data, name==treatname)
  if (sum(p_full$secondsLeft)!=0)  {  #for cont time
    
    X_break=c((0:20)*0.05)
    
    #sets min and max secondsLeft
    mini<-min(p_full$secondsLeft)
    maxi<-max(p_full$secondsLeft)
    
    #create subsets
    p_1stHalf<-subset(p_full, secondsLeft>=mini+(maxi-mini)/2)
    p_2ndHalf<-subset(p_full, secondsLeft<mini+(maxi-mini)/2) 
    
    #histograms
    hist(p_full$strategy0, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main=paste("Full",treatname,sep=" ") , col="grey")
    abline(v=0.25, col="grey", lty=2)
    abline(v=0.75, col="grey", lty=2)
    
    hist(p_1stHalf$strategy0, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main="First Half", col="grey")
    abline(v=0.25, col="grey", lty=2)
    abline(v=0.75, col="grey", lty=2)
    
    hist(p_2ndHalf$strategy0,breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main="Second Half", col="grey")
    abline(v=0.25, col="grey", lty=2)
    abline(v=0.75, col="grey", lty=2)
    
    
  }
  
  else { #for discrete time
    
    X_break=c((0:20)*0.05)
    
    mini<-min(p_full$subperiod)
    maxi<-max(p_full$subperiod)
    
    #create subsets
    p_full<-p_full[ -c(length(p_full$period):(length(p_full$period)-max(p_full$playersInGroup)+1)),] #removing duplicate period data in ticks
    p_1stHalf<-subset(p_full, subperiod<=0.5*maxi-mini)
    p_2ndHalf<-subset(p_full, subperiod>0.5*maxi-mini)
    
    #Create Window for Three Charts
    
    
    #histograms
    hist(p_full$strategy0, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main=paste("Full",treatname,sep=" ") , col="grey")
    abline(v=0.25, col="grey", lty=2)
    abline(v=0.75, col="grey", lty=2)
    
    hist(p_1stHalf$strategy0, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main="1st Half", col="grey")
    abline(v=0.25, col="grey", lty=2)
    abline(v=0.75, col="grey", lty=2)
    
    hist(p_2ndHalf$strategy0,breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main="Later Half", col="grey")
    abline(v=0.25, col="grey", lty=2)
    abline(v=0.75, col="grey", lty=2)
    
  } 
  } else if (HISTS == 2) {
    p_full<-subset(data, name==treatname)
    if (sum(p_full$secondsLeft)!=0)  {  #for cont time
      
      X_break=c((0:20)*0.05)
      
      #sets min and max secondsLeft
      mini<-min(p_full$secondsLeft)
      maxi<-max(p_full$secondsLeft)
      
      #create subsets
      p_1stHalf<-subset(p_full, secondsLeft>=mini+(maxi-mini)/2)
      p_2ndHalf<-subset(p_full, secondsLeft<mini+(maxi-mini)/2) 
      
      #histograms
      
      hist(p_1stHalf$strategy0, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main="First Half", col="grey")
      abline(v=0.25, col="grey", lty=2)
      abline(v=0.75, col="grey", lty=2)
      
      hist(p_2ndHalf$strategy0,breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main="Second Half", col="grey")
      abline(v=0.25, col="grey", lty=2)
      abline(v=0.75, col="grey", lty=2)
      
      
    }
    
    else { #for discrete time
      
      X_break=c((0:20)*0.05)
      
      mini<-min(p_full$subperiod)
      maxi<-max(p_full$subperiod)
      
      #create subsets
      p_full<-p_full[ -c(length(p_full$period):(length(p_full$period)-max(p_full$playersInGroup)+1)),] #removing duplicate period data in ticks
      p_1stHalf<-subset(p_full, subperiod<=0.5*maxi-mini)
      p_2ndHalf<-subset(p_full, subperiod>0.5*maxi-mini)
      
      #Create Window for Three Charts
      
      
      #histograms
      
      hist(p_1stHalf$strategy0, breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main="1st Half", col="grey")
      abline(v=0.25, col="grey", lty=2)
      abline(v=0.75, col="grey", lty=2)
      
      hist(p_2ndHalf$strategy0,breaks=X_break, xlab="Location", ylab="Frequency",xlim=c(0,1), main="Later Half", col="grey")
      abline(v=0.25, col="grey", lty=2)
      abline(v=0.75, col="grey", lty=2)
      
    } 
    
  }

}
  


avgDist <- function(data, treatname) {
  
  #naming initial variables and setup.
  X1=treatname
  p4<-subset(data, name==X1)
  payoffs=c()
  location=c()
  
  xLab="Time"
  yLab="Average Distance from Static Pure NE"
  
  #test for continuous time or not
  if (sum(unique((subset(data, name==X1))$subperiod))==0){cont=TRUE}else{cont=FALSE}
  
  #if statement, continuous vs discrete time treatment? 
  #distinction is needed because the ticks report doesn't have seconds with discrete (subperiod) periods. 
  if (sum(unique((subset(data, name==X1))$subperiod))==0){  
    
    #for continuous time, set up plot
    
    plot(I(max(p4$secondsLeft)-p4$secondsLeft),p4$strategy0, type="n", main=paste(X1,"- Cont'Time - AvgDist from Eq",sep=" "), 
         ylim=c(0,0.3),
         ylab=yLab , 
         xlab=xLab
    )
    abline(v=(max(p4$secondsLeft)-min(p4$secondsLeft)), col = "gray", lty=1)
    
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,I(max(p4$secondsLeft)-secondsLeft), sort)) )
    
  }
  
  else{ 
    
    #discrete time, set up plot 
    
    plot(p4$subperiod+1,p4$strategy0, type="n", main=paste(X1,"- Discrete Time - AvgDist from Eq",sep=" "),
         ylab=yLab , 
         xlab=xLab, 
         ylim=c(0,0.3),
    )
    abline(v=max(p4$subperiod), col = "gray", lty=1)
    
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,p4$subperiod, sort)) )
    
  }
  
  
  # Find average distance from eq
  # sort players into position (leftEdge, centerLeft, centerRight, rightEdge)
  ord1 <- subset(p4, L1==1)
  ord2 <- subset(p4, L1==2)
  ord3 <- subset(p4, L1==3)
  ord4 <- subset(p4, L1==4)             
  ABS <- I( ( abs(ord1$L2-0.25)+abs(ord2$L2-0.25)+abs(ord3$L2-0.75)+abs(ord4$L2-0.75) ) / 4 )
  if (cont==TRUE){
    points(I(max(ord4$secondsLeft)-ord4$secondsLeft),ABS,type="l")
  } else {
    lines(ABS)
  }
  avgdist<-mean(ABS)
  
  
  # Index of whether or not subjects tent to pair up
  Pair1 <- I(ord2$L2-ord1$L2)
  Pair2 <- I(ord4$L2-ord3$L2)
  
  if (cont==TRUE){
    points(I(max(ord1$secondsLeft)-ord1$secondsLeft),Pair1,type="l",col = "gray")
    points(I(max(ord1$secondsLeft)-ord1$secondsLeft),Pair2,type="l",col = "gray")
    
  } else {
    lines(Pair1,col = "gray")
    lines(Pair2,col = "gray")
  }
    
  avgPairing = mean(Pair1)+mean(Pair2)
  
  
  mtext((paste("Avg Dist: ",round(avgdist,digits=4)," - Pairing: ",round(avgPairing,digits=4)) ))
  abline(h=0, col = "gray", lty=1)
  abline(h=1, col = "gray", lty=1)
  abline(v=0, col = "gray", lty=1)
  
  
}


AvgDistChart <- function(data, treatname) {
  
  #naming initial variables and setup.
  X1=treatname
  p4<-subset(data, name==X1)
  payoffs=c()
  location=c()
  
  xLab="Time"
  yLab="Average Distance from Static Pure NE"
  
  #test for continuous time or not
  if (sum(unique((subset(data, name==X1))$subperiod))==0){cont=TRUE}else{cont=FALSE}
  
  #if statement, continuous vs discrete time treatment? 
  #distinction is needed because the ticks report doesn't have seconds with discrete (subperiod) periods. 
  if (sum(unique((subset(data, name==X1))$subperiod))==0){  
    
    #for continuous time, set up plot
    
    plot(I(max(p4$secondsLeft)-p4$secondsLeft),p4$strategy0, type="n", main=paste(X1,"- Cont'Time - AvgDist from Eq",sep=" "), 
         ylim=c(0,0.3),
         ylab=yLab , 
         xlab=xLab
    )
    abline(v=(max(p4$secondsLeft)-min(p4$secondsLeft)), col = "gray", lty=1)
    
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,I(max(p4$secondsLeft)-secondsLeft), sort)) )
    
  }
  
  else{ 
    
    #discrete time, set up plot 
    
    plot(p4$subperiod+1,p4$strategy0, type="n", main=paste(X1,"- Discrete Time - AvgDist from Eq",sep=" "),
         ylab=yLab , 
         xlab=xLab, 
         ylim=c(0,0.3),
    )
    abline(v=max(p4$subperiod), col = "gray", lty=1)
    
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,p4$subperiod, sort)) )
    
  }
  
  
  # Find average distance from eq
  # sort players into position (leftEdge, centerLeft, centerRight, rightEdge)
  ord1 <- subset(p4, L1==1)
  ord2 <- subset(p4, L1==2)
  ord3 <- subset(p4, L1==3)
  ord4 <- subset(p4, L1==4)             
  ABS <- I( ( abs(ord1$L2-0.25)+abs(ord2$L2-0.25)+abs(ord3$L2-0.75)+abs(ord4$L2-0.75) ) / 4 )
  if (cont==TRUE){
    points(I(max(ord4$secondsLeft)-ord4$secondsLeft),ABS,type="l")
  } else {
    lines(ABS)
  }
  avgdist<-mean(ABS)
  
  
  # Index of whether or not subjects tent to pair up
  Pair1 <- I(ord2$L2-ord1$L2)
  Pair2 <- I(ord4$L2-ord3$L2)
  
  if (cont==TRUE){
    points(I(max(ord1$secondsLeft)-ord1$secondsLeft),Pair1,type="l",col = "gray")
    points(I(max(ord1$secondsLeft)-ord1$secondsLeft),Pair2,type="l",col = "gray")
    
  } else {
    lines(Pair1,col = "gray")
    lines(Pair2,col = "gray")
  }
  
  avgPairing = mean(Pair1)+mean(Pair2)
  
  
  mtext((paste("Avg Dist: ",round(avgdist,digits=4)," - Pairing: ",round(avgPairing,digits=4)) ))
  abline(h=0, col = "gray", lty=1)
  abline(h=1, col = "gray", lty=1)
  abline(v=0, col = "gray", lty=1)
  
  
}



HotellingMetrics <- function(data, treatname) {
  
  #naming initial variables and setup.
  X1=treatname
  p4<-subset(data, name==X1)
  payoffs=c()
  location=c()
  
  #if statement, continuous vs discrete time treatment? 
  #distinction is needed because the ticks report doesn't have seconds with discrete (subperiod) periods. 
  if (sum(unique((subset(data, name==X1))$subperiod))==0){  
    #for continuous time, set up plot
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,I(max(p4$secondsLeft)-secondsLeft), sort)) )
    
  }
  
  else{ 
    
    #discrete time, set up plot     
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,p4$subperiod, sort)) )
    
  }
  
  
  # Find average distance from eq
  # sort players into position (leftEdge, centerLeft, centerRight, rightEdge)
  ord1 <- subset(p4, L1==1)
  ord2 <- subset(p4, L1==2)
  ord3 <- subset(p4, L1==3)
  ord4 <- subset(p4, L1==4)             
  ABS <- I( ( abs(ord1$L2-0.25)+abs(ord2$L2-0.25)+abs(ord3$L2-0.75)+abs(ord4$L2-0.75) ) / 4 )
  avgdist<-mean(ABS)
  sddist<-sd(ABS)
  
  
  # Index of whether or not subjects tent to pair up
  Pair1 <- I(ord2$L2-ord1$L2)
  Pair2 <- I(ord4$L2-ord3$L2)
  avgPairing = mean(Pair1)+mean(Pair2)
  sdPairing = sd(Pair1)+sd(Pair2)
  
  #Equilibrium Index
  eqs <- 1 - I(I(ord2$L2-ord1$L2)+I(ord4$L2-ord3$L2)) / 0.4
  eqIndex <- mean(eqs)            
  sdeqIndex <- sd(eqs)
  
  
  print(paste(treatname," ",
              "Avg Dist from Eq:",round(avgdist,digits=4)," (",round(sddist,digits=4),") ",
              "Pairing Index:",round(avgPairing,digits=4)," (",round(sdPairing,digits=4),")",
              "Eq Index:",round(eqIndex,digits=4)," (",round(sdeqIndex,digits=4),")",
              sep=","))

}


#Function: returns 4P if in four player game, R# if in robot
GameName <- function(treatname){
  if (grepl("R1",treatname) != 0) {return("R1")} else
  if (grepl("R2",treatname) != 0) {return("R2")} else
  if (grepl("R3",treatname) != 0) {return("R3")} else
  if (grepl("R4",treatname) != 0) {return("R4")} else
  if (grepl("4P",treatname) != 0) {
    if (grepl("a",treatname) != 0) {return("4Pa") } else
    if (grepl("b",treatname) != 0) {return("4Pb") } else
    if (grepl("c",treatname) != 0) {return("4Pc") } else
    if (grepl("d",treatname) != 0) {return("4Pd") } else
    if (grepl("e",treatname) != 0) {return("4Pe") } else
    if (grepl("f",treatname) != 0) {return("4Pf") } 
  } 
}

Payoff_Sub_per <- function(data,Session,Subject,Period){
  #Given full dataset, the session name, the subject number, and the period number, 
  # returns the average payoff for that period
  subject_subset <- subset(data,session==Session & subject==Subject & period==Period & payoff!=Inf)
  AvgPayoff <- mean(subject_subset$payoff)
  return(round(AvgPayoff,2))
}

Payoff_Sub_Total <- function(data,Session,Subject){
  #Given full dataset, the session name, and the subject number, 
  # returns the average payoff for that session
  Session_subset <- subset(data,session==Session & subject==Subject & payoff!=Inf)
  AvgPayoff <- mean(Session_subset$payoff)*12
  return(round(AvgPayoff,2))
}

sd_Sub_per <- function(data,Session,Subject,Period){
  #Given full dataset, the session name, the subject number, and the period number, 
  # returns the standard deviation of payoffs for that period
  subject_subset <- subset(data,session==Session & subject==Subject & period==Period & payoff!=Inf)
  SDAvgPayoffs <- sd(subject_subset$payoff)
  return(round(SDAvgPayoffs,2))
}

Hotelling_EQ_Metrics <- function(data,Session,treatname){
  
  data_subset <- subset(data,session==Session & name==treatname & payoff!=Inf)
  
  if (sum(unique(data_subset$subperiod)==0)){  
    #for continuous time, set up plot
    Extra_Rows <- nrow(data_subset) %% 4
    if (Extra_Rows != 0){ 
      #For as many rows are are extra (beyond 4), this line removes that # of extra rows
      data_subset <- data_subset[-sample(nrow(data_subset),Extra_Rows),]
    }
    
    data_subset$L1 <- rep(1:4, nrow(data_subset)/4)
    data_subset$L2 <- unlist (with( data_subset, tapply(strategy0,I(max(data_subset$secondsLeft)-secondsLeft), sort)) )    
  }  else {
    #discrete time, set up plot     
    data_subset$L1 <- rep(1:4, nrow(data_subset)/4)
    data_subset$L2 <- unlist (with( data_subset, tapply(strategy0,data_subset$subperiod, sort)) )
  }
  
  ord1 <- subset(data_subset, L1==1)$L2
  ord2 <- subset(data_subset, L1==2)$L2
  ord3 <- subset(data_subset, L1==3)$L2
  ord4 <- subset(data_subset, L1==4)$L2         
  ABS <- I( ( abs(ord1-0.25)+abs(ord2-0.25)+abs(ord3-0.75)+abs(ord4-0.75) ) / 4 )

  avgdist<-round(mean(ABS),4)
  sddist<-round(sd(ABS),4)
  
  Pair1 <- I(ord2-ord1)
  Pair2 <- I(ord4-ord3)
  avgPairing = round(mean(Pair1)+mean(Pair2),4)
  SDavgPairing = round(sd(Pair1)+sd(Pair2),4)
  eqs <- 1 - I(I(ord2-ord1)+I(ord4-ord3)) / 0.4
  eqs <- eqs[eqs<100]
  eqs <- eqs[eqs>-100]
  eqIndex <- round(mean(eqs),3)            
  sdeqIndex <- round(sd(eqs),3)
  
  return(c(avgdist,sddist,avgPairing,SDavgPairing,eqIndex,sdeqIndex))
  
}

Hotelling_AvgDistEQ_Fuct <- function(data,Session,treatname,time=1){
  # data is teh full dataset of all sessions
  # session is the name (a string) of the session
  # treatname is a string of the 'name' (e.g. "4P-D-L0-a") of the game to calc
  #time refers to percent of period to calculate (e.g. 1=100%, 0.5=last half, 0.25=last quarter)
  
  data_subset <- subset(data,session==Session & name==treatname & payoff!=Inf)

  
  if (sum(unique(data_subset$subperiod)==0)){  
    #for continuous time, 
    maxTime <- max(data_subset$secondsLeft)
    data_subset <- subset(data_subset, secondsLeft < maxTime-(1-time)*(maxTime))
    Extra_Rows <- nrow(data_subset) %% 4
    if (Extra_Rows != 0){ 
      #For as many rows are are extra (beyond 4), this line removes that # of extra rows
      data_subset <- data_subset[-sample(nrow(data_subset),Extra_Rows),]
    }
    
    data_subset$L1 <- rep(1:4, nrow(data_subset)/4)
    data_subset$L2 <- unlist (with( data_subset, tapply(strategy0,I(max(data_subset$secondsLeft)-secondsLeft), sort)) )    
  }  else {
    #discrete time,     
    maxsubperiod <- max(data_subset$subperiod)
    data_subset <- subset(data_subset, subperiod > maxsubperiod-(time)*(maxsubperiod))
    data_subset$L1 <- rep(1:4, nrow(data_subset)/4)
    data_subset$L2 <- unlist (with( data_subset, tapply(strategy0,data_subset$subperiod, sort)) )
  }
  
  ord1 <- subset(data_subset, L1==1)$L2
  ord2 <- subset(data_subset, L1==2)$L2
  ord3 <- subset(data_subset, L1==3)$L2
  ord4 <- subset(data_subset, L1==4)$L2         
  ABS <- I( ( abs(ord1-0.25)+abs(ord2-0.25)+abs(ord3-0.75)+abs(ord4-0.75) ) / 4 )
  
  avgdist<-round(mean(ABS),4)
  sddist<-round(sd(ABS),4)
  
  Pair1 <- I(ord2-ord1)
  Pair2 <- I(ord4-ord3)
  avgPairing = round(mean(Pair1)+mean(Pair2),4)
  SDavgPairing = round(sd(Pair1)+sd(Pair2),4)
  eqs <- I( ( I(ord2-ord1)+I(ord4-ord3) ) / (0.00000000001+(I(ord3-ord2)*2)))
  eqs <- eqs[eqs<100]
  eqs <- eqs[eqs>-100]
  eqIndex <- round(mean(eqs),3)            
  sdeqIndex <- round(sd(eqs),3)
  
  return(avgdist)
  
}



#calc Subject Payoffs per Period
SsPayoffs2 <- function(data, treatname) {
  #print a table for this data, and this treatment name with payoffs for each subject
  
  #naming initial variables and setup.
  X1=treatname
  p4<-subset(data, name==X1)
  
  for (i in unique(p4$subject)){
    AvgPayoff <- mean( subset(p4,subject==i)$payoff )
    SDAvgPayoffs <- sd( subset(p4,subject==i)$payoff )
    
    print(paste(treatname, " ","Average Payoff for Player ",i," ",round(AvgPayoff,digits=2),
                "SD Avg Payoff",round(SDAvgPayoffs,digits=2),
                sep=","))
  }
}
 

substrRight <- function(x, n=1){
  #Extracting the last n characters from a string in R
  substr(x, nchar(x)-n+1, nchar(x))
}


#calc Subject Payoffs per Period
SsPayoffs <- function(data, player=1) {
  #print a table for this data, and this treatment name with payoffs for each subject
  
  #naming initial variables and setup.
  X1=player
  p4<-subset(data, subject==X1)
  
  for (i in unique(p4$name)){
    AvgPayoff <- mean( subset(p4,name==i)$payoff )
    SDAvgPayoffs <- sd( subset(p4,name==i)$payoff )
    
    print(paste(i, " ","Average Payoff for Player ",player," ",round(AvgPayoff,digits=2),
                "SD Avg Payoff",round(SDAvgPayoffs,digits=2),
                sep=","))
  }
}

################################################
#Charts payoffs on y-axis, location on x-axis
payoffPlot <- function(x,TITLE="TREATMENT") {
  
  
  MAX=0
  for (n in c((1:(length(x)/2))*2)) {
    p_full<-subset(get(x[n-1]), name==x[n])
    
    if (MAX<max(p_full$payoff)){
      MAX=max(p_full$payoff)
    }
    
  }
  
  plot(c(0,1),c(0,1),ylim=c(0,MAX),type="n",main=TITLE,xlab="Location",ylab="Payoff")
  
  for (n in c((1:(length(x)/2))*2)) {
    p_full<-subset(get(x[n-1]), name==x[n])
    
    points(p_full$strategy0,p_full$payoff)
    
  }
}



fullPlot <- function(data, treatname,sess=""){
  layout(matrix(c(1,1,1,2,3,4,5,5,5), 3, 3, byrow = TRUE))
  playerPlot(data, treatname,session=sess)
  histHotelling(data, treatname)
  avgDist(data, treatname)
    
}


# Function that returns vector of avg distance, given data and treatment name
AvgDistGetter <- function(data,treatname){
      
  #naming initial variables and setup.
  X1=treatname
  p4<-subset(data, name==X1)
  payoffs=c()
  location=c()
  
  #if statement, continuous vs discrete time treatment? 
  #distinction is needed because the ticks report doesn't have seconds with discrete (subperiod) periods. 
  if (sum(unique((subset(data, name==X1))$subperiod))==0){  
    #for continuous time, set up plot
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,I(max(p4$secondsLeft)-secondsLeft), sort)) )
    
  }
  
  else{ 
    
    #discrete time, set up plot     
    p4$L1 <- rep(1:4, nrow(p4)/4)
    p4$L2 <- unlist (with( p4, tapply(strategy0,p4$subperiod, sort)) )
    
  }
  
  
  # Find average distance from eq
  # sort players into position (leftEdge, centerLeft, centerRight, rightEdge)
  ord1 <- subset(p4, L1==1)
  ord2 <- subset(p4, L1==2)
  ord3 <- subset(p4, L1==3)
  ord4 <- subset(p4, L1==4)             
  ABS <- I( ( abs(ord1$L2-0.25)+abs(ord2$L2-0.25)+abs(ord3$L2-0.75)+abs(ord4$L2-0.75) ) / 4 )
  
  return(ABS)


}



RandAvgDistGenerator <- function(n){
  #a function that, given sample size n, returns a uniform distribution of locations, 
  # and finds the avgdist for each
  # used to compare the results we got from experiments to what we'd expect if players were playing randomly, of a ~U(0,1) dist
  p1 <- c(runif(n,0,1))
  p2 <- c(runif(n,0,1))
  p3 <- c(runif(n,0,1))
  p4 <- c(runif(n,0,1))
  
  absDIST <- function(x){
    # x = c(1,2,3,4)
    x <- sort(x)
    abs <- ( abs(x[1]-0.25) + abs(x[2]-0.25) + abs(x[3]-0.75) + abs(x[4]-0.75) )  / 4
    return(abs)
  }
  
  temp <- data.frame(p1=p1,p2=p2,p3=p3,p4=p4,absdist=0)
  temp$absdist <- apply(temp[,1:4],1,absDIST)
  
  return(temp$absdist)
  
}







