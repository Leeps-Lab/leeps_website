# Running metrics for 2013 production runs


t20130218 =  c(
              "4P-D-L0-a",
              "4P-D-L1-a",
              "4P-D-L2-a",
              "4P-D-L3-a",
              "4P-D-L4-a",
              "4P-D-L5-a",
              "4P-D-L6-a",
              "4P-D-L7-a",
              "4P-D-L8-a",
              "4P-D-L9-a",
              "4P-D-L10-a",
              "4P-D-L11-a")
            #ticks20131218


#Run over human 4P games
for (i in t20130218) {
  #playerPlot(ticks20130218,i)
  #histHotelling(ticks20130218,i)
  #avgDist(ticks20130218,i)
  #fullPlot(ticks20130218,i)
  #HotellingMetrics(ticks20130218,i)
  SsPayoffs(ticks20130218,i)
}


####Robot plots
#Run over robot games


robot20130218<- c(
  "1Pvs3R-D-L0-R2",
  "1Pvs3R-D-L0-R1",
  "1Pvs3R-D-L1-R2",
  "1Pvs3R-D-L1-R1",
  "1Pvs3R-D-L2-R2",
  "1Pvs3R-D-L2-R1",
  "1Pvs3R-D-L3-R2",
  "1Pvs3R-D-L3-R1",
  "1Pvs3R-D-L4-R2",
  "1Pvs3R-D-L4-R1",
  "1Pvs3R-D-L5-R2",
  "1Pvs3R-D-L5-R1",
  "1Pvs3R-D-L6-R2",
  "1Pvs3R-D-L6-R1",
  "1Pvs3R-D-L7-R2",
  "1Pvs3R-D-L7-R1",
  "1Pvs3R-D-L8-R2",
  "1Pvs3R-D-L8-R1",
  "1Pvs3R-D-L9-R2",
  "1Pvs3R-D-L9-R1",
  "1Pvs3R-D-L10-R2",
  "1Pvs3R-D-L10-R1",
  "1Pvs3R-D-L11-R2",
  "1Pvs3R-D-L11-R1")


 # Important Note!!! need to change the playerPlotBots function with 12 players!!!!!!!
for (i in robot20130218) {
  playerPlot(ticks20130218,i,robot=TRUE)
  #histHotelling(ticks20130218,i)
  #avgDist(ticks20130218,i)
  #fullPlot(ticks20130218,i)
  #HotellingMetrics(ticks20130218,i)
  #SsPayoffs(ticks20130218,i)
}

#############
# Important Note!!! need to change the playerPlotBots function with 12 players!!!!!!!

for (i in unique(tempnames<-subset(tempticks,substr(name, 1,1)=="1")$name)) {
  playerPlot(tempticks,i,robot=TRUE)
  #histHotelling(ticks20130218,i)
  #avgDist(ticks20130218,i)
  #fullPlot(ticks20130218,i)
  #HotellingMetrics(ticks20130218,i)
  #SsPayoffs(ticks20130218,i)
}
playerPlot(tempticks,treatname,xLab="Time (in 100s of Milliseconds)",robot=TRUE)

library(manipulate)
manipulate(
  playerPlot(ticks20130219DS,TODO,xLab="Time",robot=TRUE),
  TODO=picker(
    "1Pvs3R-D-L0-R2",
    "1Pvs3R-D-L0-R1",
    "1Pvs3R-D-L1-R2",
    "1Pvs3R-D-L1-R1",
    "1Pvs3R-D-L2-R2",
    "1Pvs3R-D-L2-R1",
    "1Pvs3R-D-L3-R2",
    "1Pvs3R-D-L3-R1",
    "1Pvs3R-D-L4-R2",
    "1Pvs3R-D-L4-R1",
    "1Pvs3R-D-L5-R2",
    "1Pvs3R-D-L5-R1",
    "1Pvs3R-D-L6-R2",
    "1Pvs3R-D-L6-R1",
    "1Pvs3R-D-L7-R2",
    "1Pvs3R-D-L7-R1",
    "1Pvs3R-D-L8-R2",
    "1Pvs3R-D-L8-R1",
    "1Pvs3R-D-L9-R2",
    "1Pvs3R-D-L9-R1",
    "1Pvs3R-D-L10-R2",
    "1Pvs3R-D-L10-R1",
    "1Pvs3R-D-L11-R2",
    "1Pvs3R-D-L11-R1"))


############################
#For 2013.02.25 CS 6Ss 6robots Production

Sstreatments <-
  c("4P-CS-L0-a",
    "4P-CS-L1-a",
    "4P-CS-L2-a",
    "4P-CS-L3-a",
    "4P-CS-L4-a",
    "4P-CS-L5-a",
    "4P-CS-L6-a",
    "4P-CS-L7-a",
    "4P-CS-L8-a",
    "4P-CS-L9-a",
    "4P-CS-L10-a",
    "4P-CS-L11-a"
    )


for (i in Sstreatments) {
  #playerPlot(ticks20130225,i)
  #histHotelling(ticks20130225,i)
  #avgDist(ticks20130225,i)
  fullPlot(ticks20130225CS,i)
  #HotellingMetrics(ticks20130225,i)
  #SsPayoffs(ticks20130225,i)
}


library(manipulate)
manipulate(
  playerPlot(ticks20130225,TODO),
  TODO=picker("4P-CS-L0-a",
              "4P-CS-L1-a",
              "4P-CS-L2-a",
              "4P-CS-L3-a",
              "4P-CS-L4-a",
              "4P-CS-L5-a",
              "4P-CS-L6-a",
              "4P-CS-L7-a",
              "4P-CS-L8-a",
              "4P-CS-L9-a",
              "4P-CS-L10-a",
              "4P-CS-L11-a"
  )
)

#robot treatments
Robottreatments <-
  c("1Pvs3R-CS-L0-R2",
    "1Pvs3R-CS-L0-R1",
    "1Pvs3R-CS-L1-R2",
    "1Pvs3R-CS-L1-R1",
    "1Pvs3R-CS-L2-R2",
    "1Pvs3R-CS-L2-R1",
    "1Pvs3R-CS-L3-R2",
    "1Pvs3R-CS-L3-R1",
    "1Pvs3R-CS-L4-R2",
    "1Pvs3R-CS-L4-R1",
    "1Pvs3R-CS-L5-R2",
    "1Pvs3R-CS-L5-R1",
    "1Pvs3R-CS-L6-R2",
    "1Pvs3R-CS-L6-R1",
    "1Pvs3R-CS-L7-R2",
    "1Pvs3R-CS-L7-R1",
    "1Pvs3R-CS-L8-R2",
    "1Pvs3R-CS-L8-R1",
    "1Pvs3R-CS-L9-R2",
    "1Pvs3R-CS-L9-R1",
    "1Pvs3R-CS-L10-R2",
    "1Pvs3R-CS-L10-R1",
    "1Pvs3R-CS-L11-R2",
    "1Pvs3R-CS-L11-R1"
    )


#for robots
playerPlot(ticks20130225,"1Pvs3R-CS-L1-R1",robot=TRUE)

for (i in Robottreatments) {
  playerPlot(ticks20130225,i,robot=TRUE)
  #histHotelling(ticks20130225,i)
  #avgDist(ticks20130225,i)
  #fullPlot(ticks20130225,i)
  #HotellingMetrics(ticks20130225,i)
  #SsPayoffs(ticks20130225,i)
}


# For CI 12Ss session 2012 02 26

#for 4person periods

treatnames <- c("4P-CI-L0-a",  "4P-CI-L0-b",
  "4P-CI-L1-a",	"4P-CI-L1-b",
  "4P-CI-L2-a",	"4P-CI-L2-b",
  "4P-CI-L3-a",	"4P-CI-L3-b",
  "4P-CI-L4-a",	"4P-CI-L4-b",
  "4P-CI-L5-a",	"4P-CI-L5-b",
  "4P-CI-L6-a",	"4P-CI-L6-b",
  "4P-CI-L7-a",	"4P-CI-L7-b",
  "4P-CI-L8-a",	"4P-CI-L8-b",
  "4P-CI-L9-a",	"4P-CI-L9-b",
  "4P-CI-L10-a",	"4P-CI-L10-b",
  "4P-CI-L11-a",	"4P-CI-L11-b")

#fullPlot(ticks20130226,"4P-CI-L11-b")

for (i in treatnames) {
  #playerPlot(ticks20130226,i)
  #histHotelling(ticks20130226,i)
  #avgDist(ticks20130226,i)
  fullPlot(ticks20130226,i)
  #HotellingMetrics(ticks20130226,i)
  #SsPayoffs(ticks20130226,i)
}



# for periods in which humans interacted with robots:

library(manipulate)
manipulate(
  playerPlot(ticks20130226,TODO),
  TODO=picker(
    "1Pvs3R-CI-L0-R1",    "1Pvs3R-CI-L0-R2",    "1Pvs3R-CI-L0-R3",    "1Pvs3R-CI-L0-R4",
    "1Pvs3R-CI-L1-R1",    "1Pvs3R-CI-L1-R2",    "1Pvs3R-CI-L1-R3",    "1Pvs3R-CI-L1-R4",
    "1Pvs3R-CI-L2-R1",    "1Pvs3R-CI-L2-R2",    "1Pvs3R-CI-L2-R3",    "1Pvs3R-CI-L2-R4",
    "1Pvs3R-CI-L3-R1",    "1Pvs3R-CI-L3-R2",    "1Pvs3R-CI-L3-R3",    "1Pvs3R-CI-L3-R4",
    "1Pvs3R-CI-L4-R1",    "1Pvs3R-CI-L4-R2",    "1Pvs3R-CI-L4-R3",    "1Pvs3R-CI-L4-R4",
    "1Pvs3R-CI-L5-R1",    "1Pvs3R-CI-L5-R2",    "1Pvs3R-CI-L5-R3",    "1Pvs3R-CI-L5-R4",
    "1Pvs3R-CI-L6-R1",    "1Pvs3R-CI-L6-R2",    "1Pvs3R-CI-L6-R3",    "1Pvs3R-CI-L6-R4",
    "1Pvs3R-CI-L7-R1",    "1Pvs3R-CI-L7-R2",    "1Pvs3R-CI-L7-R3",    "1Pvs3R-CI-L7-R4",
    "1Pvs3R-CI-L8-R1",    "1Pvs3R-CI-L8-R2",    "1Pvs3R-CI-L8-R3",    "1Pvs3R-CI-L8-R4",
    "1Pvs3R-CI-L9-R1",    "1Pvs3R-CI-L9-R2",    "1Pvs3R-CI-L9-R3",    "1Pvs3R-CI-L9-R4",
    "1Pvs3R-CI-L10-R1",    "1Pvs3R-CI-L10-R2",    "1Pvs3R-CI-L10-R3",    "1Pvs3R-CI-L10-R4",
    "1Pvs3R-CI-L11-R1",    "1Pvs3R-CI-L11-R2",    "1Pvs3R-CI-L11-R3",    "1Pvs3R-CI-L11-R4"
    )  
  )


robonames<-c( "1Pvs3R-CI-L0-R1",    "1Pvs3R-CI-L0-R2",    "1Pvs3R-CI-L0-R3",    "1Pvs3R-CI-L0-R4",
              "1Pvs3R-CI-L1-R1",    "1Pvs3R-CI-L1-R2",    "1Pvs3R-CI-L1-R3",    "1Pvs3R-CI-L1-R4",
              "1Pvs3R-CI-L2-R1",    "1Pvs3R-CI-L2-R2",    "1Pvs3R-CI-L2-R3",    "1Pvs3R-CI-L2-R4",
              "1Pvs3R-CI-L3-R1",    "1Pvs3R-CI-L3-R2",    "1Pvs3R-CI-L3-R3",    "1Pvs3R-CI-L3-R4",
              "1Pvs3R-CI-L4-R1",    "1Pvs3R-CI-L4-R2",    "1Pvs3R-CI-L4-R3",    "1Pvs3R-CI-L4-R4",
              "1Pvs3R-CI-L5-R1",    "1Pvs3R-CI-L5-R2",    "1Pvs3R-CI-L5-R3",    "1Pvs3R-CI-L5-R4",
              "1Pvs3R-CI-L6-R1",    "1Pvs3R-CI-L6-R2",    "1Pvs3R-CI-L6-R3",    "1Pvs3R-CI-L6-R4",
              "1Pvs3R-CI-L7-R1",    "1Pvs3R-CI-L7-R2",    "1Pvs3R-CI-L7-R3",    "1Pvs3R-CI-L7-R4",
              "1Pvs3R-CI-L8-R1",    "1Pvs3R-CI-L8-R2",    "1Pvs3R-CI-L8-R3",    "1Pvs3R-CI-L8-R4",
              "1Pvs3R-CI-L9-R1",    "1Pvs3R-CI-L9-R2",    "1Pvs3R-CI-L9-R3",    "1Pvs3R-CI-L9-R4",
              "1Pvs3R-CI-L10-R1",    "1Pvs3R-CI-L10-R2",    "1Pvs3R-CI-L10-R3",    "1Pvs3R-CI-L10-R4",
              "1Pvs3R-CI-L11-R1",    "1Pvs3R-CI-L11-R2",    "1Pvs3R-CI-L11-R3",    "1Pvs3R-CI-L11-R4")

playerPlot(ticks20130226,"1Pvs3R-CI-L11-R2")

for (i in robonames) {
  playerPlot(ticks20130226,i)
  #histHotelling(ticks20130226,i)
  #avgDist(ticks20130226,i)
  #fullPlot(ticks20130225,i)
  #HotellingMetrics(ticks20130226,i)
  #SsPayoffs(ticks20130226,i)
}
#####################################



#####################################
#The followign makes a nice ggplot of all sessions, by treatment, and by learning level

library(manipulate)
library(ggplot2)
manipulate(
  ggplot(subset(ticks_allHotelling,eval(parse(text=SUBIT))), aes(x=strategy0, y=..density..)) + 
    geom_histogram(binwidth=0.04761905,colour="#808080") +
    geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
    xlim(0,1) +
    labs(title = "", x="Action Space", y="Frequency") +
    facet_wrap(~ treatment),
  SUBIT = picker(
    "All Periods"="Learning_Sense_2!=toString('FOO')",
    "Periods 1-3"="Learning_Sense_2==toString('L1_2')",
    "Periods 4-6"="Learning_Sense_2==toString('L2_2')",
    "Periods 7-9"="Learning_Sense_2==toString('L3_2')",
    "Periods 10-12"="Learning_Sense_2==toString('L4_2')"
  )
)

# 
ggplot(subset(ticks_allHotelling,Learning_Sense_2 %in% c("L3_2","L4_2")), aes(x=strategy0, y=..density..)) + 
  geom_histogram(binwidth=0.04761905,colour="#808080") +
  geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
  xlim(0,1) +
  labs(title = "", x="Action Space", y="Density") +
  facet_wrap(~ treatment) +
  theme(strip.text.x = element_text(colour = "black", size = 20),
        axis.text.y=element_text(size=12),
        axis.text.x=element_text(size=12),
        axis.title.y=element_text(size=16),
        axis.title.x=element_text(size=16))


####################################

library(manipulate)
library(ggplot2)
manipulate(
  ggplot(subset(ticks_allHotelling,eval(parse(text=SUBIT))), aes(x=strategy0, y=..density..)) + 
    geom_histogram(binwidth=0.05,colour="#808080") +
    geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
    xlim(0,1) +
    theme(strip.text.x = element_text(size = 12)) +
    labs(title = "", x="Action Space", y="Frequency") +
    facet_wrap(~ treatment),
  SUBIT = picker(
    "All Periods"="Learning_Sense_2!=toString('FOO')",
    "Periods 1-3"="Learning_Sense_2==toString('L1_2')",
    "Periods 4-6"="Learning_Sense_2==toString('L2_2')",
    "Periods 7-9"="Learning_Sense_2==toString('L3_2')",
    "Periods 10-12"="Learning_Sense_2==toString('L4_2')"
  )
)
######################################
# a single histogram



ggplot(ticks_allHotelling, aes(x=strategy0)) + 
  geom_histogram(aes(y=..count../sum(..count..)),
                 binwidth=0.05,
                 colour="#808080") +
  geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
  xlim(0,1) +
  facet_wrap(~ treatment) +
  theme(strip.text.x = element_text(size = 12)) +
  labs(title = "", x="Action Space", y="relative frequency")

# Discrete time, Treatment results
#  distribution of locations, all data (3 sessions)
ticks_allHotelling_temp <- subset(ticks_allHotelling,treatment=="Discrete")
ggplot(ticks_allHotelling_temp, aes(x=strategy0)) + 
  geom_histogram(aes(y=..count../sum(..count..)),
                 binwidth=0.04761905,
                 colour="#808080") +
  geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
  xlim(0,1) +
  theme(strip.text.x = element_text(size = 12)) +
  labs(title = "", x="Action Space", y="relative frequency")

# Distribution of Locations - All Data
ggplot(ticks_allHotelling, aes(x=strategy0)) + 
  geom_histogram(aes(y=..density..),
                 binwidth=0.04761905,
                 colour="#808080") +
  geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
  facet_wrap(~ treatment) +
  xlim(0,1) +
  theme(strip.text.x = element_text(size = 12)) +
  labs(title = "", x="Action Space", y="Density")

# Distribution of Locations – Last Three Periods
ticks_allHotelling_temp <- subset(ticks_allHotelling,period>=12)
ggplot(ticks_allHotelling_temp, aes(x=strategy0)) + 
  geom_histogram(aes(y=..density..),
                 binwidth=0.04761905,
                 colour="#808080") +
  geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
  xlim(0,1) +
  facet_wrap(~ treatment) +
  theme(strip.text.x = element_text(size = 12)) +
  labs(title = "", x="Action Space", y="Density")



#----

manipulate(
  ggplot(subset(ticks_allHotelling,name==SUBIT)), aes(x=strategy0, y=..density..)) + 
    geom_histogram(binwidth=0.025,colour="#808080") +
    geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
    xlim(0,1) +
    labs(title = "", x="Action Space", y="Frequency") +
    facet_wrap(~ treatment),
  SUBIT = picker(
    "4P-D-L0-a",    "4P-D-L9-a",    "4P-CS-L6-a",    "4P-CI-L1-b",
    "4P-CI-L6-a",    "4P-CI-L10-b",    "4P-CI-L6-c",    "4P-D-L1-c",
    "4P-D-L6-b",    "4P-D-L10-c",    "4P-CS-L3-b",    "4P-CS-L7-c",
    "4P-D-L1-a",    "4P-D-L10-a",    "4P-CS-L7-a",    "4P-CI-L2-a",
    "4P-CI-L6-b",    "4P-CI-L11-a",    "4P-CI-L7-c",    "4P-D-L2-b",
    "4P-D-L6-c",    "4P-D-L11-b",    "4P-CS-L3-c",    "4P-CS-L8-b",
    "4P-D-L2-a",    "4P-D-L11-a",    "4P-CS-L8-a",    "4P-CI-L2-b",
    "4P-CI-L7-a",    "4P-CI-L11-b",    "4P-CI-L8-c",    "4P-D-L2-c",
    "4P-D-L7-b",    "4P-D-L11-c",    "4P-CS-L4-b",    "4P-CS-L8-c",
    "4P-D-L3-a",    "4P-CS-L0-a",    "4P-CS-L9-a",    "4P-CI-L3-a",
    "4P-CI-L7-b",    "4P-CI-L0-c",    "4P-CI-L9-c",    "4P-D-L3-c",
    "4P-D-L7-c",    "4P-CS-L0-c",    "4P-CS-L4-c",    "4P-CS-L9-c",
    "4P-D-L4-a",    "4P-CS-L1-a",    "4P-CS-L10-a",    "4P-CI-L3-b",
    "4P-CI-L8-b",    "4P-CI-L1-c",    "4P-CI-L10-c",    "4P-D-L3-b",
    "4P-D-L8-b",    "4P-CS-L0-b",    "4P-CS-L5-b",    "4P-CS-L9-b",
    "4P-D-L5-a",    "4P-CS-L2-a",    "4P-CS-L11-a",    "4P-CI-L4-a",
    "4P-CI-L8-a",    "4P-CI-L2-c",    "4P-CI-L11-c",    "4P-D-L4-b",
    "4P-D-L8-c",    "4P-CS-L1-b",    "4P-CS-L5-c",    "4P-CS-L10-b",
    "4P-D-L6-a",    "4P-CS-L3-a",    "4P-CI-L0-a",    "4P-CI-L4-b",    "4P-CI-L9-a",
    "4P-CI-L3-c",    "4P-D-L0-b",    "4P-D-L4-c",    "4P-D-L9-b",    "4P-CS-L1-c",    "4P-CS-L6-b",
    "4P-CS-L10-c",    "4P-D-L7-a",    "4P-CS-L4-a",    "4P-CI-L0-b",
    "4P-CI-L5-a",    "4P-CI-L9-b",    "4P-CI-L4-c",    "4P-D-L0-c",
    "4P-D-L5-b",    "4P-D-L9-c",    "4P-CS-L2-b",    "4P-CS-L6-c",
    "4P-CS-L11-b",    "4P-D-L8-a",    "4P-CS-L5-a",    "4P-CI-L1-a",
    "4P-CI-L5-b",    "4P-CI-L10-a",    "4P-CI-L5-c",    "4P-D-L1-b",
    "4P-D-L5-c",    "4P-D-L10-b",    "4P-CS-L2-c",    "4P-CS-L7-b",    "4P-CS-L11-c",    
  )
)



######################################

for (i in unique(subset(ticks_allHotelling,robot=="humans")$name)) {
  #playerPlot(ticks_allHotelling,i)
  #histHotelling(ticks_allHotelling,i)
  #avgDist(ticks_allHotelling,i)
  fullPlot(ticks_allHotelling,i)
  #HotellingMetrics(ticks_allHotelling,i)
  #SsPayoffs(ticks_allHotelling,i)
}

manipulate(
  fullPlot(ticks_allHotelling,TREATMENTS,sess="TRUE"),
  TREATMENTS = picker
  (
    "4P-D-L0-a",    "4P-D-L9-a",    "4P-CS-L6-a",    "4P-CI-L1-b",
    "4P-CI-L6-a",    "4P-CI-L10-b",    "4P-CI-L6-c",    "4P-D-L1-c",
    "4P-D-L6-b",    "4P-D-L10-c",    "4P-CS-L3-b",    "4P-CS-L7-c",
    "4P-D-L1-a",    "4P-D-L10-a",    "4P-CS-L7-a",    "4P-CI-L2-a",
    "4P-CI-L6-b",    "4P-CI-L11-a",    "4P-CI-L7-c",    "4P-D-L2-b",
    "4P-D-L6-c",    "4P-D-L11-b",    "4P-CS-L3-c",    "4P-CS-L8-b",
    "4P-D-L2-a",    "4P-D-L11-a",    "4P-CS-L8-a",    "4P-CI-L2-b",
    "4P-CI-L7-a",    "4P-CI-L11-b",    "4P-CI-L8-c",    "4P-D-L2-c",
    "4P-D-L7-b",    "4P-D-L11-c",    "4P-CS-L4-b",    "4P-CS-L8-c",
    "4P-D-L3-a",    "4P-CS-L0-a",    "4P-CS-L9-a",    "4P-CI-L3-a",
    "4P-CI-L7-b",    "4P-CI-L0-c",    "4P-CI-L9-c",    "4P-D-L3-c",
    "4P-D-L7-c",    "4P-CS-L0-c",    "4P-CS-L4-c",    "4P-CS-L9-c",
    "4P-D-L4-a",    "4P-CS-L1-a",    "4P-CS-L10-a",    "4P-CI-L3-b",
    "4P-CI-L8-b",    "4P-CI-L1-c",    "4P-CI-L10-c",    "4P-D-L3-b",
    "4P-D-L8-b",    "4P-CS-L0-b",    "4P-CS-L5-b",    "4P-CS-L9-b",
    "4P-D-L5-a",    "4P-CS-L2-a",    "4P-CS-L11-a",    "4P-CI-L4-a",
    "4P-CI-L8-a",    "4P-CI-L2-c",    "4P-CI-L11-c",    "4P-D-L4-b",
    "4P-D-L8-c",    "4P-CS-L1-b",    "4P-CS-L5-c",    "4P-CS-L10-b",
    "4P-D-L6-a",    "4P-CS-L3-a",    "4P-CI-L0-a",    "4P-CI-L4-b",    "4P-CI-L9-a",
    "4P-CI-L3-c",    "4P-D-L0-b",    "4P-D-L4-c",    "4P-D-L9-b",    "4P-CS-L1-c",    "4P-CS-L6-b",
    "4P-CS-L10-c",    "4P-D-L7-a",    "4P-CS-L4-a",    "4P-CI-L0-b",
    "4P-CI-L5-a",    "4P-CI-L9-b",    "4P-CI-L4-c",    "4P-D-L0-c",
    "4P-D-L5-b",    "4P-D-L9-c",    "4P-CS-L2-b",    "4P-CS-L6-c",
    "4P-CS-L11-b",    "4P-D-L8-a",    "4P-CS-L5-a",    "4P-CI-L1-a",
    "4P-CI-L5-b",    "4P-CI-L10-a",    "4P-CI-L5-c",    "4P-D-L1-b",
    "4P-D-L5-c",    "4P-D-L10-b",    "4P-CS-L2-c",    "4P-CS-L7-b",    "4P-CS-L11-c"
  )
)



# Creates a small sub-sample
temp<-ticks_allHotelling[sample(nrow(ticks_allHotelling),50),]


# create and print all plots of all production runs, each period of each session. 
for (i in 1:nrow(AllNames)){
  Name = AllNames[i,1]
  session = AllNames[i,2]
  fullPlot(ticks_allHotelling,Name,sess=session)
  filename_1 <- paste(session,"_",Name,".png",sep="")
  dev.copy(png,filename=filename_1,height=1100, width=850,bg="white")
  dev.off()
}




######################################
#Full session review

###IMPORTANT INPUTS####
#Define the Following:
ptm <- proc.time() #start clock
SessionsAndSilos <- c("ticks20130219DS","a", 
                      "ticks20130225CS","a", 
                      "ticks20130226CI","a",
                      "ticks20130226CI","b", 
                      "ticks20130301CI","c", 
                      "ticks20130304DS","b",
                      "ticks20130304DS","c", 
                      "ticks20130304CS","b",
                      "ticks20130304CS","c")
for (i in seq(1,18,2)){ #cycle through Session names and treatment silo ids (a, b, c....)
  Session=as.character(SessionsAndSilos[i]) #see unique(AllNames$session) for all
  SILO=as.character(SessionsAndSilos[i+1])                 #there are a, b and c SILOs. perhaps more later
  
  # setup session review table. 
  Session_review <- data.frame(Title=c("Subject1_Type","Subject1_Payoff","Subject1_sdPayoff",
        "Subject2_Type","Subject2_Payoff","Subject2_sdPayoff",
        "Subject3_Type","Subject3_Payoff","Subject3_sdPayoff",
        "Subject4_Type","Subject4_Payoff","Subject4_sdPayoff",
        "Subject5_Type","Subject5_Payoff","Subject5_sdPayoff",
        "Subject6_Type","Subject6_Payoff","Subject6_sdPayoff",
        "AvgDist","sdDist","PairingI","sdPairing","EqIndex","sdEqIndex"),
        L0=0,L1=0,L2=0,L3=0,L4=0,L5=0,L6=0,L7=0,L8=0,L9=0,L10=0,L11=0,Total=0)
  
  #Full dataset
  data=ticks_allHotelling
  
  #define vector of treatment names
  treatments <- unique(subset(AllNames,session==Session & Silo==SILO)$name)
  
  #find subject numbers (1,3,5,6... or 2,4,6,8...)
  SubjectGroup<-unique(sort(subset(ticks_allHotelling,name %in% treatments)$subject))
  
  #Big matrix of per subject scores
  # since this is a vector, the numbers will be saved as text
  row = 0
  for (Subject in SubjectGroup){
    row = row +1
    
    for (per in 3:14){
      treatname <- unique(subset(data,session==Session & subject==Subject & period==per)$name)
      Session_review[row,(per-1)] <- GameName(treatname)
    }
    row = row +1
    for (per in 3:14){
      Session_review[row,(per-1)] <- Payoff_Sub_per(data, Session, Subject, per)
    }
    row = row +1
    for (per in 3:14){
      Session_review[row,(per-1)] <- sd_Sub_per(data, Session, Subject, per)
    }
  }
  
  # subject totals
  for (subject in seq(2,17,3)){
    Session_review[subject,14] <- sum(as.numeric(Session_review[subject,2:13]))
  }
  
  for (per in 3:14){ #for each period, find summary metrics for non-robot game. 
    treatname <- subset(AllNames,session==Session & Silo==SILO)$name[per-2]
    
    Session_review[19:24,per-1] <- Hotelling_EQ_Metrics(data,Session,treatname)
    
  }
  
  for (i in 19:24){#for overall session, average of per-period metrics
    Session_review[i,14] <- round(mean(as.numeric(Session_review[i,2:13])),4)
  }
  
  assign(paste("Session_review",Session,SILO,sep="_"),Session_review)
  print(proc.time() - ptm) #stop clock
}
proc.time() - ptm #stop clock

#Hotelling_EQ_Metrics(ticks_allHotelling,"ticks20130219DS","4P-D-L0-a")



#----
# Alt form of Session Review
Sessions_Review <- <- data.frame(session="",
                                 period=0,
                                 subject=0,
                                 payoff=0,
                                 treatment="",
                                 silo="",
                                 robot="",
                                 Learning_Sense_1="",
                                 name="")
                                 
SessionsAndSilos <- c("ticks20130219DS","a", 
                      "ticks20130225CS","a", 
                      "ticks20130226CI","a",
                      "ticks20130226CI","b", 
                      "ticks20130301CI","c", 
                      "ticks20130304DS","b",
                      "ticks20130304DS","c", 
                      "ticks20130304CS","b",
                      "ticks20130304CS","c")


#Full dataset
data=ticks_allHotelling

for (i in seq(1,18,2)){ 
  Session=as.character(SessionsAndSilos[i]) #see unique(AllNames$session) for all
  SILO=as.character(SessionsAndSilos[i+1])       

  #define vector of treatment names
  treatments <- unique(subset(ticks_allHotelling,session==Session & silo==SILO)$name)
  
  #find subject numbers (1,3,5,6... or 2,4,6,8...)
  SubjectGroup<-unique(sort(subset(ticks_allHotelling,name %in% treatments)$subject))
  
  row = 0
  for (Subject in SubjectGroup){
    row = row +1
    
    for (per in 3:14){
      treatname <- unique(subset(data,session==Session & subject==Subject & period==per)$name)
      Session_review[row,(per-1)] <- GameName(treatname)
    }
    row = row +1
    for (per in 3:14){
      Session_review[row,(per-1)] <- Payoff_Sub_per(data, Session, Subject, per)
    }
    row = row +1
    for (per in 3:14){
      Session_review[row,(per-1)] <- sd_Sub_per(data, Session, Subject, per)
    }
  }
  
  # subject totals
  for (subject in seq(2,17,3)){
    Session_review[subject,14] <- sum(as.numeric(Session_review[subject,2:13]))
  }
  
  for (per in 3:14){ #for each period, find summary metrics for non-robot game. 
    treatname <- subset(AllNames,session==Session & Silo==SILO)$name[per-2]
    
    Session_review[19:24,per-1] <- Hotelling_EQ_Metrics(data,Session,treatname)
    
  }
  
  for (i in 19:24){#for overall session, average of per-period metrics
    Session_review[i,14] <- round(mean(as.numeric(Session_review[i,2:13])),4)
  }
  
  assign(paste("Session_review",Session,SILO,sep="_"),Session_review)
  
}
                                 
  
  
  
  
  Title=c("Subject1_Type","Subject1_Payoff","Subject1_sdPayoff",
                                         "Subject2_Type","Subject2_Payoff","Subject2_sdPayoff",
                                         "Subject3_Type","Subject3_Payoff","Subject3_sdPayoff",
                                         "Subject4_Type","Subject4_Payoff","Subject4_sdPayoff",
                                         "Subject5_Type","Subject5_Payoff","Subject5_sdPayoff",
                                         "Subject6_Type","Subject6_Payoff","Subject6_sdPayoff",
                                         "AvgDist","sdDist","PairingI","sdPairing","EqIndex","sdEqIndex"),
                                 L0=0,L1=0,L2=0,L3=0,L4=0,L5=0,L6=0,L7=0,L8=0,L9=0,L10=0,L11=0,Total=0)

     
########################
# plotting Avg Dist from Eq for each treatment over periods
# Assuming that we have all our "Session_review_ticks...." reports

Session_reviews = c("Session_review_ticks20130219DS_a","Session_review_ticks20130304DS_b","Session_review_ticks20130304DS_c",
                    "Session_review_ticks20130226CI_a","Session_review_ticks20130226CI_b","Session_review_ticks20130301CI_c",
                    "Session_review_ticks20130225CS_a","Session_review_ticks20130304CS_b","Session_review_ticks20130304CS_c")

AvgDistGraph <- data.frame(AvgDist=0,Ei=0,Period="",session="",treatment="")
AvgDistGraph <- AvgDistGraph[-1,]
for (i in 1:9){ #just taking the AvgDist line from each session review
  for (Lrn in 1:12){
    AvgDistGraph <- rbind(AvgDistGraph,
                          data.frame(AvgDist=as.numeric(eval(parse(text=Session_reviews[i]))[19,Lrn+1]),
                                     Ei=as.numeric(eval(parse(text=Session_reviews[i]))[23,Lrn+1]),
                                     Period=paste(Lrn,sep=""),
                                     session=Session_reviews[i],
                                     treatment=substr(Session_reviews[i],29,30)))
    
  }
}

library(plyr)
AvgDistGraph$treatment <- mapvalues(AvgDistGraph$treatment, 
                                    from = c("DS", "CI","CS"), 
                                    to = c("Discrete","Continuous Instant","Continuous Slow"))


library(ggplot2) 
library(gridExtra)
# Line and dot plot of how AvgDist evolves over periods, by session and treatment type. 
# this took a wile to get right!
ggplot(data=AvgDistGraph, aes(x=Period, y=AvgDist, group=session,colour=treatment)) + 
  geom_point(size=3) +
  geom_line(size=1) +
  ylim(0,0.22) +
  labs(colour = "Treatment")  +
  theme(legend.title=element_text(size=14),
        legend.text=element_text(size=14))

# Same plot as above, but with EquilibriumIndex instead of AvgDist from Eq
ggplot(data=AvgDistGraph, aes(x=Period, y=Ei, group=session,colour=treatment)) + 
  geom_point(size=3) +
  geom_line(size=1) +
  ylim(-0.3,1) +
  labs(colour = "Treatment",y="Equilibrium Index",y="Period",title="Equilibrium Index, by Session")  +
  theme(legend.title=element_text(size=14),
        legend.text=element_text(size=14),
        plot.title=element_text(size=18, hjust = 0))



# # Line and dot plot of how AvgDist evolves over periods, by session and treatment type. 
# Now, with only the second half of perio'd data.
ptm <- proc.time()
Session_reviews = c("Session_review_ticks20130219DS_a","Session_review_ticks20130304DS_b","Session_review_ticks20130304DS_c",
                          "Session_review_ticks20130226CI_a","Session_review_ticks20130226CI_b","Session_review_ticks20130301CI_c",
                          "Session_review_ticks20130225CS_a","Session_review_ticks20130304CS_b","Session_review_ticks20130304CS_c")
      
      LastHalf_AvgDistGraph <- data.frame(AvgDist=0,Period="",session="",SessionName="",treatment="",name="")
      LastHalf_AvgDistGraph <- LastHalf_AvgDistGraph[-1,]
      
      for (i in 1:9){ #just taking the AvgDist line from each session review
        sessionname <- substr(Session_reviews[i],16,30)
        SiLo <-  substr(Session_reviews[i],32,32)
        for (Lrn in 1:12){
          thisName <- subset(AllNames,session==sessionname & Silo==SiLo)$name[Lrn]
          LastHalf_AvgDistGraph <- rbind(LastHalf_AvgDistGraph,
                                          data.frame(AvgDist= Hotelling_AvgDistEQ_Fuct(ticks_allHotelling,sessionname,thisName,0.5),
                                                     Period=paste(Lrn,sep=""),
                                                     session=sessionname,
                                                     SessionName=Session_reviews[i],
                                                     treatment=substr(Session_reviews[i],29,30),
                                                     name = thisName))
          
        }
      }

      ggplot(data=LastHalf_AvgDistGraph, aes(x=Period, y=AvgDist, group=SessionName,colour=treatment)) + 
        geom_point(size=4) +
        geom_line(size=1) +
        ylim(0,0.25)
proc.time() - ptm #about two minutes


# boxplot of average dist
# ABS Learning Session Treatment
substrRight <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}

AvgDistBarplot <- data.frame(ABS=0, Learning="", Session="", Treatment="")
AvgDistBarplot <- AvgDistBarplot[-1,]
for (i in 1:nrow(AllNames)){
  
  MyData <- eval(parse(text=as.character(AllNames[i,2])))
  MyName <- as.character(AllNames[i,1])
  
  MyLearning <- paste("L",((i-1)%%12),sep="")
  MySession <- as.character(AllNames[i,2])
  MyTreatment <- as.character(AllNames[i,3])
  
  tempAvgDistBarplot <- data.frame(ABS=AvgDistGetter(MyData,MyName),
                                   Learning=MyLearning,
                                   Session=MySession,
                                   Treatment=MyTreatment)
    
  AvgDistBarplot = rbind(AvgDistBarplot,tempAvgDistBarplot)
  
}

temp <- subset(AvgDistBarplot,Treatment=="Continuous Slow")
ggplot(AvgDistBarplot, aes(factor(Learning), ABS)) +
  geom_boxplot() + ylim(0,0.3) +labs(x="Learning Level",y="AvgDist") +
  facet_wrap(~ Treatment)


#########################
# Summary Stats

# players in each session
print("Players in each session")
for (i in unique(HL_Test_Results$treatment)){
  result = length(subset(HL_Test_Results,treatment==i)$subject)
  print(paste(i,result))
}

# pre and post HL test
print("Count of HL pre and post tests, by treatment")
for (i in unique(HL_Test_Results$treatment)){
  for (t in unique(HL_Test_Results$pre_post)){
  result = length(subset(HL_Test_Results,treatment==i & pre_post==t)$subject)
  print(paste(i,t,result))
  }
}

# Avg Payoff by treatment
print("Average Payoff for each Treatment (including robot treatments)")
for (i in unique(HL_Test_Results$treatment)){
  result = mean(subset(HL_Test_Results,treatment==i)$payoff)
  print(paste(i,result))
}  
print(paste("Overal",mean(HL_Test_Results$payoff)))

# Avg distance by treatment
print("Average Distance from Eq for each Treatment (not including robot treatments)")
for (i in unique(HL_Test_Results$treatment)){
  result = mean(subset(AvgDistData,treatment==i)$AvgDistAbs)
  print(paste(i,result))
}  
a=mean(subset(AvgDistData,treatment=="Discrete" & name!="Overall")$AvgDistAbs)
b=mean(subset(AvgDistData,treatment=="Continuous Instant" & name!="Overall")$AvgDistAbs)
c=mean(subset(AvgDistData,treatment=="Continuous Slow" & name!="Overall")$AvgDistAbs)
print(paste("Overal",mean(c(a,b,c))))



#
a=(subset(AvgDistData,treatment=="Discrete" & name!="Overall"))
b=(subset(AvgDistData,treatment=="Continuous Instant" & name!="Overall"))
c=(subset(AvgDistData,treatment=="Continuous Slow" & name!="Overall"))

ggplot(AvgDistData, aes(x = Time, y = AvgDistAbs)) +
  geom_line(color=grey)
  
  



#Avg Dist from Eq by Learning Level
print("Average Dist from Eq by Learning Level for each Treatment (not including robot treatments)")
for (i in unique(AvgDistGraph$treatment)){
  for (l in seq(0,9,3)){
    L1 = paste("L",l,sep="")
    L2 = paste("L",l+1,sep="")
    L3 = paste("L",l+2,sep="")
    temp <- subset(AvgDistGraph,subset = Learning %in% c(L1,L2,L3) & treatment==i)
    result = mean(temp$AvgDist)
    result = round(result,4)
    SDresult =round(sd((temp$AvgDist)),4)
    print(paste(i,L1,"to",L3,result,"+-",SDresult))
  }
}
for (l in seq(0,9,3)){
  L1 = paste("L",l,sep="")
  L2 = paste("L",l+1,sep="")
  L3 = paste("L",l+2,sep="")
  temp <- subset(AvgDistGraph,subset = Learning %in% c(L1,L2,L3))
  result = mean(temp$AvgDist)
  result = round(result,4)
  SDresult =round(sd((temp$AvgDist)),4)
  print(paste("Overall",L1,"to",L3,result,"+-",SDresult))
}

#----
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  require(grid)
  
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

#####
# Example of session
# Used in paper
# Three time series plots, one on top of the other. 
layout(matrix(c(1,2,3), 3, 1, byrow = TRUE))
playerPlot(ticks20130304DS, "4P-D-L7-b")
playerPlot(ticks20130226CI, "4P-CI-L7-a")
playerPlot(ticks20130225CS, "4P-CS-L7-a")

#player plots for ALL Human Periods!
#####

# Plot for all treatments, AvgDistAbs
{

  
  
}

temp <- subset(ticks_allHotelling,treatment == "Discrete" & robot == "humans")
temp$name <- 
  factor(temp$name,
         levels = c("4P-D-L0-a", "4P-D-L1-a", "4P-D-L2-a","4P-D-L3-a", "4P-D-L4-a", "4P-D-L5-a",
                    "4P-D-L6-a", "4P-D-L7-a", "4P-D-L8-a","4P-D-L9-a", "4P-D-L10-a","4P-D-L11-a",
                    "4P-D-L0-b", "4P-D-L1-b", "4P-D-L2-b","4P-D-L3-b", "4P-D-L4-b", "4P-D-L5-b",
                    "4P-D-L6-b", "4P-D-L7-b", "4P-D-L8-b","4P-D-L9-b", "4P-D-L10-b","4P-D-L11-b",
                    "4P-D-L0-c", "4P-D-L1-c", "4P-D-L2-c","4P-D-L3-c", "4P-D-L4-c", "4P-D-L5-c",
                    "4P-D-L6-c", "4P-D-L7-c", "4P-D-L8-c","4P-D-L9-c", "4P-D-L10-c","4P-D-L11-c"))
ggplot(temp, aes(x=subperiod, y = strategy0, color = as.factor((subject%%6)+1))) + 
  geom_point() + 
  theme_bw() + 
  ylim(0,1) + 
  facet_wrap(~ name, nrow = 3) + 
  theme(legend.position = "none")

#####
temp <- subset(ticks_allHotelling,treatment == "Continuous Slow" & robot == "humans")
temp$name <- 
  factor(temp$name,
         levels = c("4P-CS-L0-a", "4P-CS-L1-a", "4P-CS-L2-a","4P-CS-L3-a", "4P-CS-L4-a", "4P-CS-L5-a",
                    "4P-CS-L6-a", "4P-CS-L7-a", "4P-CS-L8-a","4P-CS-L9-a", "4P-CS-L10-a","4P-CS-L11-a",
                    "4P-CS-L0-b", "4P-CS-L1-b", "4P-CS-L2-b","4P-CS-L3-b", "4P-CS-L4-b", "4P-CS-L5-b",
                    "4P-CS-L6-b", "4P-CS-L7-b", "4P-CS-L8-b","4P-CS-L9-b", "4P-CS-L10-b","4P-CS-L11-b",
                    "4P-CS-L0-c", "4P-CS-L1-c", "4P-CS-L2-c","4P-CS-L3-c", "4P-CS-L4-c", "4P-CS-L5-c",
                    "4P-CS-L6-c", "4P-CS-L7-c", "4P-CS-L8-c","4P-CS-L9-c", "4P-CS-L10-c","4P-CS-L11-c"))

temp <- subset(ticks_allHotelling,treatment == "Continuous Instant" & robot == "humans")
temp$name <- 
  factor(temp$name,
         levels = c("4P-CI-L0-a", "4P-CI-L1-a", "4P-CI-L2-a","4P-CI-L3-a", "4P-CI-L4-a", "4P-CI-L5-a",
                    "4P-CI-L6-a", "4P-CI-L7-a", "4P-CI-L8-a","4P-CI-L9-a", "4P-CI-L10-a","4P-CI-L11-a",
                    "4P-CI-L0-b", "4P-CI-L1-b", "4P-CI-L2-b","4P-CI-L3-b", "4P-CI-L4-b", "4P-CI-L5-b",
                    "4P-CI-L6-b", "4P-CI-L7-b", "4P-CI-L8-b","4P-CI-L9-b", "4P-CI-L10-b","4P-CI-L11-b",
                    "4P-CI-L0-c", "4P-CI-L1-c", "4P-CI-L2-c","4P-CI-L3-c", "4P-CI-L4-c", "4P-CI-L5-c",
                    "4P-CI-L6-c", "4P-CI-L7-c", "4P-CI-L8-c","4P-CI-L9-c", "4P-CI-L10-c","4P-CI-L11-c"))

ggplot(temp,aes(x=(180 - secondsLeft), y = strategy0, color = as.factor((subject)))) + 
  geom_point() + 
  theme_bw() + 
  ylim(0,1) + 
  facet_wrap(~ name, nrow = 3) + 
  theme(legend.position = "none")



# Histograms used in paper
# "Histograms of Player Positions" is title in paper
# periods 7 - 12
library(scales)
library(ggplot2)
bindwidth.size = 0.02
axis.title.size = 19
axis.text.size = 15

# With bin size 0.02 and max rel freq of 0.25, suggest image is: 472x335, and cut and paste into MSPaint

ticks_DS <- subset(ticks_allHotelling,treatment=="D")
foo <- function(x){if (x>=9 & x<=10){return(1)} else if (x>10){return(2)} else{return(0)}}
ticks_DS$Break <- sapply(ticks_DS$period,foo)
ticks_DS <- subset(ticks_DS,Break!=0 & robot != "robost")
ggplot(ticks_DS, aes(x=strategy0, y=(..count..)/sum(..count..))) + 
  geom_bar(binwidth=0.03,colour="#808080") +
  scale_y_continuous(labels = percent) +
  geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
  xlim(0,1) +
  labs(title="", x = "Positions", y = "Relative Frequency") +
  ylim(0,0.25) +
  theme_bw() +
  theme(axis.title = element_text(size = axis.title.size),
        axis.text = element_text(size = axis.text.size))

ticks_CI <- subset(ticks_allHotelling,treatment=="CI")
ticks_CI$Break <- sapply(ticks_CI$period,foo)
ticks_CI <- subset(ticks_CI,Break!=0 & robot != "robots")
ggplot(ticks_CI, aes(x=strategy0, y=(..count..)/sum(..count..))) +
  #geom_histogram()
  geom_bar(binwidth=bindwidth.size, colour="#808080") +
  #scale_y_continuous(labels = percent) +
  geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
  xlim(0,1) +
  ggtitle("") + 
  xlab("Positions") + ylab("Relative Frequency") +
  ylim(0,0.25) +
  theme_bw() +
  theme(axis.title = element_text(size = axis.title.size),
        axis.text = element_text(size = axis.text.size))

  ticks_CS <- subset(ticks_allHotelling,treatment=="CS")
ticks_CS$Break <- sapply(ticks_CS$period,foo)
ticks_CS <- subset(ticks_CS,Break!=0 & robot != "robots")
ggplot(ticks_CS, aes(x=strategy0, y=(..count..)/sum(..count..))) + 
  geom_bar(binwidth=bindwidth.size,colour="#808080") +
  scale_y_continuous(labels = percent) +
  geom_vline(xintercept = c(0.25,0.75),colour="#808080",linetype="longdash") +
  xlim(0,1) +
  labs(title="", x = "Positions", y = "Relative Frequency") +
  ylim(0,0.25) +
  theme_bw() + 
  theme(axis.title = element_text(size = axis.title.size),
        axis.text = element_text(size = axis.text.size))


#Huck 2002 original data
Huck2002 <- read.csv("~/Dropbox/Hotelling Model & Experiment/Hotelling RStudio Project/Hotelling/HuckMV2003.csv")
library(scales)
library(reshape2)
library(dplyr)

ticks_huck2002 <- rbind(
  data.frame(
    Player = 1,
    merge(
      melt(dplyr::select(Huck2002, SESSION, ROUND, POS_1),
           id = c("SESSION","ROUND"),
           value.name = "Location")[,c(1,2,4)],
      melt(dplyr::select(Huck2002, SESSION, ROUND, PROFIT_1),
           id = c("SESSION","ROUND"),
           value.name = "Payoff")[,c(1,2,4)],
      by = c("SESSION","ROUND"))
  ),
  data.frame(
    Player = 2,
    merge(
      melt(dplyr::select(Huck2002, SESSION, ROUND, POS_2),
           id = c("SESSION","ROUND"),
           value.name = "Location")[,c(1,2,4)],
      melt(dplyr::select(Huck2002, SESSION, ROUND, PROFIT_2),
           id = c("SESSION","ROUND"),
           value.name = "Payoff")[,c(1,2,4)],
      by = c("SESSION","ROUND"))
  ),
  data.frame(
    Player = 3,
    merge(
      melt(dplyr::select(Huck2002, SESSION, ROUND, POS_3),
           id = c("SESSION","ROUND"),
           value.name = "Location")[,c(1,2,4)],
      melt(dplyr::select(Huck2002, SESSION, ROUND, PROFIT_3),
           id = c("SESSION","ROUND"),
           value.name = "Payoff")[,c(1,2,4)],
      by = c("SESSION","ROUND"))
  ),
  data.frame(
    Player = 4,
    merge(
      melt(dplyr::select(Huck2002, SESSION, ROUND, POS_4),
           id = c("SESSION","ROUND"),
           value.name = "Location")[,c(1,2,4)],
      melt(dplyr::select(Huck2002, SESSION, ROUND, PROFIT_4),
           id = c("SESSION","ROUND"),
           value.name = "Payoff")[,c(1,2,4)],
      by = c("SESSION","ROUND"))
  )
)

ticks_huck2002 <- dplyr::arrange(ticks_huck2002, SESSION, ROUND, Player)
ggplot(ticks_huck2002, aes(x=Location,  y=(..count..)/sum(..count..))) + 
  geom_bar(binwidth=bindwidth.size*1000,colour="#808080") +
  scale_y_continuous(labels = percent) +
  geom_vline(xintercept = c(250,750),colour="#808080",linetype="longdash") +
  xlim(0,1000) +
  labs(title="", x = "Positions", y = "Relative Frequency") +
  ylim(0,0.25) +
  theme_bw() + 
  theme(axis.title = element_text(size = axis.title.size),
        axis.text = element_text(size = axis.text.size))

ggplot(dplyr::filter(ticks_huck2002, ROUND > 25 ), 
       aes(x=Location,  y=(..count..)/sum(..count..))) + 
  geom_bar(binwidth=bindwidth.size*1000,colour="#808080") +
  scale_y_continuous(labels = percent) +
  geom_vline(xintercept = c(250,750),colour="#808080",linetype="longdash") +
  xlim(0,1000) +
  labs(title="", x = "Positions", y = "Relative Frequency") +
  ylim(0,0.25) +
  theme_bw() + 
  theme(axis.title = element_text(size = axis.title.size),
        axis.text = element_text(size = axis.text.size))


## Paper: percent of locations a certain distance away from equilibrium 
dist = 0.05

# discrete
length(subset(ticks_DS, strategy0 >= 0.25-(dist/2) & strategy0 <= 0.25+(dist/2))$strategy0)  / length(ticks_DS$strategy0) + length(subset(ticks_DS, strategy0 >= 0.75-(dist/2) & strategy0 <= 0.75+(dist/2))$strategy0)  / length(ticks_DS$strategy0)
length(subset(ticks_DS, strategy0 >= 0.5-(dist/2) & strategy0 <= 0.5+(dist/2))$strategy0)  / length(ticks_DS$strategy0)

# CI
length(subset(ticks_CI, strategy0 >= 0.25-(dist/2) & strategy0 <= 0.25+(dist/2))$strategy0)  / length(ticks_CI$strategy0) + length(subset(ticks_CI, strategy0 >= 0.75-(dist/2) & strategy0 <= 0.75+(dist/2))$strategy0)  / length(ticks_CI$strategy0)
length(subset(ticks_CI, strategy0 >= 0.5-(dist/2) & strategy0 <= 0.5+(dist/2))$strategy0)  / length(ticks_CI$strategy0)

# CS
length(subset(ticks_CS, strategy0 >= 0.25-(dist/2) & strategy0 <= 0.25+(dist/2))$strategy0)  / 
  length(ticks_CS$strategy0) + 
  length(subset(ticks_CS, strategy0 >= 0.75-(dist/2) & strategy0 <= 0.75+(dist/2))$strategy0)  / 
  length(ticks_CS$strategy0)
length(subset(ticks_CS, strategy0 >= 0.5-(dist/2) & strategy0 <= 0.5+(dist/2))$strategy0)  / length(ticks_CS$strategy0)




layout(matrix(c(1,1,2,3,4,4), 3, 2, byrow = TRUE))
playerPlot(data, treatname,session=sess)
histHotelling(data, treatname,2)
avgDist(data, treatname)




#####
#---- Summary of Results Table
library(plyr)

# Subjects count
ddply(subset(ticks_allHotelling, SubjectType=="HumanSubject" ),.(treatment,session),summarize,
      NumSubject = length(unique(subject)))


# HL Pre and post test
ddply(subset(HL_Test_Results,),.(treatment,pre_post),summarize,
      NumHL = length(pre_post))



# Average scores against robots. 
ddply(subset(ticks_allHotelling,SubjectType!="RobotSubject" & silo=="robot" & payoff < 400),.(treatment),summarize,
      Mean_ExgainstRobots = mean(payoff),
      SD_ExgainstRobots = sd(payoff))

overall.temp <- ddply(subset(ticks_allHotelling,SubjectType!="RobotSubject" & silo=="robot" & payoff < 400),.(treatment,period),summarize,
                      Mean_ExgainstRobots = mean(payoff),
                      SD_ExgainstRobots = sd(payoff))
mean(overall.temp$Mean_ExgainstRobots)
mean(overall.temp$SD_ExgainstRobots)

#Average Payoff - Includes robot treatments
ddply(subset(ticks_allHotelling, SubjectType!="RobotSubject" & payoff < 400),.(treatment),summarize,
      Mean_WithRobots = mean(payoff),
      SD_WithRobots = sd(payoff))

# Average Payoff - including vs robot treatments - overall
overall.temp <- ddply(subset(ticks_allHotelling, SubjectType!="RobotSubject" & payoff < 400),.(treatment,period),summarize,
                      Mean_WithRobots = mean(payoff),
                      SD_WithRobots = sd(payoff))
mean(overall.temp$Mean_WithRobots)
mean(overall.temp$SD_WithRobots)


# Average Payoff & SD - excluding  robot treatments
# by treatment
ddply(subset(ticks_allHotelling,silo!="robot" & payoff < 400),.(treatment),summarize,
      Mean_ExRobots = mean(payoff),
      SD_ExRobots = sd(payoff))
# overall
overall.temp <- ddply(subset(ticks_allHotelling,silo!="robot" & payoff < 400),.(treatment,period),summarize,
                      Mean_ExRobots = mean(payoff),
                      SD_ExRobots = sd(payoff))
mean(overall.temp$Mean_ExRobots)
mean(overall.temp$SD_ExRobots)

# Avg Dist - see AvgDistStudy





# sandbox - 
system.time({
  Hotelling.sim <- data.frame(s1=runif(1000000, min = 0, max = 1),
                              s2=runif(1000000, min = 0, max = 1),
                              s3=runif(1000000, min = 0, max = 1),
                              s4=runif(1000000, min = 0, max = 1))
  AvgDistCalc <- function(s1,s2,s3,s4){
    ActionSet <- sort(c(s1,s2,s3,s4))
    AvgDistThingy <- (abs(ActionSet[1]-0.25) + abs(ActionSet[2]-0.25) + abs(ActionSet[3]-0.75) + abs(ActionSet[4]-0.75)) / 4
    return(AvgDistThingy)
  }
  
  Hotelling.sim$AvgDist <- mapply(AvgDistCalc,
                                  Hotelling.sim$s1,
                                  Hotelling.sim$s2,
                                  Hotelling.sim$s3,
                                  Hotelling.sim$s4)
  mean(Hotelling.sim$AvgDist)
  
}) #with ten mil row, takes 
rm(Hotelling.sim)



