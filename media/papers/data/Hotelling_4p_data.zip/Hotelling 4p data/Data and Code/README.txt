Read Me


- ticks_allHotelling.CSV (66mb) has all the original session data. 

- HuckMV2003.CSV is the session data from the Huck et al 2002 paper

- Hotelling_GRAND_Metrics_Plot.R has function to help visualize and summarize subject/game actions

- AvgDist Study.R has all figures and data tables
 - Figure 4: AvgAbsDist by period and treatment
 - Figure 5, AvgAbsDist by second, by treatment over the period
 - Table 2, Estimates of Equation 4, Convergence Targets by Treatment
 - Table 3: Attainment of Near-Equilibrium Location Formations by Treatment
 - Figure 6, search for "CDF of Average Absolute Distances"

- Metrics-2013 PRductoin Runs.R
 Figure 3: 
 - Example period plots, search for "Example of session"
 - Histograms of player location selections, search "Histograms used in paper"


