these are the sas files from tim cason for the first 13 pilot experiments

they contain data collected from the buyer and seller files

tinfo1-tinfo7 are from the ucsc experiments
tinfou1-tinfou7are from usc experiments    ( .tinfo raw data files)

